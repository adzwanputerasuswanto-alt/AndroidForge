package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;

public class MainActivity extends Activity {
  private static final int RED=Color.rgb(210,18,32), BLUE=Color.rgb(0,72,145), DARK=Color.rgb(35,35,35), MUTED=Color.rgb(105,105,105), BG=Color.rgb(247,247,247), GREEN=Color.rgb(25,135,55);
  private static final String AUTH_DOMAIN="@ikt-monitoring.app";
  private FirebaseAuth auth; private FirebaseFirestore db;
  private boolean adminMode=false, loading=false;
  private EditText identityInput,passwordInput; private Button loginButton;
  private String currentName="", currentRole="", currentNik="", storeCode="K876", storeName="RC Veteran 2";
  private LinearLayout root;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(RED);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();}catch(Exception e){toast("Firebase belum siap: "+e.getMessage());} showLogin();}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke!=0)d.setStroke(1,stroke);return d;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private LinearLayout.LayoutParams lp(int h){return new LinearLayout.LayoutParams(-1,h<0?h:dp(h));}
  private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1);}
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  private TextView center(String s,int size,int color,boolean bold){TextView t=txt(s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
  private void showLogin(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);root=col();root.setBackgroundColor(BG);sc.addView(root);root.setPadding(dp(22),dp(22),dp(22),dp(22));
    LinearLayout hero=col();hero.setGravity(Gravity.CENTER);hero.setBackground(shape(RED,0,dp(22)));hero.setPadding(dp(16),dp(26),dp(16),dp(25));
    TextView logo=center("Alfamart",30,BLUE,true);logo.setBackground(shape(Color.WHITE,0,dp(24)));logo.setPadding(dp(22),dp(3),dp(22),dp(3));hero.addView(logo,lp(-2));TextView title=center("IKT Alfamart Monitoring",20,Color.WHITE,true);title.setPadding(0,dp(12),0,0);hero.addView(title,lp(-2));root.addView(hero,lp(-2));
    LinearLayout modes=row();modes.setPadding(0,dp(20),0,dp(8));Button p=modeButton("Personil Toko",!adminMode),a=modeButton("Admin Utama",adminMode);modes.addView(p,weight());modes.addView(a,weight());root.addView(modes,lp(-2));
    TextView info=center(adminMode?"LOGIN ADMIN UTAMA":"LOGIN PERSONIL TOKO",17,DARK,true);info.setPadding(0,dp(7),0,dp(8));root.addView(info,lp(-2));
    identityInput=new EditText(this);identityInput.setSingleLine(true);identityInput.setTextSize(15);identityInput.setPadding(dp(15),dp(12),dp(15),dp(12));identityInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));identityInput.setHint(adminMode?"Email Admin Utama":"NIK (8 angka)");identityInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:InputType.TYPE_CLASS_NUMBER);root.addView(identityInput,field());
    passwordInput=new EditText(this);passwordInput.setSingleLine(true);passwordInput.setTextSize(15);passwordInput.setPadding(dp(15),dp(12),dp(15),dp(12));passwordInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));passwordInput.setHint(adminMode?"Password":"PIN (6 digit)");passwordInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(passwordInput,field());
    loginButton=new Button(this);loginButton.setText("Login");loginButton.setTextColor(Color.WHITE);loginButton.setAllCaps(false);loginButton.setTextSize(16);loginButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));root.addView(loginButton,field());
    TextView note=center(adminMode?"Admin Utama\nLogin menggunakan email dan password.":"Personil Toko: COS, ACOS, dan Crew\nLogin menggunakan NIK dan PIN.",12,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(12)));note.setPadding(dp(12),dp(14),dp(12),dp(14));root.addView(note,field());
    p.setOnClickListener(v->{adminMode=false;showLogin();});a.setOnClickListener(v->{adminMode=true;showLogin();});loginButton.setOnClickListener(v->doLogin());setContentView(sc);
  }
  private Button modeButton(String s,boolean selected){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(selected?Color.WHITE:DARK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(selected?RED:Color.WHITE));return b;}
  private LinearLayout.LayoutParams field(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(10);return p;}
  private void doLogin(){if(auth==null||db==null){toast("Firebase belum siap.");return;}String id=identityInput.getText().toString().trim(),pw=passwordInput.getText().toString().trim();if(adminMode){if(id.isEmpty()||pw.isEmpty()){toast("Masukkan email dan password.");return;}signIn(id,pw,true,null);}else{if(!id.matches("\\d{8}")||!pw.matches("\\d{6}")){toast("NIK harus 8 angka dan PIN harus 6 digit.");return;}signIn(id+AUTH_DOMAIN,pw,false,id);}}
  private void signIn(String email,String password,boolean admin,String nik){loginButton.setEnabled(false);loginButton.setText("Memeriksa...");auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,task->{if(!task.isSuccessful()){restoreLogin();toast("Login gagal. Periksa NIK/email dan PIN/password.");return;}String doc=admin?"AdminUtama":nik;db.collection("Users").document(doc).get().addOnCompleteListener(this,r->{restoreLogin();if(!r.isSuccessful()||!r.getResult().exists()){auth.signOut();toast("Profil pengguna tidak ditemukan.");return;}DocumentSnapshot d=r.getResult();String role=d.getString("role"),registered=d.getString("email");boolean valid=Boolean.TRUE.equals(d.getBoolean("isActive"))&&(admin?"admin_utama".equals(role):(role!=null&&!"admin_utama".equals(role)&&nik.equals(d.getString("nik"))));if(admin&&registered!=null&&!registered.equalsIgnoreCase(email))valid=false;if(!valid){auth.signOut();toast("Akun tidak aktif atau hak akses tidak sesuai.");return;}currentName=d.getString("name")==null?"Personil":d.getString("name");currentRole=role;currentNik=admin?"":nik;storeCode=d.getString("storeCode")==null?"K876":d.getString("storeCode");storeName=d.getString("storeName")==null?"RC Veteran 2":d.getString("storeName");showDashboard("Beranda");});});}
  private void restoreLogin(){if(loginButton!=null){loginButton.setEnabled(true);loginButton.setText("Login");}}
  private void showDashboard(String page){
    LinearLayout shell=col(); shell.setBackgroundColor(BG);
    LinearLayout header=row(); header.setBackgroundColor(RED); header.setPadding(dp(16),dp(12),dp(16),dp(12));
    TextView menu=txt("☰",24,Color.WHITE,true); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(8),dp(4),dp(8),dp(4)); menu.setContentDescription("Buka menu"); menu.setClickable(true); menu.setFocusable(true); header.addView(menu);
    menu.setOnClickListener(v->{ PopupMenu popup=new PopupMenu(MainActivity.this,menu); String[] entries={"Beranda","Input Toko","Input PL Crew","Ranking Crew","Reward","Laporan","Profil","Keluar"}; for(String entry:entries) popup.getMenu().add(entry); popup.setOnMenuItemClickListener(item->{String choice=item.getTitle().toString(); if("Keluar".equals(choice)){if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();}else if("Input PL Crew".equals(choice)){showDashboard("Input PL");}else{showDashboard(choice);} return true;}); popup.show();});
    TextView brand=txt("IKT Alfamart",18,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(14);header.addView(brand,bp);
    TextView bell=txt("♧",22,Color.WHITE,true);header.addView(bell);shell.addView(header,lp(-2));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(14));sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout welcome=row();TextView avatar=center("●",25,RED,true);avatar.setBackground(shape(Color.WHITE,0xffdddddd,dp(28)));avatar.setWidth(dp(50));avatar.setHeight(dp(50));welcome.addView(avatar);
    LinearLayout who=col();who.setPadding(dp(10),0,0,0);who.addView(txt("Halo, "+currentName,15,DARK,true));who.addView(txt(roleLabel()+" • Toko "+storeCode,12,MUTED,false));welcome.addView(who,new LinearLayout.LayoutParams(0,-2,1));
    TextView month=txt("Nov 2026  ▣",11,DARK,true);month.setBackground(shape(Color.WHITE,0xffdddddd,dp(8)));month.setPadding(dp(9),dp(8),dp(9),dp(8));welcome.addView(month);body.addView(welcome,lp(-2));

    if(page.equals("Beranda")){
      if("crew".equals(currentRole)){
        cardTitle(body,"Pencapaian Saya (s.d. 20 Nov)");
        LinearLayout trophy=col();trophy.setBackground(shape(0xfffff6df,0xffeadcae,dp(11)));trophy.setPadding(dp(13),dp(12),dp(13),dp(12));
        trophy.addView(txt("🏆  Ranking Gabungan",14,DARK,true));trophy.addView(txt("Menunggu data pencapaian",18,GREEN,true));body.addView(trophy,lp(-2));
        cardTitle(body,"Pencapaian per Indikator");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
        LinearLayout acts=row();Button input=primary("Input PL Hari Ini");Button rank=smallButton("Lihat Ranking");acts.addView(input,weight());acts.addView(rank,weight());body.addView(acts,field());input.setOnClickListener(v->showDashboard("Input PL"));rank.setOnClickListener(v->showDashboard("Ranking Crew"));
      }else{
        cardTitle(body,"Kinerja Toko (s.d. 20 Nov)");
        LinearLayout metrics=row();for(String[] m:new String[][]{{"Net Sales","--"},{"Margin","--"},{"NSB","--"},{"Status IKT","--"}}){LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));c.setPadding(dp(5),dp(11),dp(5),dp(11));c.addView(center(m[0],10,MUTED,false));c.addView(center(m[1],15,GREEN,true));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,-2,1);q.setMargins(dp(2),0,dp(2),0);metrics.addView(c,q);}body.addView(metrics,lp(-2));
        LinearLayout actions=row();String[] acts="acos".equals(currentRole)?new String[]{"Input Toko","Input PL Crew","Ranking Crew"}:new String[]{"Input Toko","Input PL Crew","Ranking Crew","Reward"};
        for(String s:acts){Button b=smallButton(s);LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(66),1);q.setMargins(dp(2),dp(8),dp(2),dp(8));actions.addView(b,q);b.setOnClickListener(v->showDashboard(s.equals("Input Toko")?"Input Toko":s.equals("Input PL Crew")?"Input PL":s));}body.addView(actions,lp(-2));
        cardTitle(body,"Progress Indikator PL Toko");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
      }
    }else if(page.equals("Input PL")||page.equals("Input Toko")){
      cardTitle(body,page.equals("Input Toko")?"Input Data Toko":"Input Penawaran Langsung (PL)");
      body.addView(txt("Tanggal",13,DARK,true));DatePicker date=new DatePicker(this);date.setCalendarViewShown(false);date.setSpinnersShown(true);body.addView(date,lp(-2));
      String[] labels=page.equals("Input Toko")?new String[]{"Net Sales","Margin","NSB"}:new String[]{"PSM","PWP","Serba Gratis","SUEGER"};
      for(String s:labels){LinearLayout r=row();r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));r.addView(txt(s,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));EditText val=new EditText(this);val.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);val.setText("0");val.setEms(5);r.addView(val);LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);body.addView(r,q);}
      Button save=primary("Simpan");body.addView(save,field());save.setOnClickListener(v->toast("Form siap. Penyimpanan data akan diaktifkan setelah skema laporan dikonfirmasi."));
      TextView note=txt("Data dapat diperbarui pada hari yang sama maksimal pukul 23.59.",11,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(8)));note.setPadding(dp(10),dp(10),dp(10),dp(10));body.addView(note,lp(-2));
    }else if(page.equals("Ranking Crew")){
      cardTitle(body,"Ranking Crew");LinearLayout tabs=row();tabs.addView(smallButton("Harian"),weight());tabs.addView(primary("Bulanan"),weight());body.addView(tabs,field());
      for(int i=1;i<=5;i++)progressRow(body,i+". Personil Crew","Menunggu data pencapaian");
    }else if(page.equals("Reward")){
      cardTitle(body,"Reward IKT");LinearLayout trophy=col();trophy.setBackground(shape(0xfff0f8e9,0xffd4e8c8,dp(10)));trophy.setPadding(dp(14),dp(14),dp(14),dp(14));trophy.addView(center("🏆",28,GREEN,true));trophy.addView(center("Status IKT Toko",14,DARK,true));trophy.addView(center("Menunggu data kinerja",18,GREEN,true));body.addView(trophy,lp(-2));
      cardTitle(body,"Kategori Reward");progressRow(body,"Kategori A","Menunggu pencapaian Net Sales");progressRow(body,"Penerima","Data reward belum tersedia");
    }else if(page.equals("Profil")){
      cardTitle(body,"Profil Personil");TextView profileAvatar=center("●",38,RED,true);profileAvatar.setBackground(shape(Color.WHITE,0xffdddddd,dp(48)));profileAvatar.setHeight(dp(96));body.addView(profileAvatar,lp(-2));TextView name=center(currentName,18,DARK,true);body.addView(name,lp(-2));for(String[] x:new String[][]{{"NIK",currentNik.isEmpty()?"Admin Utama":currentNik},{"Username",currentNik},{"Jabatan",roleLabel()},{"Kode Toko",storeCode},{"Nama Toko",storeName}})detail(body,x[0],x[1]);
      Button out=smallButton("Keluar");body.addView(out,field());out.setOnClickListener(v->{if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();});
    }else if(page.equals("Laporan")){
      cardTitle(body,"Laporan");progressRow(body,"Rekap Kinerja Toko","Net Sales, Margin, NSB, Status IKT");progressRow(body,"Rekap Penawaran Langsung","PSM, PWP, Serba Gratis, SUEGER");progressRow(body,"Ranking Crew","Peringkat dan pencapaian");cardTitle(body,"Ekspor Laporan");LinearLayout ex=row();ex.addView(smallButton("Excel (.xlsx)"),weight());ex.addView(smallButton("PDF (.pdf)"),weight());body.addView(ex,lp(-2));
    }else{
      cardTitle(body,page);body.addView(txt("Halaman ini disiapkan mengikuti desain referensi. Data dan fungsi operasional akan dihubungkan bertahap.",14,MUTED,false));
    }
    LinearLayout nav=row(); nav.setBackgroundColor(Color.WHITE); nav.setElevation(dp(8)); nav.setPadding(dp(2),dp(4),dp(2),dp(8)); String[][] tabs={{"⌂","Beranda"},{"✎","Input PL"},{"♛","Ranking Crew"},{"▤","Laporan"},{"♙","Profil"}}; for(String[] tab:tabs){String t=tab[1]; LinearLayout item=col(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2),dp(5),dp(2),dp(5)); item.setClickable(true); item.setFocusable(true); item.setBackgroundResource(android.R.drawable.list_selector_background); TextView ico=center(tab[0],18,t.equals(page)?RED:MUTED,true); TextView label=center(t,9,t.equals(page)?RED:MUTED,true); item.addView(ico,lp(-2)); item.addView(label,lp(-2)); nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1)); item.setOnClickListener(v->showDashboard(t)); } shell.addView(nav,lp(-2)); setContentView(shell);
  }
  private String roleLabel(){if("cos".equals(currentRole))return "COS";if("acos".equals(currentRole))return "ACOS";if("crew".equals(currentRole))return "Crew";return "Admin Utama";}
  private void cardTitle(LinearLayout p,String s){TextView t=txt(s,16,DARK,true);t.setPadding(0,dp(16),0,dp(9));p.addView(t,lp(-2));}
  private View metricBox(String title,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe4e4e4,dp(10)));c.setPadding(dp(6),dp(12),dp(6),dp(12));c.addView(center(title,10,MUTED,false));c.addView(center(value,16,GREEN,true));return c;}
  private View metric(LinearLayout p,String title,String sub,String val,boolean unused){LinearLayout c=col();c.setBackground(shape(0xfffff5dc,0xffeadcae,dp(12)));c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(txt(title,14,DARK,true));c.addView(txt(sub+"  "+val,14,GREEN,true));p.addView(c,lp(-2));return c;}
  private void progressRow(LinearLayout p,String name,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(9)));c.setPadding(dp(12),dp(10),dp(12),dp(10));TextView a=txt(name,14,DARK,true);c.addView(a);c.addView(txt(value,12,MUTED,false));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);p.addView(c,q);}
  private void detail(LinearLayout p,String k,String v){LinearLayout r=row();r.setPadding(dp(10),dp(13),dp(10),dp(13));r.setBackground(shape(Color.WHITE,0xffe6e6e6,dp(8)));r.addView(txt(k,13,DARK,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,DARK,true));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(5);p.addView(r,q);}
  private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setTextColor(RED);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));return b;}
  private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));return b;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(auth!=null&&auth.getCurrentUser()!=null){showDashboard("Beranda");}else showLogin();}
}
