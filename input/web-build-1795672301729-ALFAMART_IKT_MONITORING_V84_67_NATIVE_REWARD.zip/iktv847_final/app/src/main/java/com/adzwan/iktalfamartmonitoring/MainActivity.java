package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.content.Intent;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.yalantis.ucrop.UCrop;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
  private static final int RED=Color.rgb(196,0,35), BLUE=Color.rgb(20,75,130), DARK=Color.rgb(29,37,51), MUTED=Color.rgb(111,121,136), BG=Color.rgb(246,247,250), GREEN=Color.rgb(24,132,83), SOFT_RED=Color.rgb(255,241,244);
  private static final String AUTH_DOMAIN="@ikt-monitoring.app";
  private FirebaseAuth auth; private FirebaseFirestore db; private FirebaseStorage storage; private ImageView profileAvatar; private static final int PICK_PROFILE_PHOTO=412;
  private boolean adminMode=false, loading=false;
  private EditText identityInput,passwordInput; private Button loginButton;
  private String currentName="", currentRole="", currentNik="", storeCode="", storeName="", storeType="";
  private Calendar rewardSelectedMonth=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"),new Locale("id","ID"));
  private LinearLayout root;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(RED);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();storage=FirebaseStorage.getInstance();}catch(Exception e){toast("Firebase belum siap: "+e.getMessage());} showLogin();}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(Math.max(radius,dp(14)));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private LinearLayout.LayoutParams lp(int h){return new LinearLayout.LayoutParams(-1,h<0?h:dp(h));}
  private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1);}
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  private TextView center(String s,int size,int color,boolean bold){TextView t=txt(s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
  private void showLogin(){
    // Halaman login dibuat satu layar penuh tanpa scroll; ruang vertikal dipadatkan proporsional.
    root=col();root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(0xfffff8f9);root.setPadding(dp(10),dp(6),dp(10),dp(4));
    addLoginBranding(root,true);
    LinearLayout modes=row();modes.setPadding(dp(6),dp(7),dp(6),dp(4));Button p=modeButton("Personil Toko",!adminMode),a=modeButton("Admin Utama",adminMode);modes.addView(p,weight());modes.addView(a,weight());root.addView(modes,lp(-2));
    TextView info=center(adminMode?"🛡  LOGIN ADMIN UTAMA":"👥  LOGIN PERSONIL TOKO",17,DARK,true);info.setPadding(0,dp(5),0,dp(6));root.addView(info,lp(-2));
    identityInput=new EditText(this);identityInput.setSingleLine(true);identityInput.setTextSize(15);identityInput.setPadding(dp(15),dp(8),dp(15),dp(8));identityInput.setBackground(shape(Color.WHITE,0xffcbd0d8,dp(14)));identityInput.setHint(adminMode?"Email Admin Utama":"NIK (8 angka)");identityInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:InputType.TYPE_CLASS_NUMBER);root.addView(identityInput,compactLoginField());
    passwordInput=new EditText(this);passwordInput.setSingleLine(true);passwordInput.setTextSize(15);passwordInput.setPadding(dp(15),dp(8),dp(15),dp(8));passwordInput.setBackground(shape(Color.WHITE,0xffcbd0d8,dp(14)));passwordInput.setHint(adminMode?"Password":"PIN (6 digit)");passwordInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(passwordInput,compactLoginField());
    loginButton=primary("Login");root.addView(loginButton,compactLoginField());
    TextView note=center(adminMode?"ⓘ  Admin Utama\nLogin menggunakan email dan password.":"ⓘ  Personil Toko: COS, ACOS, dan Crew\nLogin menggunakan NIK dan PIN.",12,BLUE,false);note.setBackground(shape(0xffe5efff,0,dp(14)));note.setPadding(dp(10),dp(8),dp(10),dp(8));root.addView(note,compactLoginField());
    if(!adminMode){LinearLayout signup=row();signup.setGravity(Gravity.CENTER);TextView prompt=txt("Belum punya akun?",13,DARK,true);signup.addView(prompt);TextView link=txt("  Daftar Akun Baru  ➜",13,RED,true);signup.addView(link);signup.setPadding(0,dp(4),0,dp(4));signup.setOnClickListener(v->showRegister());root.addView(signup,lp(-2));}
    TextView credit=center("Design by Adzwan Putera Suswanto",11,MUTED,false);credit.setPadding(0,dp(5),0,dp(3));root.addView(credit,lp(-2));addBottomBrandWave(root);
    p.setOnClickListener(v->{adminMode=false;showLogin();});a.setOnClickListener(v->{adminMode=true;showLogin();});loginButton.setOnClickListener(v->doLogin());setContentView(root);
  }
  private LinearLayout.LayoutParams compactLoginField(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(6);return p;}
  private void showRegister(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(0xfffff8f9);LinearLayout page=col();page.setGravity(Gravity.CENTER_HORIZONTAL);page.setPadding(dp(12),dp(12),dp(12),dp(18));page.setBackgroundColor(0xfffff8f9);page.setMinimumWidth(getResources().getDisplayMetrics().widthPixels);sc.addView(page,new ScrollView.LayoutParams(-1,-2));
    addLoginBranding(page,true);
    TextView title=center("DAFTAR AKUN PERSONIL",21,Color.WHITE,true);title.setBackgroundColor(RED);title.setPadding(0,dp(12),0,dp(12));page.addView(title,lp(-2));
    TextView desc=center("Isi data personil dan toko. Akun menunggu verifikasi Admin Utama.",13,DARK,false);desc.setPadding(dp(8),dp(10),dp(8),dp(8));page.addView(desc,lp(-2));
    EditText name=registerField(page,"Nama Lengkap",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    EditText nik=registerField(page,"NIK (8 angka)",InputType.TYPE_CLASS_NUMBER);
    Spinner role=new Spinner(this);String[] roles={"Pilih Jabatan","Crew","ACOS","COS"};role.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,roles));page.addView(role,field());
    EditText code=registerField(page,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText shop=registerField(page,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    TextView storeTypeLabel=txt("Jenis Toko",13,DARK,true);storeTypeLabel.setPadding(dp(12),dp(8),0,dp(2));page.addView(storeTypeLabel,lp(-2));
    Spinner storeTypeChoice=new Spinner(this);String[] storeTypes={"Pilih Jenis Toko","Normal (2 Shift)","24 Jam (3 Shift)"};storeTypeChoice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,storeTypes));page.addView(storeTypeChoice,field());
    EditText pin=registerField(page,"Buat PIN (6 digit)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    EditText confirm=registerField(page,"Ulangi PIN",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    Button submit=primary("Daftar Akun");page.addView(submit,field());
    TextView regInfo=txt("ⓘ  Pendaftaran tidak memerlukan kode aktivasi. Akun baru belum dapat login sampai Admin Utama memverifikasi data dan mengaktifkannya.",12,BLUE,false);regInfo.setBackground(shape(0xffe5efff,0,dp(14)));regInfo.setPadding(dp(12),dp(12),dp(12),dp(12));page.addView(regInfo,field());
    TextView back=center("←  Kembali ke Login",15,RED,true);back.setPadding(0,dp(14),0,dp(12));page.addView(back,lp(-2));back.setOnClickListener(v->showLogin());
    TextView credit=center("Design by Adzwan Putera Suswanto",12,MUTED,false);credit.setPadding(0,dp(12),0,dp(8));page.addView(credit,lp(-2));addBottomBrandWave(page);
    submit.setOnClickListener(v->{String nm=name.getText().toString().trim(),n=nik.getText().toString().trim(),r=role.getSelectedItemPosition()==1?"crew":role.getSelectedItemPosition()==2?"acos":role.getSelectedItemPosition()==3?"cos":"",c=code.getText().toString().trim().toUpperCase(Locale.US),sn=shop.getText().toString().trim(),requestedStoreType=storeTypeChoice.getSelectedItemPosition()==1?"NORMAL":storeTypeChoice.getSelectedItemPosition()==2?"24_JAM":"",pw=pin.getText().toString(),cp=confirm.getText().toString();if(nm.isEmpty()||!n.matches("\\d{8}")||r.isEmpty()||c.isEmpty()||sn.isEmpty()||requestedStoreType.isEmpty()||!pw.matches("\\d{6}")||!pw.equals(cp)){toast("Periksa semua data, jabatan, NIK, dan PIN.");return;}if(auth==null||db==null){toast("Firebase belum siap.");return;}submit.setEnabled(false);submit.setText("Mendaftarkan...");String email=n+AUTH_DOMAIN;auth.createUserWithEmailAndPassword(email,pw).addOnCompleteListener(this,task->{if(!task.isSuccessful()){submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran gagal: "+(task.getException()==null?"periksa koneksi":task.getException().getLocalizedMessage()));return;}Map<String,Object> req=new HashMap<>();req.put("nik",n);req.put("name",nm);req.put("requestedRole",r);req.put("storeCode",c);req.put("storeName",sn);req.put("requestedStoreType",requestedStoreType);req.put("email",email);req.put("status","pending");req.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());req.put("authUid",auth.getCurrentUser().getUid());db.collection("RegistrationRequests").document(n).set(req).addOnSuccessListener(vv->{auth.signOut();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran terkirim. Tunggu verifikasi Admin Utama.");showLogin();}).addOnFailureListener(e->{if(auth.getCurrentUser()!=null)auth.getCurrentUser().delete();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Permohonan gagal disimpan. Rules Firestore perlu diperbarui: "+e.getLocalizedMessage());});});});
    setContentView(sc);
  }
  private void addLoginBranding(LinearLayout parent,boolean compact){
    LinearLayout brand=col();brand.setBackground(shape(RED,0,dp(22)));brand.setClipToOutline(true);brand.setElevation(dp(4));
    LinearLayout top=col();top.setGravity(Gravity.CENTER);top.setPadding(dp(12),dp(compact?14:20),dp(12),dp(12));top.setBackgroundColor(RED);
    LinearLayout logoCard=row();logoCard.setGravity(Gravity.CENTER);logoCard.setBackground(shape(Color.WHITE,0xfff0d7df,dp(14)));logoCard.setPadding(dp(8),dp(6),dp(8),dp(6));logoCard.setElevation(dp(2));
    ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.alfamart_logo_login);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logoCard.addView(logo,new LinearLayout.LayoutParams(dp(170),dp(54)));
    LinearLayout.LayoutParams logoCardParams=new LinearLayout.LayoutParams(dp(188),dp(68));logoCardParams.gravity=Gravity.CENTER;logoCardParams.bottomMargin=dp(2);top.addView(logoCard,logoCardParams);
    TextView title=center("IKT Alfamart Monitoring",compact?18:21,Color.WHITE,true);title.setPadding(0,dp(8),0,0);top.addView(title,lp(-2));brand.addView(top,lp(-2));
    View topWave=new View(this){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);Path path=new Path();@Override protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();path.reset();path.moveTo(0,h*.42f);path.cubicTo(w*.24f,-h*.10f,w*.42f,h*.08f,w*.58f,h*.42f);path.cubicTo(w*.78f,h*.78f,w*.88f,h*.55f,w,h*.18f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(0xffffd21f);c.drawPath(path,p);path.reset();path.moveTo(0,h*.72f);path.cubicTo(w*.22f,h*.18f,w*.42f,h*.30f,w*.58f,h*.70f);path.cubicTo(w*.78f,h*1.02f,w*.90f,h*.78f,w,h*.46f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(RED);c.drawPath(path,p);}};
    brand.addView(topWave,new LinearLayout.LayoutParams(-1,dp(22)));
    FrameLayout photoFrame=new FrameLayout(this);ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.profile_store_banner);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photoFrame.addView(photo,new FrameLayout.LayoutParams(-1,dp(compact?130:160)));
    View bottomWave=new View(this){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);Path path=new Path();@Override protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();path.reset();path.moveTo(0,h*.20f);path.cubicTo(w*.22f,h*.58f,w*.40f,h*.52f,w*.58f,h*.20f);path.cubicTo(w*.78f,-h*.08f,w*.90f,h*.10f,w,h*.36f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(0xffffd21f);c.drawPath(path,p);path.reset();path.moveTo(0,h*.50f);path.cubicTo(w*.22f,h*.88f,w*.42f,h*.78f,w*.58f,h*.48f);path.cubicTo(w*.78f,h*.18f,w*.90f,h*.36f,w,h*.60f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(RED);c.drawPath(path,p);}};
    photoFrame.addView(bottomWave,new FrameLayout.LayoutParams(-1,dp(30),Gravity.BOTTOM));brand.addView(photoFrame,new LinearLayout.LayoutParams(-1,dp(compact?130:160)));parent.addView(brand,lp(-2));
  }
  private void addBottomBrandWave(LinearLayout parent){
    View wave=new View(this){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);Path path=new Path();@Override protected void onDraw(Canvas c){float w=getWidth(),h=dp(30),top=Math.max(0,getHeight()-h);c.save();c.translate(0,top);path.reset();path.moveTo(0,h*.38f);path.cubicTo(w*.22f,-h*.02f,w*.38f,h*.02f,w*.55f,h*.38f);path.cubicTo(w*.75f,h*.76f,w*.90f,h*.70f,w,h*.22f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(0xffffd21f);c.drawPath(path,p);path.reset();path.moveTo(0,h*.60f);path.cubicTo(w*.22f,h*.20f,w*.38f,h*.22f,w*.55f,h*.60f);path.cubicTo(w*.75f,h*.98f,w*.90f,h*.94f,w,h*.44f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(RED);c.drawPath(path,p);c.restore();}};
    wave.setMinimumHeight(dp(30));
    parent.addView(wave,new LinearLayout.LayoutParams(-1,0,1f));
  }
  private EditText registerField(LinearLayout parent,String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setInputType(type);e.setPadding(dp(17),dp(14),dp(17),dp(14));e.setBackground(shape(Color.WHITE,0xffe4e8ef,dp(16)));parent.addView(e,field());return e;}
  private Button modeButton(String s,boolean selected){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(selected?Color.WHITE:DARK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(selected?RED:Color.WHITE));return b;}
  private LinearLayout.LayoutParams field(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(10);return p;}
  private void doLogin(){if(auth==null||db==null){toast("Firebase belum siap.");return;}String id=identityInput.getText().toString().trim(),pw=passwordInput.getText().toString().trim();if(adminMode){if(id.isEmpty()||pw.isEmpty()){toast("Masukkan email dan password.");return;}signIn(id,pw,true,null);}else{if(!id.matches("\\d{8}")||!pw.matches("\\d{6}")){toast("NIK harus 8 angka dan PIN harus 6 digit.");return;}signIn(id+AUTH_DOMAIN,pw,false,id);}}
  private void signIn(String email,String password,boolean admin,String nik){
    loginButton.setEnabled(false);loginButton.setText("Memeriksa...");
    auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,task->{
      if(!task.isSuccessful()){restoreLogin();toast("Login gagal. Periksa NIK/email dan PIN/password.");return;}
      if(admin){db.collection("Users").document("AdminUtama").get().addOnSuccessListener(d->finishLogin(d,true,nik,email)).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil Admin: "+e.getLocalizedMessage());});return;}
      // Personil: baca identitas kanonis langsung dari Personnel/{NIK}; tidak memakai collectionGroup/index.
      db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{
        if(!person.exists()){restoreLogin();auth.signOut();toast("Profil Personnel tidak ditemukan. Minta Admin Utama memeriksa data personil.");return;}
        if(!Boolean.TRUE.equals(person.getBoolean("isActive"))){restoreLogin();auth.signOut();toast("Akun personil belum aktif. Hubungi Admin Utama.");return;}
        String role=firstNonEmpty(person.getString("currentRole"),person.getString("role"));
        String code=firstNonEmpty(person.getString("currentStoreCode"),person.getString("storeCode"));
        String shop=firstNonEmpty(person.getString("currentStoreName"),person.getString("storeName"));
        if(role.isEmpty()||code.isEmpty()||shop.isEmpty()){restoreLogin();auth.signOut();toast("Data jabatan atau toko aktif di Personnel belum lengkap. Hubungi Admin Utama.");return;}
        db.collection("Stores").document(code).collection("Users").document(nik).get().addOnSuccessListener(profile->{
          if(!profile.exists()||!Boolean.TRUE.equals(profile.getBoolean("isActive"))||!nik.equals(profile.getString("nik"))){restoreLogin();auth.signOut();toast("Profil toko aktif tidak ditemukan atau belum aktif. Periksa Stores/"+code+"/Users/"+nik+".");return;}
          String storeRole=firstNonEmpty(profile.getString("role"),role);
          if(!role.equals(storeRole)){restoreLogin();auth.signOut();toast("Jabatan di Personnel dan profil toko berbeda. Minta Admin Utama menyamakan data.");return;}
          // Jangan membaca Stores/{kode} di proses login karena Firestore Rules aktif
          // hanya mengizinkan akses ke Personnel dan profil Stores/{kode}/Users/{NIK}.
          // Jenis toko sudah disalin oleh Admin Utama ke dokumen personil/profil pengguna.
          String rawType=firstNonEmpty(person.getString("storeType"),profile.getString("storeType"));
          String type=normalizeStoreType(rawType);
          currentName=firstNonEmpty(person.getString("name"),profile.getString("name"));
          currentRole=role;currentNik=nik;storeCode=code;storeName=shop;storeType=type;
          restoreLogin();showDashboard("Beranda");
        }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil toko: "+e.getLocalizedMessage());});
      }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca Personnel: "+e.getLocalizedMessage());});
    });
  }
  private String normalizeStoreType(String value){
    if(value==null)return "";
    String v=value.trim().toUpperCase(Locale.US).replace(' ','_');
    if(v.equals("24_JAM")||v.equals("24JAM")||v.equals("24_JAM_STORE"))return "24_JAM";
    if(v.equals("NORMAL")||v.equals("TOKO_NORMAL"))return "NORMAL";
    return "";
  }
  private String firstNonEmpty(String a,String b){if(a!=null&&!a.trim().isEmpty()&&!"...".equals(a.trim())&&!".".equals(a.trim()))return a;return b==null?"":b;}
  private void finishLogin(DocumentSnapshot d,boolean admin,String nik,String email){restoreLogin();String role=d.getString("role"),registered=d.getString("email");boolean valid=Boolean.TRUE.equals(d.getBoolean("isActive"))&&(admin?"admin_utama".equals(role):(role!=null&&("crew".equals(role)||"acos".equals(role)||"cos".equals(role))&&nik.equals(d.getString("nik"))));if(admin&&registered!=null&&!registered.equalsIgnoreCase(email))valid=false;if(!valid){auth.signOut();toast("Akun belum aktif atau hak akses tidak sesuai. Jika baru mendaftar, tunggu verifikasi Admin Utama.");return;}currentName=d.getString("name")==null?"Personil":d.getString("name");currentRole=role;currentNik=admin?"":nik;storeCode=d.getString("storeCode")==null?"":d.getString("storeCode");storeName=d.getString("storeName")==null?"":d.getString("storeName");if(!admin&&(storeCode.isEmpty()||storeName.isEmpty())){auth.signOut();toast("Profil belum memiliki data toko aktif. Hubungi Admin Utama.");return;}showDashboard("Beranda");}
  private void restoreLogin(){if(loginButton!=null){loginButton.setEnabled(true);loginButton.setText("Login");}}
  private void showDashboard(String page){
    FrameLayout screen=new FrameLayout(this);screen.setClipChildren(false);screen.setClipToPadding(false);LinearLayout shell=col(); shell.setBackgroundColor(BG); shell.setClipChildren(false); shell.setClipToPadding(false);
    LinearLayout header=row(); header.setBackgroundColor(RED); header.setGravity(Gravity.CENTER_VERTICAL); header.setMinimumHeight(dp(58)); header.setPadding(dp(16),dp(10),dp(16),dp(10)); header.setElevation(dp(8)); header.setClipToPadding(false);
    TextView menu=txt("☰",24,Color.WHITE,true); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(8),dp(4),dp(8),dp(4)); menu.setContentDescription("Buka menu"); menu.setClickable(true); menu.setFocusable(true); header.addView(menu);
    menu.setOnClickListener(v->showNavigationDrawer(screen));
    TextView brand=txt("IKT Alfamart",18,Color.WHITE,true); brand.setSingleLine(true); brand.setGravity(Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(14);header.addView(brand,bp);
    TextView bell=txt("♧",22,Color.WHITE,true);header.addView(bell);shell.addView(header,lp(-2));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(14));sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    if(!page.equals("Profil")){
      LinearLayout welcome=row();FrameLayout welcomeAvatar=createRoleProfileAvatar(dp(58),dp(34));LinearLayout.LayoutParams welcomeAvatarParams=new LinearLayout.LayoutParams(dp(58),dp(58));welcome.addView(welcomeAvatar,welcomeAvatarParams);
      LinearLayout who=col();who.setPadding(dp(10),0,0,0);who.addView(txt("Halo, "+currentName,15,DARK,true));who.addView(txt("admin_utama".equals(currentRole)?"Admin Utama • Seluruh Toko":roleLabel()+" • Toko "+storeCode,12,MUTED,false));welcome.addView(who,new LinearLayout.LayoutParams(0,-2,1));
      String monthText="Ranking Crew".equals(page)?new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(new Date()).toUpperCase(new Locale("id","ID")):("Reward".equals(page)?new SimpleDateFormat("MMM yyyy",new Locale("id","ID")).format(rewardSelectedMonth.getTime()):new SimpleDateFormat("MMM yyyy",new Locale("id","ID")).format(new Date()));TextView month=txt(monthText+"  ▾",11,DARK,true);month.setBackground(shape(Color.WHITE,0xffdddddd,dp(18)));month.setPadding(dp(11),dp(8),dp(11),dp(8));welcome.addView(month);if("Reward".equals(page)){month.setOnClickListener(v->{DatePickerDialog picker=new DatePickerDialog(this,(view,y,m,d)->{rewardSelectedMonth.set(y,m,1,0,0,0);rewardSelectedMonth.set(Calendar.MILLISECOND,0);showDashboard("Reward");},rewardSelectedMonth.get(Calendar.YEAR),rewardSelectedMonth.get(Calendar.MONTH),1);picker.getDatePicker().setMaxDate(System.currentTimeMillis());picker.show();});}body.addView(welcome,lp(-2));
    }

    if(page.equals("Pengaturan Jenis Toko")){
      if(!"admin_utama".equals(currentRole)){body.addView(txt("Akses hanya untuk Admin Utama.",14,RED,true));}
      else showStoreTypeSettings(body);
    }else if(page.equals("Beranda")){
      if("crew".equals(currentRole)){
        cardTitle(body,"Pencapaian Saya (s.d. 20 Nov)");
        LinearLayout trophy=col();trophy.setBackground(shape(0xfffff6df,0xffeadcae,dp(11)));trophy.setPadding(dp(13),dp(12),dp(13),dp(12));
        trophy.addView(txt("🏆  Ranking Gabungan",14,DARK,true));trophy.addView(txt("Menunggu data pencapaian",18,GREEN,true));body.addView(trophy,lp(-2));
        cardTitle(body,"Pencapaian per Indikator");loadCrewIndicatorProgress(body);
        LinearLayout acts=row();Button input=primary("Input PL Hari Ini");Button rank=smallButton("Lihat Ranking");acts.addView(input,weight());acts.addView(rank,weight());body.addView(acts,field());input.setOnClickListener(v->showDashboard("Input PL"));rank.setOnClickListener(v->showDashboard("Ranking Crew"));
      }else{
        TextView kinerjaTitle=txt("Kinerja Toko (memuat data...)",16,DARK,true);kinerjaTitle.setPadding(0,dp(16),0,dp(9));body.addView(kinerjaTitle,lp(-2));
        LinearLayout metrics=col(); TextView[][] metricFields=new TextView[4][4]; String[] metricLabels={"NET SALES","MARGIN","NSB","STATUS IKT"}; int[] cardColors={0xffFBE3E8,0xffDFEAFA,0xffE2F2E2,0xffFCEBD9};
        for(int rowIndex=0;rowIndex<2;rowIndex++){ LinearLayout metricRow=row(); for(int colIndex=0;colIndex<2;colIndex++){int ix=rowIndex*2+colIndex; LinearLayout c=col(); c.setBackground(shape(cardColors[ix],0xffe7ebf2,dp(20)));c.setElevation(dp(3)); c.setPadding(dp(13),dp(14),dp(13),dp(14)); c.addView(txt(metricLabels[ix],16,BLUE,true)); metricFields[ix][0]=txt("Memuat...",29,Color.BLACK,true); metricFields[ix][0].setPadding(0,dp(9),0,dp(1)); c.addView(metricFields[ix][0]); metricFields[ix][1]=txt(ix==3?"Status toko":"Pencapaian",14,DARK,false); c.addView(metricFields[ix][1]); View gap=new View(this);c.addView(gap,lp(12)); metricFields[ix][2]=txt("Target : --",13,DARK,false); c.addView(metricFields[ix][2]); metricFields[ix][3]=txt("Aktual : --",13,DARK,false); c.addView(metricFields[ix][3]); TextView kekurangan=txt("",13,DARK,false); if(ix==0){kekurangan.setPadding(0,dp(3),0,0);c.addView(kekurangan);} TextView note=txt("Keterangan : Menunggu data",13,GREEN,true); note.setPadding(0,dp(13),0,0);c.addView(note); metricFields[ix]=ix==0?new TextView[]{metricFields[ix][0],metricFields[ix][1],metricFields[ix][2],metricFields[ix][3],note,kekurangan}:new TextView[]{metricFields[ix][0],metricFields[ix][1],metricFields[ix][2],metricFields[ix][3],note}; LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(254),1); q.setMargins(dp(4),dp(4),dp(4),dp(4)); metricRow.addView(c,q);} metrics.addView(metricRow,lp(-2)); } body.addView(metrics,lp(-2)); loadDashboardIKT(metricFields,kinerjaTitle);
        LinearLayout menuHeading=row();menuHeading.setGravity(Gravity.CENTER);View leftLine=new View(this);leftLine.setBackgroundColor(RED);menuHeading.addView(leftLine,new LinearLayout.LayoutParams(0,dp(2),1));LinearLayout menuTitlePill=row();menuTitlePill.setGravity(Gravity.CENTER);menuTitlePill.setPadding(dp(16),dp(8),dp(18),dp(8));menuTitlePill.setBackground(shape(RED,0,dp(24)));ImageView menuStoreIcon=new ImageView(this);menuStoreIcon.setImageResource(R.drawable.dashboard_menu_store_icon);menuStoreIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams storeIconParams=new LinearLayout.LayoutParams(dp(20),dp(20));storeIconParams.rightMargin=dp(8);menuTitlePill.addView(menuStoreIcon,storeIconParams);TextView menuTitle=center("Menu Utama Toko",16,Color.WHITE,true);menuTitlePill.addView(menuTitle,lp(-2));LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(-2,-2);titleParams.leftMargin=dp(8);titleParams.rightMargin=dp(8);menuHeading.addView(menuTitlePill,titleParams);View rightLine=new View(this);rightLine.setBackgroundColor(RED);menuHeading.addView(rightLine,new LinearLayout.LayoutParams(0,dp(2),1));LinearLayout.LayoutParams headingParams=lp(-2);headingParams.topMargin=dp(14);headingParams.bottomMargin=dp(4);body.addView(menuHeading,headingParams);
        LinearLayout menuRow1=row();LinearLayout.LayoutParams menuTile1=new LinearLayout.LayoutParams(0,dp(94),1);menuTile1.setMargins(dp(4),dp(5),dp(4),dp(5));menuRow1.addView(dashboardMenuTile(R.drawable.dashboard_icon_target,"INPUT TARGET IKT","Input Target IKT"),menuTile1);LinearLayout.LayoutParams menuTile2=new LinearLayout.LayoutParams(0,dp(94),1);menuTile2.setMargins(dp(4),dp(5),dp(4),dp(5));menuRow1.addView(dashboardMenuTile(R.drawable.dashboard_icon_sales,"INPUT LAPORAN SALES","Input Toko"),menuTile2);body.addView(menuRow1,field());
        LinearLayout menuRow2=row();LinearLayout.LayoutParams menuTile3=new LinearLayout.LayoutParams(0,dp(94),1);menuTile3.setMargins(dp(4),dp(5),dp(4),dp(5));menuRow2.addView(dashboardMenuTile(R.drawable.dashboard_icon_clipboard,"INPUT TARGET PL","Input Target Penawaran Langsung"),menuTile3);LinearLayout.LayoutParams menuTile4=new LinearLayout.LayoutParams(0,dp(94),1);menuTile4.setMargins(dp(4),dp(5),dp(4),dp(5));menuRow2.addView(dashboardMenuTile(R.drawable.dashboard_icon_gift,"REWARD","Reward"),menuTile4);body.addView(menuRow2,field());
        cardTitle(body,"Progress Indikator PL Toko");loadPLStoreProgress(body);
      }
    }else if(page.equals("Input Target Penawaran Langsung")) {
      cardTitle(body,"Input Target Penawaran Langsung");
      body.addView(txt("Target diinput bertahap. Periode berikutnya baru terbuka saat tanggal periodenya dimulai.",12,MUTED,false),field());
      final EditText adminCode, adminName;
      if("admin_utama".equals(currentRole)){
        adminCode=registerField(body,"Masukkan Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        adminName=null;
      }else{adminCode=null;adminName=null;body.addView(txt("Toko: "+storeCode+" • "+storeName,12,BLUE,true),field());}
      body.addView(txt("Bulan Target",13,DARK,true)); DatePicker targetMonth=new DatePicker(this); TextView targetMonthSelector=addDropdownDatePicker(body,targetMonth,true,null);
      Map<String,EditText> plTargets=new HashMap<>();
      addTargetPeriod(body,plTargets,"PSM","Week 1 • Tanggal 1–7","PSM_W1"); addWorkdays(body,plTargets,"PSM_W1"); addTargetPeriod(body,plTargets,"PSM","Week 2 • Tanggal 8–15","PSM_W2"); addWorkdays(body,plTargets,"PSM_W2"); addTargetPeriod(body,plTargets,"PSM","Week 3 • Tanggal 16–23","PSM_W3"); addWorkdays(body,plTargets,"PSM_W3"); addTargetPeriod(body,plTargets,"PSM","Week 4 • Tanggal 24–akhir bulan","PSM_W4"); addWorkdays(body,plTargets,"PSM_W4");
      addTargetPeriod(body,plTargets,"PWP","Periode 1 • Tanggal 1–15","PWP_P1"); addWorkdays(body,plTargets,"PWP_P1"); addTargetPeriod(body,plTargets,"PWP","Periode 2 • Tanggal 16–akhir bulan","PWP_P2"); addWorkdays(body,plTargets,"PWP_P2");
      addTargetPeriod(body,plTargets,"Serba Gratis","Periode 1 • Tanggal 1–15","SG_P1"); addWorkdays(body,plTargets,"SG_P1"); addTargetPeriod(body,plTargets,"Serba Gratis","Periode 2 • Tanggal 16–akhir bulan","SG_P2"); addWorkdays(body,plTargets,"SG_P2");
      addTargetPeriod(body,plTargets,"SUEGER","Periode 1 • Tanggal 1–15","SUEGER_P1"); addWorkdays(body,plTargets,"SUEGER_P1"); addTargetPeriod(body,plTargets,"SUEGER","Periode 2 • Tanggal 16–akhir bulan","SUEGER_P2"); addWorkdays(body,plTargets,"SUEGER_P2");
      if("admin_utama".equals(currentRole)){Button loadTarget=smallButton("Muat Target Toko");body.addView(loadTarget,field());loadTarget.setOnClickListener(v->{String c=adminCode.getText().toString().trim().toUpperCase(Locale.US);if(c.isEmpty()){toast("Masukkan kode toko.");return;}loadMonthlyPLTargets(targetMonth,plTargets,c);});}
      String initialCode="admin_utama".equals(currentRole)?"":storeCode;
      loadMonthlyPLTargets(targetMonth,plTargets,initialCode);
      Runnable refreshPeriodLocks=()->{
        Calendar now=Calendar.getInstance();boolean currentMonth=targetMonth.getYear()==now.get(Calendar.YEAR)&&targetMonth.getMonth()==now.get(Calendar.MONTH);int today=now.get(Calendar.DAY_OF_MONTH);int last=now.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(String key:plTargets.keySet()){
          String period=key.endsWith("_DAYS")?key.substring(0,key.length()-5):key;
          int end=period.equals("PSM_W1")?7:period.equals("PSM_W2")?15:period.equals("PSM_W3")?23:period.equals("PSM_W4")||period.endsWith("_P2")?last:15;
          EditText field=plTargets.get(key);field.setEnabled(currentMonth&&end>=today);
        }
      };
      refreshPeriodLocks.run();
      setDropdownDatePickerListener(targetMonthSelector,targetMonth,true,refreshPeriodLocks);
      Button savePLTarget=primary("Simpan Target Periode"); body.addView(savePLTarget,field());
      savePLTarget.setOnClickListener(v->{String c="admin_utama".equals(currentRole)?adminCode.getText().toString().trim().toUpperCase(Locale.US):storeCode;String n="admin_utama".equals(currentRole)?c:storeName;if(c.isEmpty()){toast("Masukkan kode toko.");return;}saveMonthlyPLTargets(targetMonth,plTargets,savePLTarget,c,n);});
      TextView plNote=txt("Semua periode ditampilkan. Periode yang sudah selesai dikunci; periode aktif dan periode mendatang pada bulan berjalan dapat disiapkan.",11,BLUE,false); plNote.setBackground(shape(0xffe8f0fc,0,dp(8))); plNote.setPadding(dp(10),dp(10),dp(10),dp(10)); body.addView(plNote,lp(-2));
    }else if(page.equals("Input Target IKT")||page.equals("Input PL")||page.equals("Input PL Crew")||page.equals("Input Toko")){
      boolean target=page.equals("Input Target IKT");boolean pl=page.equals("Input PL")||page.equals("Input PL Crew");
      cardTitle(body,target?"Input Target IKT Bulanan":pl?("crew".equals(currentRole)?"Penawaran Langsung Hari Ini":"Penawaran Langsung Crew") :"Input Data Toko");
      if(target)body.addView(txt("Atur target IKT bulanan toko: Net Sales, Margin %, NSB, APC, dan STD.",12,MUTED,false),field());
      if(pl && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))body.addView(txt("Masukkan NIK Crew yang akan diinput atau diperbarui. Data tersimpan atas nama Crew yang dipilih.",12,MUTED,false),field());
      body.addView(txt(target?"Pilih bulan target":"Tanggal",13,DARK,true));DatePicker date=new DatePicker(this);TextView dateSelector=addDropdownDatePicker(body,date,target,null);
      EditText targetNik=null;
      if(pl&&("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){body.addView(txt("NIK Crew yang diinput (8 angka)",13,DARK,true));targetNik=registerField(body,"Masukkan NIK Crew",InputType.TYPE_CLASS_NUMBER);targetNik.setText(currentNik);}
      String[] labels=target?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:page.equals("Input Toko")?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:new String[]{"PSM","PWP","Serba Gratis","SUEGER"};
      Map<String,EditText> inputs=new HashMap<>();
      for(String key:labels){LinearLayout r=row();r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));r.addView(txt((page.equals("Input Toko")&&key.equals("Net Sales"))?"SPD":key,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));if(isRupiahMetric(key))r.addView(txt("Rp",12,MUTED,true));else if(isDecimalMetric(key))r.addView(txt("%",12,MUTED,true));EditText val=new EditText(this);configureMetricInput(val,key);val.setText("0");val.setEms(5);applyZeroFocusStyle(val);r.addView(val);inputs.put(key,val);LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);body.addView(r,q);}
      final EditText selectedCrewNik=targetNik;
      if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);
      setDropdownDatePickerListener(dateSelector,date,target,()->{if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);});
      Button save=primary(target?"Simpan Target": "Simpan");body.addView(save,field());save.setOnClickListener(v->{if(target)saveMonthlyTarget(date,inputs,save);else saveDailyInput(page,date,inputs,save,selectedCrewNik);});
      TextView note=txt(target?"Target berlaku untuk toko dan bulan yang dipilih.":"Data harian dapat diinput dan dikoreksi kapan saja. Semua indikator wajib diisi; NSB boleh 0. Setiap koreksi dicatat.",11,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(8)));note.setPadding(dp(10),dp(10),dp(10),dp(10));body.addView(note,lp(-2));
    }else if(page.equals("Ranking Crew")){
      LinearLayout.LayoutParams rankingHeaderParams=field();rankingHeaderParams.topMargin=dp(14);body.addView(referenceHeroHeader("RANKING CREW","",R.drawable.ranking_header_trophy),rankingHeaderParams);
      body.addView(txt("Peringkat dihitung dari pencapaian berbobot: PSM 25%, PWP 25%, Serba Gratis 30%, SUEGER 20%.",12,MUTED,false),field());
      DatePicker rankDate=new DatePicker(this);rankDate.setVisibility(View.GONE);body.addView(rankDate,new LinearLayout.LayoutParams(1,1));
      LinearLayout menuRow1=row();menuRow1.setGravity(Gravity.CENTER_VERTICAL);
      LinearLayout menuRow2=row();menuRow2.setGravity(Gravity.CENTER_VERTICAL);
      LinearLayout rankResults=col();
      TextView dateSelector=txt("Pilih Tanggal  ▾",14,DARK,true);dateSelector.setGravity(Gravity.CENTER_VERTICAL);dateSelector.setPadding(dp(14),dp(13),dp(14),dp(13));dateSelector.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));
      Runnable updateDateLabel=()->dateSelector.setText(new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(new GregorianCalendar(rankDate.getYear(),rankDate.getMonth(),rankDate.getDayOfMonth()).getTime()).toUpperCase(new Locale("id","ID"))+"  ▾");
      Runnable showDaily=()->loadCrewRanking(rankResults,rankDate,false);
      Runnable showMonthly=()->loadCrewRanking(rankResults,rankDate,true);
      LinearLayout dailyCard=rankingMenuCard(R.drawable.ic_rank_daily,"Ranking Harian","Peringkat berdasarkan tanggal yang dipilih.",true,showDaily);
      LinearLayout periodCard=rankingMenuCard(R.drawable.ic_rank_period,"Ranking Periode","Mengikuti periode target masing-masing indikator.",false,()->loadCrewRankingAdvanced(rankResults,rankDate,false));
      LinearLayout monthlyCard=rankingMenuCard(R.drawable.ic_rank_monthly,"Ranking Bulanan","Rekap pencapaian selama satu bulan.",false,showMonthly);
      LinearLayout reportCard=rankingMenuCard(R.drawable.ic_rank_report,"Raport Crew","Rekap total pencapaian dalam setahun (Jan–Des).",false,()->loadCrewRankingAdvanced(rankResults,rankDate,true));
      LinearLayout[] rankingMenuCards={dailyCard,periodCard,monthlyCard,reportCard};
      final int[] selectedRankingMode={0};
      Runnable[] rankingMenuActions={showDaily,()->loadCrewRankingAdvanced(rankResults,rankDate,false),showMonthly,()->loadCrewRankingAdvanced(rankResults,rankDate,true)};
      for(int i=0;i<rankingMenuCards.length;i++){final int selected=i;rankingMenuCards[i].setOnClickListener(v->{selectedRankingMode[0]=selected;for(int j=0;j<rankingMenuCards.length;j++)setRankingMenuCardActive(rankingMenuCards[j],j==selected);rankingMenuActions[selected].run();});}
      menuRow1.setPadding(dp(4),0,dp(4),0);menuRow2.setPadding(dp(4),0,dp(4),0);
      menuRow1.addView(dailyCard,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,-2,1);p2.leftMargin=dp(8);menuRow1.addView(periodCard,p2);body.addView(menuRow1,field());
      menuRow2.addView(monthlyCard,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p4=new LinearLayout.LayoutParams(0,-2,1);p4.leftMargin=dp(8);menuRow2.addView(reportCard,p4);body.addView(menuRow2,field());
      body.addView(dateSelector,field());body.addView(rankResults,lp(-2));
      dateSelector.setOnClickListener(v->{DatePickerDialog dialog=new DatePickerDialog(this,(view,y,m,d)->{rankDate.updateDate(y,m,d);updateDateLabel.run();rankingMenuActions[selectedRankingMode[0]].run();},rankDate.getYear(),rankDate.getMonth(),rankDate.getDayOfMonth());dialog.show();});
      updateDateLabel.run();showDaily.run();
    }else if(page.equals("Laporan Sales")){
      showSalesReport(body);
    }else if(page.equals("Laporan Penawaran Langsung Per Periode")){
      showPLPeriodReport(body);
    }else if(page.equals("Laporan Penawaran Langsung Per Bulan")){
      showPLMonthlyReport(body);
    }else if(page.equals("Reward")){
      body.setPadding(0,dp(12),0,dp(14));
      renderRewardPage(body);
    }else if(page.equals("Profil")){
      LinearLayout hero=col();hero.setPadding(0,0,0,dp(14));hero.setBackground(shape(0xffffeff1,0xfff2c5cc,dp(18)));
      FrameLayout bannerFrame=new FrameLayout(this);
      ImageView storeBanner=new ImageView(this);storeBanner.setImageResource(R.drawable.profile_store_banner);storeBanner.setScaleType(ImageView.ScaleType.CENTER_CROP);bannerFrame.addView(storeBanner,new FrameLayout.LayoutParams(-1,dp(155)));
      View profileWave=new View(this){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);Path path=new Path();@Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setStyle(Paint.Style.FILL);path.reset();path.moveTo(0,h*0.28f);path.cubicTo(w*0.22f,-h*0.12f,w*0.34f,h*0.05f,w*0.52f,h*0.32f);path.cubicTo(w*0.72f,h*0.62f,w*0.84f,h*0.46f,w,h*0.12f);path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(0xffc9002b);c.drawPath(path,p);path.reset();path.moveTo(0,h*0.48f);path.cubicTo(w*0.22f,h*0.12f,w*0.36f,h*0.24f,w*0.52f,h*0.48f);path.cubicTo(w*0.72f,h*0.76f,w*0.86f,h*0.66f,w,h*0.34f);path.lineTo(w,h*0.54f);path.cubicTo(w*0.84f,h*0.86f,w*0.70f,h*0.92f,w*0.50f,h*0.65f);path.cubicTo(w*0.32f,h*0.40f,w*0.18f,h*0.35f,0,h*0.68f);path.close();p.setColor(0xffffd21f);c.drawPath(path,p);}};
      bannerFrame.addView(profileWave,new FrameLayout.LayoutParams(-1,dp(46),Gravity.BOTTOM));
      LinearLayout bannerText=col();bannerText.setPadding(dp(16),dp(14),dp(16),0);
      TextView bannerTitle=txt("♙  Profil Personil",20,Color.WHITE,true);bannerText.addView(bannerTitle,lp(-2));
      bannerText.addView(txt("Data lengkap personil Alfamart",12,Color.WHITE,false),lp(-2));
      FrameLayout.LayoutParams textP=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.LEFT);bannerFrame.addView(bannerText,textP);
      TextView monthChip=txt("▣  "+new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(new Date()).toUpperCase(new Locale("id","ID"))+"  ▾",12,DARK,true);monthChip.setPadding(dp(10),dp(6),dp(10),dp(6));monthChip.setBackground(shape(Color.WHITE,Color.WHITE,dp(18)));FrameLayout.LayoutParams monthP=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.TOP);monthP.setMargins(0,dp(10),dp(10),0);bannerFrame.addView(monthChip,monthP);
      hero.addView(bannerFrame,new LinearLayout.LayoutParams(-1,dp(165)));
      FrameLayout profileAvatarFrame=new FrameLayout(this);profileAvatarFrame.setClipChildren(false);profileAvatarFrame.setClipToPadding(false);
      profileAvatar=new ImageView(this);profileAvatar.setImageResource(android.R.drawable.ic_menu_camera);profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);profileAvatar.setBackground(shape(Color.WHITE,Color.WHITE,dp(42)));profileAvatar.setClipToOutline(true);
      FrameLayout.LayoutParams profilePhotoParams=new FrameLayout.LayoutParams(dp(70),dp(70),Gravity.TOP|Gravity.CENTER_HORIZONTAL);profilePhotoParams.topMargin=dp(13);profileAvatarFrame.addView(profileAvatar,profilePhotoParams);
      ImageView profileRoleFrame=new ImageView(this);int profileRoleFrameRes=getRoleProfileFrameResource();if(profileRoleFrameRes!=0){profileRoleFrame.setImageResource(profileRoleFrameRes);profileRoleFrame.setScaleType(ImageView.ScaleType.FIT_CENTER);profileAvatarFrame.addView(profileRoleFrame,new FrameLayout.LayoutParams(-1,-1));}
      LinearLayout.LayoutParams avatarLp=new LinearLayout.LayoutParams(dp(116),dp(116));avatarLp.gravity=Gravity.CENTER_HORIZONTAL;avatarLp.topMargin=dp(-60);hero.addView(profileAvatarFrame,avatarLp);profileAvatar.setOnClickListener(v->chooseProfilePhoto());loadProfilePhoto();
      FrameLayout identity=new FrameLayout(this);identity.setBackgroundColor(0x00ffffff);
      ImageView padiLeft=new ImageView(this);padiLeft.setImageResource(R.drawable.profile_padi_left);padiLeft.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams padiLP=new FrameLayout.LayoutParams(dp(58),dp(104),Gravity.LEFT|Gravity.CENTER_VERTICAL);padiLP.leftMargin=dp(22);identity.addView(padiLeft,padiLP);
      ImageView padiRight=new ImageView(this);padiRight.setImageResource(R.drawable.profile_padi_right);padiRight.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams padiRP=new FrameLayout.LayoutParams(dp(58),dp(104),Gravity.RIGHT|Gravity.CENTER_VERTICAL);padiRP.rightMargin=dp(22);identity.addView(padiRight,padiRP);
      TextView name=center(currentName,18,DARK,true);FrameLayout.LayoutParams nameP=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);nameP.topMargin=dp(2);identity.addView(name,nameP);
      TextView roleChip=center(roleLabel(),13,0xff5b3900,true);roleChip.setPadding(dp(14),dp(6),dp(14),dp(6));roleChip.setBackground(shape(0xffffe7a3,0xffffd36a,dp(20)));FrameLayout.LayoutParams roleP=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);roleP.topMargin=dp(36);identity.addView(roleChip,roleP);
      TextView storeChip=center((storeCode==null?"":storeCode)+" - "+(storeName==null?"":storeName),14,Color.WHITE,true);storeChip.setPadding(dp(16),dp(7),dp(16),dp(7));storeChip.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_myplaces,0,0,0);storeChip.setBackground(shape(RED,RED,dp(20)));FrameLayout.LayoutParams storeP=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);storeP.topMargin=dp(82);identity.addView(storeChip,storeP);

      hero.addView(identity,new LinearLayout.LayoutParams(-1,dp(128)));body.addView(hero,field());
      LinearLayout info=col();info.setPadding(dp(10),dp(6),dp(10),dp(6));info.setBackground(shape(Color.WHITE,0xffe6e9ef,dp(16)));info.setElevation(dp(3));
      String[][] rows={{"▣","NIK",currentNik.isEmpty()?"Admin Utama":currentNik},{"●","Username",currentNik.isEmpty()?"Admin Utama":currentNik},{"▰","Jabatan",roleLabel()},{"▤","Kode Toko",storeCode},{"▦","Nama Toko",storeName},{"◆","Jenis Toko","24_JAM".equals(storeType)?"24 Jam":"NORMAL".equals(storeType)?"Normal":"Belum diatur"}};
      int[] profileIconIds={R.drawable.profile_icon_nik,R.drawable.profile_icon_user,R.drawable.profile_icon_job,R.drawable.profile_icon_store,R.drawable.profile_icon_building,R.drawable.profile_icon_layers};
      for(int i=0;i<rows.length;i++){LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(2),dp(3),dp(2),dp(3));ImageView ic=new ImageView(this);ic.setImageResource(profileIconIds[i]);ic.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams icP=new LinearLayout.LayoutParams(dp(38),dp(38));icP.rightMargin=dp(9);r.addView(ic,icP);r.addView(txt(rows[i][1],14,DARK,false),new LinearLayout.LayoutParams(0,-2,1));TextView val=txt(rows[i][2]==null?"-":rows[i][2],14,DARK,true);val.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);val.setSingleLine(true);val.setEllipsize(android.text.TextUtils.TruncateAt.END);r.addView(val,new LinearLayout.LayoutParams(-2,-2));info.addView(r,lp(-2));if(i<rows.length-1){View line=new View(this);line.setBackgroundColor(0xffeeeeee);info.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}}
      body.addView(info,field());
      if(!currentNik.isEmpty()){Button career=profileActionButton("🏅","Jenjang Karir / Ajukan Kenaikan");body.addView(career,field());career.setOnClickListener(v->showCareerRequest());}
      if(!currentNik.isEmpty()){Button changePin=profileActionButton("🔒","Ubah PIN");body.addView(changePin,field());changePin.setOnClickListener(v->showChangePinDialog());}
      Button out=profileActionButton("⇥","Keluar");body.addView(out,field());out.setOnClickListener(v->{if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();});
      TextView version=center("ⓘ  Versi Aplikasi : "+BuildConfig.VERSION_NAME,13,0xff8d2338,true);version.setPadding(dp(12),dp(6),dp(12),dp(6));version.setBackground(shape(0xffffeef0,0xfff3c0c6,dp(22)));LinearLayout.LayoutParams versionLp=lp(-2);versionLp.gravity=Gravity.CENTER_HORIZONTAL;versionLp.topMargin=dp(4);body.addView(version,versionLp);
    }else if(page.equals("Verifikasi Pendaftaran")){
      cardTitle(body,"Verifikasi Pendaftaran Personil");loadPendingRegistrations(body);
    }else if(page.equals("Permohonan Karir")){
      cardTitle(body,"Persetujuan Jenjang Karir");loadPendingCareer(body);
    }else if(page.equals("Mutasi Personil")){
      cardTitle(body,"Mutasi Personil Antar Toko");EditText mn=registerField(body,"NIK Personil (8 angka)",InputType.TYPE_CLASS_NUMBER);EditText mc=registerField(body,"Kode Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);EditText ms=registerField(body,"Nama Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);Button move=primary("Proses Mutasi");body.addView(move,field());move.setOnClickListener(v->processMutation(mn.getText().toString().trim(),mc.getText().toString().trim().toUpperCase(Locale.US),ms.getText().toString().trim()));body.addView(txt("Mutasi memperbarui toko aktif dan mencatat riwayat toko sebelumnya. Hanya Admin Utama.",12,BLUE,false),field());
    }else if(page.equals("Laporan Penjualan")||page.equals("Laporan")){
      showSalesReportMenu(body);
    }else if(page.equals("Laporan Penawaran Langsung Sementara")){
      cardTitle(body,"Laporan Penawaran Langsung Sementara");
      body.addView(txt("Pilih rentang tanggal laporan. JHK dihitung dari jumlah tanggal dalam rentang yang dipilih, termasuk tanggal awal dan akhir.",12,MUTED,false),field());
      Calendar rangeNow=Calendar.getInstance();DatePicker reportStart=new DatePicker(this);reportStart.updateDate(rangeNow.get(Calendar.YEAR),rangeNow.get(Calendar.MONTH),1);
      DatePicker reportEnd=new DatePicker(this);reportEnd.updateDate(rangeNow.get(Calendar.YEAR),rangeNow.get(Calendar.MONTH),rangeNow.get(Calendar.DAY_OF_MONTH));
      body.addView(txt("Tanggal Awal",13,DARK,true),lp(-2));TextView startSelector=addDropdownDatePicker(body,reportStart,false,null);
      body.addView(txt("Tanggal Akhir",13,DARK,true),lp(-2));TextView endSelector=addDropdownDatePicker(body,reportEnd,false,null);
      Button refresh=primary("Tampilkan Laporan");body.addView(refresh,field());
      LinearLayout reportResults=col();
      refresh.setOnClickListener(v->loadPLReport(reportResults,reportStart,reportEnd));
      DatePicker.OnDateChangedListener clearUntilSubmit=(view,year,monthOfYear,day)->reportResults.removeAllViews();
      reportStart.init(reportStart.getYear(),reportStart.getMonth(),reportStart.getDayOfMonth(),clearUntilSubmit);
      reportEnd.init(reportEnd.getYear(),reportEnd.getMonth(),reportEnd.getDayOfMonth(),clearUntilSubmit);
      body.addView(reportResults,lp(-2));
    }else{
      cardTitle(body,page);body.addView(txt("Halaman ini disiapkan mengikuti desain referensi. Data dan fungsi operasional akan dihubungkan bertahap.",14,MUTED,false));
    }
    LinearLayout nav=row();nav.setGravity(Gravity.CENTER);nav.setClipChildren(false);nav.setClipToPadding(false);nav.setBackground(shape(Color.WHITE,0xffedf0f5,dp(24)));nav.setElevation(dp(12));nav.setPadding(dp(4),dp(2),dp(4),dp(2));String[][] tabs={{"home","Beranda"},{"ticket","Input PL"},{"trophy","Ranking Crew"},{"report","Laporan Penjualan"},{"profile","Profil"}};int[] navIcons={R.drawable.nav_icon_home,R.drawable.nav_icon_ticket,R.drawable.nav_icon_trophy,R.drawable.nav_icon_report,R.drawable.nav_icon_profile};for(int ti=0;ti<tabs.length;ti++){String t=tabs[ti][1];boolean active=t.equals(page)||("Input PL".equals(t)&&"Input PL Crew".equals(page));LinearLayout item=col();item.setGravity(Gravity.CENTER);item.setClipChildren(false);item.setClipToPadding(false);item.setPadding(0,0,0,0);item.setClickable(true);item.setFocusable(true);if(ti==2){FrameLayout centerCircle=new FrameLayout(this);centerCircle.setBackground(shape(RED,0xffd8a0aa,dp(50)));centerCircle.setElevation(dp(10));LinearLayout centerContent=col();centerContent.setGravity(Gravity.CENTER);centerContent.setClipChildren(false);centerContent.setClipToPadding(false);ImageView trophy=new ImageView(this);trophy.setImageResource(R.drawable.nav_icon_trophy);trophy.setScaleType(ImageView.ScaleType.FIT_CENTER);trophy.setColorFilter(active?Color.WHITE:0xffb8bec7);LinearLayout.LayoutParams trophyLp=new LinearLayout.LayoutParams(dp(34),dp(34));trophyLp.bottomMargin=dp(1);centerContent.addView(trophy,trophyLp);TextView centerLabel=center("Ranking Crew",8,active?Color.WHITE:0xffb8bec7,true);centerLabel.setMaxLines(2);centerLabel.setGravity(Gravity.CENTER);centerContent.addView(centerLabel,lp(-2));centerCircle.addView(centerContent,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));LinearLayout.LayoutParams circleParams=new LinearLayout.LayoutParams(dp(76),dp(76));circleParams.topMargin=dp(-17);item.addView(centerCircle,circleParams);}else{ImageView ico=new ImageView(this);ico.setImageResource(navIcons[ti]);ico.setColorFilter(active?RED:MUTED);ico.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(19),dp(19));iconLp.bottomMargin=dp(2);item.addView(ico,iconLp);TextView label=center(t,8,active?RED:MUTED,true);label.setMaxLines(2);label.setGravity(Gravity.CENTER);item.addView(label,lp(-2));}nav.addView(item,new LinearLayout.LayoutParams(0,dp(48),1));item.setOnClickListener(v->showDashboard(("Input PL".equals(t)&&("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))?"Input PL Crew":t));}LinearLayout.LayoutParams navParams=new LinearLayout.LayoutParams(-1,dp(62));navParams.setMargins(dp(10),dp(4),dp(10),dp(9));shell.addView(nav,navParams);screen.addView(shell,new FrameLayout.LayoutParams(-1,-1));setContentView(screen);
  }

  // Seluruh logika berikut khusus halaman Laporan Penawaran Langsung Per Bulan.
  private void showPLMonthlyReport(LinearLayout body){
    LinearLayout intro=col();intro.setPadding(dp(5),dp(4),dp(5),dp(8));
    intro.addView(txt("Laporan Penawaran Langsung Per Bulan",20,DARK,true),field());
    intro.addView(txt("Rekap pencapaian indikator penawaran langsung bulanan dengan bobot penilaian ACV.",12,BLUE,false));body.addView(intro,lp(-2));
    Calendar now=Calendar.getInstance();Spinner month=new Spinner(this),year=new Spinner(this);
    String[] months={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};
    month.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,months));month.setSelection(now.get(Calendar.MONTH));
    ArrayList<String> years=new ArrayList<>();for(int y=now.get(Calendar.YEAR)-3;y<=now.get(Calendar.YEAR)+1;y++)years.add(String.valueOf(y));
    year.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,years));year.setSelection(years.indexOf(String.valueOf(now.get(Calendar.YEAR))));
    LinearLayout selectors=row();selectors.addView(month,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams yp=new LinearLayout.LayoutParams(0,dp(48),1);yp.leftMargin=dp(8);selectors.addView(year,yp);body.addView(selectors,field());
    Button show=primary("▥  TAMPILKAN LAPORAN");body.addView(show,field());LinearLayout results=col();body.addView(results,lp(-2));
    month.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){results.removeAllViews();}});
    year.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){results.removeAllViews();}});
    show.setOnClickListener(v->{int y=Integer.parseInt(String.valueOf(year.getSelectedItem()));int m=month.getSelectedItemPosition()+1;loadPLMonthlyData(results,y,m);});
  }
  private void loadPLMonthlyData(LinearLayout out,int year,int month){
    out.removeAllViews();if(db==null){out.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!("crew".equals(currentRole)||"acos".equals(currentRole)||"cos".equals(currentRole)||"admin_utama".equals(currentRole))){out.addView(txt("Akses laporan tidak tersedia untuk jabatan ini.",13,RED,true),field());return;}
    Calendar cal=Calendar.getInstance();String from=String.format(Locale.US,"%04d%02d01",year,month);int last=cal.getActualMaximum(Calendar.DAY_OF_MONTH);if(year==cal.get(Calendar.YEAR)&&month==cal.get(Calendar.MONTH)+1)last=cal.get(Calendar.DAY_OF_MONTH);String to=String.format(Locale.US,"%04d%02d%02d",year,month,last);String mk=String.format(Locale.US,"%04d%02d",year,month);
    out.addView(txt("Memuat laporan bulan...",12,MUTED,false),field());Query pl=db.collection("DailyPLReports").whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    Query toko=db.collection("DailyStoreReports").whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    if(!"admin_utama".equals(currentRole)){pl=pl.whereEqualTo("storeCode",storeCode);toko=toko.whereEqualTo("storeCode",storeCode);}
    final int yy=year,mm=month;final Query plQuery=pl;final Query storeQuery=toko;plQuery.get().addOnSuccessListener(plSnap->storeQuery.get().addOnSuccessListener(storeSnap->{
      double[] actual={0,0,0};double apcSum=0;int apcCount=0;java.util.HashSet<String> stores=new java.util.HashSet<>();if(!"admin_utama".equals(currentRole)&&storeCode!=null&&!storeCode.isEmpty())stores.add(storeCode);
      for(DocumentSnapshot d:plSnap.getDocuments()){String c=d.getString("storeCode");if(c!=null&&!c.isEmpty())stores.add(c);actual[0]+=num(d.get("PSM"));actual[1]+=num(d.get("PWP"));actual[2]+=num(d.get("Serba Gratis"));}
      for(DocumentSnapshot d:storeSnap.getDocuments()){String c=d.getString("storeCode");if(c!=null&&!c.isEmpty())stores.add(c);Object a=d.get("APC");if(a!=null&&!String.valueOf(a).trim().isEmpty()){apcSum+=num(a);apcCount++;}}
      if(stores.isEmpty()){out.removeAllViews();out.addView(txt("Belum ada data laporan untuk bulan yang dipilih.",13,MUTED,false),field());return;}
      final double avgApc=apcCount==0?0:apcSum/apcCount;final double[] targets={0,0,0};final double[] apcTarget={0};final int[] pending={stores.size()*2};final boolean[] failed={false};
      Runnable finish=()->{if(--pending[0]!=0)return;out.removeAllViews();double[] pct=new double[4];for(int i=0;i<3;i++)pct[i]=targets[i]>0?actual[i]/targets[i]*100:0;double finalApcTarget=stores.isEmpty()?0:apcTarget[0]/stores.size();pct[3]=finalApcTarget>0?avgApc/finalApcTarget*100:0;double acv=pct[0]*.20+pct[1]*.25+pct[2]*.30+pct[3]*.25;renderPLMonthlyTable(out,yy,mm,targets,actual,finalApcTarget,avgApc,pct,acv,failed[0]);};
      for(String code:stores){db.collection("MonthlyPLTargets").document(code+"_"+mk).get().addOnSuccessListener(d->{if(d.exists()){targets[0]+=num(d.get("PSM_W1"))+num(d.get("PSM_W2"))+num(d.get("PSM_W3"))+num(d.get("PSM_W4"));targets[1]+=num(d.get("PWP_P1"))+num(d.get("PWP_P2"));targets[2]+=num(d.get("SG_P1"))+num(d.get("SG_P2"));}else failed[0]=true;finish.run();}).addOnFailureListener(e->{failed[0]=true;finish.run();});
        db.collection("MonthlyIKTTargets").document(code+"_"+mk).get().addOnSuccessListener(d->{if(d.exists())apcTarget[0]+=num(d.get("APC"));else failed[0]=true;finish.run();}).addOnFailureListener(e->{failed[0]=true;finish.run();});}
    }).addOnFailureListener(e->{out.removeAllViews();out.addView(txt("Gagal membaca DailyStoreReports: "+e.getLocalizedMessage(),12,RED,false),field());})).addOnFailureListener(e->{out.removeAllViews();out.addView(txt("Gagal membaca DailyPLReports: "+e.getLocalizedMessage(),12,RED,false),field());});
  }
  private void renderPLMonthlyTable(LinearLayout out,int year,int month,double[] target,double[] actual,double apcTarget,double avgApc,double[] pct,double acv,boolean failed){
    LinearLayout card=col();card.setPadding(dp(12),dp(12),dp(12),dp(12));card.setBackground(shape(Color.WHITE,0xffcbd3e2,dp(18)));
    String title=String.format(Locale.forLanguageTag("id-ID"),"Laporan Bulan: %1$tB %1$tY",new GregorianCalendar(year,month-1,1).getTime());card.addView(txt("▦  "+title,16,DARK,true),field());
    LinearLayout head=row();head.setPadding(dp(4),dp(8),dp(4),dp(8));head.setBackground(shape(0xffedf0f8,0,dp(10)));String[] h={"Indikator","Bobot","Target","Actual","Pencapaian"};float[] w={1.25f,.65f,.85f,.85f,1.05f};for(int i=0;i<h.length;i++){TextView t=center(h[i],10,DARK,true);head.addView(t,new LinearLayout.LayoutParams(0,-2,w[i]));}card.addView(head,field());
    String[] labels={"🔖  PSM","🛒  PWP","🎁  SERBA GRATIS","🎯  APC"};String[] weights={"20%","25%","30%","25%"};for(int i=0;i<4;i++){LinearLayout r=row();r.setPadding(dp(4),dp(10),dp(4),dp(10));r.setBackground(shape(Color.WHITE,0xffe5e9f1,dp(10)));TextView n=txt(labels[i],i==3?9:12,DARK,true);r.addView(n,new LinearLayout.LayoutParams(0,-2,w[0]));r.addView(center(weights[i],11,DARK,i==3),new LinearLayout.LayoutParams(0,-2,w[1]));String tv=i==3?"Rp"+formatGroupedInteger(apcTarget):formatGroupedInteger(target[i]);String av=i==3?"Rp"+formatGroupedInteger(avgApc):formatGroupedInteger(actual[i]);r.addView(center(tv,10,DARK,false),new LinearLayout.LayoutParams(0,-2,w[2]));r.addView(center(av,10,DARK,false),new LinearLayout.LayoutParams(0,-2,w[3]));TextView p=center(String.format(new Locale("id","ID"),"%.2f%%",pct[i]),11,achievementColor(String.format(Locale.US,"%.2f",pct[i])+"%"),true);p.setBackground(shape(0xffffe66b,0,dp(18)));p.setPadding(dp(3),dp(6),dp(3),dp(6));r.addView(p,new LinearLayout.LayoutParams(0,-2,w[4]));LinearLayout.LayoutParams rp=lp(-2);rp.bottomMargin=dp(3);card.addView(r,rp);}
    LinearLayout total=row();total.setPadding(dp(4),dp(10),dp(4),dp(10));total.setBackground(gradient(0xffd5001e,0xffed142c,dp(10)));total.addView(txt("TOTAL INDIKATOR",9,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,w[0]));total.addView(center("100%",11,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,w[1]));total.addView(center("—",11,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,w[2]));total.addView(center("—",11,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,w[3]));TextView av=center(String.format(new Locale("id","ID"),"%.2f%%",acv),13,achievementColor(String.format(Locale.US,"%.2f",acv)+"%"),true);av.setBackground(shape(0xffffe66b,0,dp(18)));av.setPadding(dp(4),dp(6),dp(4),dp(6));total.addView(av,new LinearLayout.LayoutParams(0,-2,w[4]));card.addView(total,field());
    LinearLayout motivation=col();motivation.setPadding(dp(14),dp(16),dp(14),dp(16));motivation.setBackground(shape(0xfffff7df,0xffffc52e,dp(16)));motivation.addView(center("🎯  Pencapaian ACV : "+String.format(new Locale("id","ID"),"%.2f%%",acv),14,RED,true),field());String headline,detail;if(acv<90){headline="Jangan Menyerah, Perjuangkan Targetmu!";detail="Pencapaian bulan ini masih di bawah ACV. Evaluasi hasil, perkuat penawaran PSM, PWP, Serba Gratis, dan tingkatkan Average APC.\nTetap semangat, konsisten, dan pastikan bulan depan bisa ACV! 💪";}else if(acv<100){headline="Sedikit Lagi Menuju ACV!";detail="Pencapaian sudah semakin dekat dengan ACV. Tingkatkan konsistensi penawaran PSM, PWP, Serba Gratis, dan Average APC.\nTerus semangat, sedikit lagi target ACV 100% tercapai! 💪";}else if(acv==100){headline="Selamat! ACV Berhasil Tercapai!";detail="Kerja keras dan konsistensi membuahkan hasil. Pertahankan kualitas penawaran PSM, PWP, Serba Gratis, dan Average APC.\nTerus jaga performa dan raih pencapaian terbaik berikutnya! 🏆";}else{headline="Luar Biasa! ACV Terlampaui!";detail="Selamat atas pencapaian yang melampaui target ACV. Pertahankan konsistensi dan jangan cepat puas.\nTerus tingkatkan performa dan jadikan pencapaian hebat ini standar berikutnya! 💪";}motivation.addView(center(headline,17,0xff9f1827,true),field());motivation.addView(txt(detail,12,DARK,false),lp(-2));LinearLayout.LayoutParams mp=field();mp.topMargin=dp(10);card.addView(motivation,mp);out.addView(card,field());if(failed)out.addView(txt("Catatan: sebagian target belum ditemukan atau gagal dibaca. Periksa target bulan yang dipilih.",11,RED,false),field());
  }

  private View referenceHeroHeader(String title,String subtitle,int iconRes){
    FrameLayout frame=new FrameLayout(this);
    frame.setBackground(gradient(0xffc9002b,0xffe3132d,dp(22)));
    frame.setClipToOutline(true);
    frame.setElevation(dp(3));
    LinearLayout content=row();
    content.setGravity(Gravity.CENTER_VERTICAL);
    content.setPadding(dp(14),dp(4),dp(14),dp(12));
    ImageView icon=new ImageView(this);
    icon.setImageResource(iconRes);
    icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
    content.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
    View divider=new View(this);
    divider.setBackgroundColor(0xccffffff);
    LinearLayout.LayoutParams dividerParams=new LinearLayout.LayoutParams(dp(1),dp(50));
    dividerParams.setMargins(dp(10),0,dp(14),0);
    content.addView(divider,dividerParams);
    LinearLayout words=col();
    words.setGravity(Gravity.CENTER_VERTICAL);
    words.addView(txt(title,22,Color.WHITE,true));
    if(subtitle!=null&&!subtitle.isEmpty()){
      TextView sub=txt(subtitle,12,Color.WHITE,false);
      sub.setPadding(0,dp(3),0,0);
      words.addView(sub);
    }
    content.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    frame.addView(content,new FrameLayout.LayoutParams(-1,-1));
    View wave=new View(this){
      Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
      Path path=new Path();
      @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setColor(0x55ff7b9a);
        paint.setStrokeWidth(dp(10));
        path.reset();
        path.moveTo(-dp(5),h-dp(19));
        path.cubicTo(w*.28f,h-dp(2),w*.55f,h-dp(36),w*.78f,h-dp(28));
        path.cubicTo(w*.90f,h-dp(23),w*.96f,h-dp(8),w+dp(8),h-dp(16));
        canvas.drawPath(path,paint);
        paint.setColor(0xffffd21f);
        paint.setStrokeWidth(dp(6));
        path.reset();
        path.moveTo(-dp(5),h-dp(11));
        path.cubicTo(w*.28f,h+dp(1),w*.55f,h-dp(24),w*.78f,h-dp(17));
        path.cubicTo(w*.90f,h-dp(12),w*.96f,h-dp(1),w+dp(8),h-dp(8));
        canvas.drawPath(path,paint);
      }
    };
    frame.addView(wave,new FrameLayout.LayoutParams(-1,dp(24),Gravity.BOTTOM));
    frame.setMinimumHeight(dp(88));
    return frame;
  }


  // Reward IKT — native Android renderer; seluruh angka dan roster tetap dinamis dari Firestore.
  // Net Sales menentukan kategori; Margin >=100% adalah syarat wajib. NSB/APC/STD tidak menentukan Reward.
  private void renderRewardPage(LinearLayout body){
    if(adminMode || "admin_utama".equals(currentRole)){
      renderRewardAdminAllStores(body,rewardSelectedMonth.get(Calendar.YEAR),rewardSelectedMonth.get(Calendar.MONTH));
      return;
    }
    if(db==null){body.addView(rewardMessageCard("DATABASE BELUM SIAP","Reward IKT tidak dapat dimuat.",0xfffff3e8,RED),field());return;}
    final int year=rewardSelectedMonth.get(Calendar.YEAR), month=rewardSelectedMonth.get(Calendar.MONTH);
    final String monthKey=String.format(Locale.US,"%04d%02d",year,month+1);
    final String code=storeCode==null?"":storeCode.trim();
    if(code.isEmpty()){body.addView(rewardMessageCard("TOKO BELUM TERDETEKSI","Kode toko akun aktif tidak tersedia.",0xfffff3e8,RED),field());return;}
    LinearLayout page=col();page.setPadding(0,dp(4),0,dp(10));page.setClipChildren(false);page.setClipToPadding(false);body.addView(page,lp(-1));
    TextView title=txt("▏Reward IKT",21,DARK,true);page.addView(title,field());
    LinearLayout loading=rewardCard();loading.setGravity(Gravity.CENTER);loading.addView(txt("Memuat pencapaian dan penerima Reward IKT...",12,MUTED,false),field());page.addView(loading,field());
    db.collection("DailyStoreReports").whereEqualTo("storeCode",code).get().addOnSuccessListener(reports->{
      double actualSales=0,marginSum=0;int reportCount=0;
      for(DocumentSnapshot d:reports.getDocuments()){
        String key=d.getString("dateKey");
        if(key==null||!key.matches("\\d{8}")||!key.startsWith(monthKey))continue;
        actualSales+=num(d.get("Net Sales"));marginSum+=num(d.get("Margin %"));reportCount++;
      }
      final double sales=actualSales,avgMargin=reportCount==0?0:marginSum/reportCount;final int reportsCount=reportCount;
      db.collection("MonthlyIKTTargets").document(code+"_"+monthKey).get().addOnSuccessListener(target->{
        double targetSales=target.exists()?num(target.get("Net Sales")):0;
        double targetMargin=target.exists()?num(target.get("Margin %")):0;
        double salesPct=targetSales>0?sales/targetSales*100.0:0;
        double marginPct=targetMargin>0?avgMargin/targetMargin*100.0:0;
        boolean ready=targetSales>0&&targetMargin>0&&reportsCount>0;
        boolean eligible=ready&&salesPct>=100.0&&marginPct>=100.0;
        Calendar now=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"),new Locale("id","ID"));
        boolean closed=now.get(Calendar.YEAR)>year||(now.get(Calendar.YEAR)==year&&now.get(Calendar.MONTH)>month);
        String category=salesPct>105.0?"MAXIMAL":(salesPct>=102.6&&salesPct<=105.0?"MIDDLE":(salesPct>=100.0&&salesPct<=102.5?"MINIMAL":""));
        int[] amounts="MAXIMAL".equals(category)?new int[]{750000,500000,200000}:"MIDDLE".equals(category)?new int[]{500000,300000,150000}:new int[]{300000,200000,100000};
        db.collection("Stores").document(code).collection("Users").get().addOnSuccessListener(users->{
          ArrayList<DocumentSnapshot> roster=new ArrayList<>();
          for(DocumentSnapshot u:users.getDocuments()){
            if(!Boolean.TRUE.equals(u.getBoolean("isActive")))continue;
            String role=firstNonEmpty(u.getString("role"),"").toLowerCase(Locale.ROOT);
            if("cos".equals(role)||"acos".equals(role)||"crew".equals(role))roster.add(u);
          }
          Collections.sort(roster,(a,b)->rewardRoleOrder(a.getString("role"))-rewardRoleOrder(b.getString("role")));
          int cos=0,acos=0,crew=0;for(DocumentSnapshot u:roster){String r=firstNonEmpty(u.getString("role"),"").toLowerCase(Locale.ROOT);if("cos".equals(r))cos++;else if("acos".equals(r))acos++;else crew++;}
          int total=eligible?(cos*amounts[0]+acos*amounts[1]+crew*amounts[2]):0;
          page.removeAllViews();
          page.addView(title,field());
          String bannerTitle,bannerSub,bannerIcon;
          if(closed){bannerTitle=eligible?"MENANG IKT":"SYARAT REWARD BELUM TERPENUHI";bannerSub="HASIL FINAL PERIODE";bannerIcon=eligible?"🏆":"✖";}
          else {bannerTitle=eligible?"SYARAT REWARD TERPENUHI":"SYARAT REWARD BELUM TERPENUHI";bannerSub="▦  DALAM PROGRES";bannerIcon=eligible?"🏆":"✖";}
          page.addView(rewardHero(bannerTitle,bannerSub,eligible,closed,bannerIcon),field());
          page.addView(rewardStatusPanel(salesPct,marginPct),field());
          page.addView(rewardTierPanel(category,eligible,closed,amounts),field());
          page.addView(rewardRecipientsPanel(roster,eligible,amounts,total,category,closed,code,monthKey),field());
        }).addOnFailureListener(e->{page.removeAllViews();page.addView(title,field());page.addView(rewardMessageCard("GAGAL MEMUAT PERSONIL",e.getLocalizedMessage(),0xffffeeee,RED),field());});
      }).addOnFailureListener(e->{page.removeAllViews();page.addView(title,field());page.addView(rewardMessageCard("GAGAL MEMUAT TARGET",e.getLocalizedMessage(),0xffffeeee,RED),field());});
    }).addOnFailureListener(e->{page.removeAllViews();page.addView(title,field());page.addView(rewardMessageCard("GAGAL MEMUAT LAPORAN",e.getLocalizedMessage(),0xffffeeee,RED),field());});
  }


  private int rewardRoleOrder(String role){String r=role==null?"":role.toLowerCase(Locale.ROOT);return "cos".equals(r)?0:("acos".equals(r)?1:2);}
  private LinearLayout rewardCard(){LinearLayout c=col();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(shape(Color.WHITE,0xffffd15b,dp(18)));c.setElevation(dp(2));return c;}
  private View rewardHero(String heading,String sub,boolean eligible,boolean closed,String icon){
    LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setPadding(dp(14),dp(16),dp(14),dp(16));
    GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff8e0019,0xffe00028,0xff99001c});bg.setCornerRadius(dp(24));bg.setStroke(dp(2),0xffffcf36);box.setBackground(bg);box.setElevation(dp(3));
    TextView stars=center(eligible?"✦   ★ ★ ★   ✦":"✦   ✕   ✦",22,0xffffd84a,true);box.addView(stars,lp(-2));
    TextView h=center(heading,22,eligible?0xffffe56a:Color.WHITE,true);h.setShadowLayer(dp(3),0,dp(2),0xff52000d);h.setMaxLines(2);box.addView(h,field());
    TextView ribbon=center(sub,15,0xffa90020,true);ribbon.setPadding(dp(18),dp(6),dp(18),dp(6));ribbon.setBackground(shape(Color.WHITE,0xffffd85b,dp(18)));box.addView(ribbon,lp(-2));
    String detail=closed?(eligible?"Toko berhasil memenuhi seluruh syarat dan berhak mendapatkan Reward IKT.":"Toko belum memenuhi syarat untuk mendapatkan reward IKT pada periode ini."):(eligible?"Pencapaian IKT toko telah memenuhi syarat reward. Hasil final ditetapkan setelah periode berakhir.":"Pencapaian IKT toko saat ini masih di bawah syarat. Penuhi syarat reward sebelum periode berakhir.");
    TextView d=center(detail,12,Color.WHITE,false);d.setPadding(dp(8),dp(8),dp(8),0);d.setMaxLines(3);box.addView(d,lp(-2));return box;
  }
  private View rewardStatusPanel(double sales,double margin){
    LinearLayout outer=rewardCard();outer.setPadding(dp(8),dp(14),dp(8),dp(12));TextView cap=center("▥  Status IKT Toko",16,Color.WHITE,true);cap.setPadding(dp(18),dp(5),dp(18),dp(5));cap.setBackground(gradient(0xffa90020,0xffe0002d,dp(18)));LinearLayout.LayoutParams cp=lp(-2);cp.gravity=Gravity.CENTER;outer.addView(cap,cp);
    LinearLayout row=row();LinearLayout a=col(),b=col();a.setGravity(Gravity.CENTER);b.setGravity(Gravity.CENTER);a.addView(txt("🛒  Pencapaian Net Sales",12,DARK,true),lp(-2));a.addView(center(pct(sales,2),25,achievementColor(pct(sales,2)),true),lp(-2));b.addView(txt("🪙  Pencapaian Margin",12,DARK,true),lp(-2));b.addView(center(pct(margin,2),25,achievementColor(pct(margin,2)),true),lp(-2));row.addView(a,new LinearLayout.LayoutParams(0,-2,1));View divider=new View(this);divider.setBackgroundColor(0xffffd15b);row.addView(divider,new LinearLayout.LayoutParams(dp(1),dp(52)));row.addView(b,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams rp=field();rp.topMargin=dp(8);outer.addView(row,rp);return outer;
  }
  private View rewardTierPanel(String category,boolean eligible,boolean closed,int[] amounts){
    LinearLayout outer=rewardCard();outer.setPadding(dp(8),dp(8),dp(8),dp(10));TextView heading=center("🎁  Kategori Reward",17,Color.WHITE,true);heading.setPadding(dp(10),dp(8),dp(10),dp(8));heading.setBackground(gradient(0xffa90020,0xffe0002d,dp(14)));outer.addView(heading,lp(-1));TextView condition=center(eligible?"✓  Syarat Tercapai":"✕  Syarat Belum Tercapai",12,eligible?0xff176b36:0xffa90020,true);condition.setPadding(0,dp(8),0,dp(4));outer.addView(condition,lp(-2));
    TextView tier=center("Kategori Reward ("+(closed?"Final Periode":"Sementara")+")",14,DARK,true);tier.setPadding(dp(12),dp(5),dp(12),dp(5));tier.setBackground(shape(0xffffd32b,0xffffa900,dp(18)));LinearLayout.LayoutParams tp=lp(-2);tp.gravity=Gravity.CENTER;outer.addView(tier,tp);
    TextView status=center(eligible?category:(closed?"TIDAK MEMENUHI SYARAT":"BELUM MEMENUHI SYARAT"),20,Color.WHITE,true);status.setPadding(dp(10),dp(8),dp(10),dp(8));status.setBackground(gradient(eligible?0xffa90020:0xff303039,eligible?0xffe0002d:0xff55555d,dp(24)));LinearLayout.LayoutParams sp=field();sp.topMargin=dp(6);outer.addView(status,sp);
    LinearLayout roles=row();String[] names={"COS","ACOS","CREW"};for(int i=0;i<3;i++){LinearLayout c=col();c.setGravity(Gravity.CENTER);TextView n=center(names[i],15,DARK,true);n.setPadding(dp(12),dp(5),dp(12),dp(5));n.setBackground(shape(i==0?0xffffd32b:(i==1?0xffd9dce2:0xffffa64b),0xffd5a52b,dp(20)));c.addView(n,lp(-2));c.addView(center(eligible?formatRupiah(amounts[i]):"—",14,eligible?0xffb00024:DARK,true),field());roles.addView(c,new LinearLayout.LayoutParams(0,-2,1));if(i<2){View line=new View(this);line.setBackgroundColor(0xffffd15b);roles.addView(line,new LinearLayout.LayoutParams(dp(1),dp(54)));}}LinearLayout.LayoutParams rp=field();rp.topMargin=dp(8);outer.addView(roles,rp);return outer;
  }
  private View rewardRecipientsPanel(ArrayList<DocumentSnapshot> roster,boolean eligible,int[] amounts,int total,String category,boolean closed,String code,String monthKey){
    LinearLayout card=col();card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(shape(Color.WHITE,0xffe0e3e9,dp(20)));card.setElevation(dp(2));TextView heading=txt("👥  Penerima Reward",17,Color.WHITE,true);heading.setPadding(dp(12),dp(8),dp(12),dp(8));heading.setBackground(gradient(0xffa90020,0xffe0002d,dp(18)));card.addView(heading,lp(-1));
    LinearLayout summary=row();LinearLayout left=col();left.addView(txt("Penerima Reward ("+(eligible?roster.size():0)+" Personil)",13,0xffa90020,true),lp(-2));left.addView(txt(eligible?"Seluruh personil aktif di Toko "+code:"Belum ada personil yang memenuhi syarat reward pada periode ini.",10,MUTED,false),lp(-2));summary.addView(left,new LinearLayout.LayoutParams(0,-2,1));LinearLayout totalBox=col();totalBox.setGravity(Gravity.CENTER);totalBox.setPadding(dp(10),dp(6),dp(10),dp(6));totalBox.setBackground(shape(0xffffe8ee,0xffffd0da,dp(14)));totalBox.addView(center("Total Reward",10,DARK,true),lp(-2));totalBox.addView(center(formatRupiah(eligible?total:0),16,0xffb00024,true),lp(-2));summary.addView(totalBox,lp(-2));LinearLayout.LayoutParams sumP=field();sumP.topMargin=dp(6);card.addView(summary,sumP);
    LinearLayout header=row();header.setBackgroundColor(0xffffdce4);String[] cols={"No","Nama Personil","NIK","Jabatan","Nominal"};float[] weights={.35f,1.45f,1.05f,.9f,1.05f};for(int i=0;i<cols.length;i++){TextView t=center(cols[i],10,DARK,true);header.addView(t,new LinearLayout.LayoutParams(0,dp(30),weights[i]));}card.addView(header,lp(-1));
    int index=0;for(DocumentSnapshot u:roster){index++;String role=firstNonEmpty(u.getString("role"),"").toLowerCase(Locale.ROOT);int amount=role.equals("cos")?amounts[0]:(role.equals("acos")?amounts[1]:amounts[2]);String name=firstNonEmpty(u.getString("name"),firstNonEmpty(u.getString("fullName"),"-"));String nik=firstNonEmpty(u.getString("nik"),u.getId());LinearLayout r=row();r.setBackgroundColor(index%2==0?0xffedf0f5:Color.WHITE);String[] values={String.valueOf(index),name,nik,role.toUpperCase(Locale.ROOT),eligible?formatRupiah(amount):"—"};for(int i=0;i<values.length;i++){TextView t=center(values[i],10,DARK,i==4);t.setSingleLine(true);t.setEllipsize(android.text.TextUtils.TruncateAt.END);r.addView(t,new LinearLayout.LayoutParams(0,dp(25),weights[i]));}card.addView(r,lp(-1));}
    if(roster.isEmpty())card.addView(center("Belum ada personil aktif.",11,MUTED,false),field());
    LinearLayout footer=col();footer.setGravity(Gravity.CENTER);footer.setPadding(dp(10),dp(12),dp(10),dp(12));footer.setBackground(gradient(0xfffff0a8,0xffffd34a,dp(18)));TextView ft=center(closed?(eligible?"Selamat! Toko Anda MENANG IKT":"Syarat Reward Belum Terpenuhi"):(eligible?"Pertahankan Pencapaian!":"SYARAT REWARD BELUM TERPENUHI"),16,0xffa90020,true);footer.addView(ft,lp(-2));footer.addView(center(closed?(eligible?"Terima kasih atas kerja keras dan kolaborasi seluruh personil!":"Evaluasi pencapaian untuk periode berikutnya."):(eligible?"Jaga konsistensi kinerja hingga periode berakhir.":"Fokus pada pencapaian target Net Sales dan Margin agar reward dapat diraih."),11,DARK,false),field());LinearLayout.LayoutParams fp=field();fp.topMargin=dp(10);card.addView(footer,fp);return card;
  }

  private void renderRewardAdminAllStores(LinearLayout body,int year,int month){
    if(db==null){body.addView(rewardMessageCard("DATABASE BELUM SIAP","Tidak dapat memuat data seluruh toko.",0xfffff3e8,0xffbd7020),field());return;}
    String monthKey=String.format(Locale.US,"%04d%02d",year,month+1);
    TextView heading=center("REWARD IKT • SELURUH TOKO",14,Color.WHITE,true);
    heading.setPadding(dp(14),dp(10),dp(14),dp(10));
    heading.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xffa90020,0xffdf002f,0xffa90020}));
    LinearLayout.LayoutParams hp=field();hp.bottomMargin=dp(8);body.addView(heading,hp);
    TextView monthLabel=center(new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(rewardSelectedMonth.getTime()),12,0xff6d3a00,true);
    monthLabel.setPadding(dp(12),dp(6),dp(12),dp(6));monthLabel.setBackground(shape(0xfffff0c2,0xffffd15b,dp(14)));
    LinearLayout.LayoutParams mp=lp(-2);mp.gravity=Gravity.CENTER_HORIZONTAL;mp.bottomMargin=dp(10);body.addView(monthLabel,mp);
    LinearLayout list=col();list.setClipChildren(false);list.setClipToPadding(false);body.addView(list,lp(-1));
    TextView loading=txt("Memuat daftar toko dan pencapaian Reward IKT...",12,MUTED,false);list.addView(loading,field());
    db.collection("Stores").get().addOnSuccessListener(snapshot->{
      list.removeAllViews();
      java.util.List<DocumentSnapshot> stores=new java.util.ArrayList<>(snapshot.getDocuments());
      java.util.Collections.sort(stores,(a,b)->firstNonEmpty(a.getString("storeCode"),a.getId()).compareToIgnoreCase(firstNonEmpty(b.getString("storeCode"),b.getId())));
      if(stores.isEmpty()){list.addView(rewardMessageCard("BELUM ADA DATA TOKO","Master toko belum tersedia.",0xfffff3e8,0xffbd7020),field());return;}
      TextView count=center("Total "+stores.size()+" toko terdaftar",11,MUTED,true);count.setPadding(0,0,0,dp(8));list.addView(count,lp(-2));
      for(DocumentSnapshot storeDoc:stores)renderAdminRewardStoreCard(list,storeDoc,year,month,monthKey);
    }).addOnFailureListener(e->{list.removeAllViews();list.addView(rewardMessageCard("GAGAL MEMUAT TOKO",e.getLocalizedMessage(),0xffffeeee,RED),field());});
  }

  private void renderAdminRewardStoreCard(LinearLayout parent,DocumentSnapshot storeDoc,int year,int month,String monthKey){
    final String code=firstNonEmpty(storeDoc.getString("storeCode"),storeDoc.getId());
    final String name=firstNonEmpty(storeDoc.getString("storeName"),code);
    LinearLayout card=col();card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(shape(Color.WHITE,0xffffd16b,dp(16)));card.setElevation(dp(2));
    LinearLayout.LayoutParams cp=field();cp.bottomMargin=dp(9);parent.addView(card,cp);
    card.addView(txt(code+" • "+name,14,0xffa90020,true),lp(-2));
    card.addView(txt("Memuat pencapaian dan personil aktif...",10,MUTED,false),field());

    db.collection("DailyStoreReports").whereEqualTo("storeCode",code).get().addOnSuccessListener(reports->{
      double sales=0,marginSum=0;int reportCount=0;
      for(DocumentSnapshot d:reports.getDocuments()){
        String key=d.getString("dateKey");
        if(key==null||!key.matches("\\d{8}")||!key.startsWith(monthKey))continue;
        sales+=num(d.get("Net Sales"));marginSum+=num(d.get("Margin %"));reportCount++;
      }
      final double actualSales=sales,avgMargin=reportCount==0?0:marginSum/reportCount;
      final int finalReports=reportCount;
      // Query by storeCode (single-field filter) so toko without target document is handled safely.
      db.collection("MonthlyIKTTargets").whereEqualTo("storeCode",code).get().addOnSuccessListener(targets->{
        DocumentSnapshot target=null;
        for(DocumentSnapshot candidate:targets.getDocuments())if(monthKey.equals(candidate.getString("month"))){target=candidate;break;}
        double targetSales=target!=null?num(target.get("Net Sales")):0;
        double targetMargin=target!=null?num(target.get("Margin %")):0;
        double salesPct=targetSales>0?actualSales/targetSales*100.0:0;
        double marginPct=targetMargin>0?avgMargin/targetMargin*100.0:0;
        boolean ready=targetSales>0&&targetMargin>0&&finalReports>0;
        boolean eligible=ready&&salesPct>=100.0&&marginPct>=100.0;
        Calendar now=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"),new Locale("id","ID"));
        boolean closed=now.get(Calendar.YEAR)>year||(now.get(Calendar.YEAR)==year&&now.get(Calendar.MONTH)>month);
        String category=salesPct>105.0?"MAXIMAL":(salesPct>=102.6&&salesPct<=105.0?"MIDDLE":(salesPct>=100.0&&salesPct<=102.5?"MINIMAL":""));
        String state=!ready?"DATA BELUM LENGKAP":(closed?(eligible?"MENANG IKT":"BELUM MENANG IKT"):(eligible?"SYARAT TERPENUHI • DALAM PROGRES":"BELUM MEMENUHI SYARAT"));
        int[] amounts=category.equals("MAXIMAL")?new int[]{750000,500000,200000}:category.equals("MIDDLE")?new int[]{500000,300000,150000}:new int[]{300000,200000,100000};
        db.collection("Stores").document(code).collection("Users").get().addOnSuccessListener(users->{
          int cos=0,acos=0,crew=0;
          for(DocumentSnapshot u:users.getDocuments()){
            if(!Boolean.TRUE.equals(u.getBoolean("isActive")))continue;
            String role=firstNonEmpty(u.getString("role"),"").toLowerCase(Locale.ROOT);
            if("cos".equals(role))cos++;else if("acos".equals(role))acos++;else if("crew".equals(role))crew++;
          }
          int total=eligible?(cos*amounts[0]+acos*amounts[1]+crew*amounts[2]):0;
          card.removeAllViews();
          LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
          LinearLayout title=col();title.addView(txt(code+" • "+name,14,0xffa90020,true),lp(-2));
          title.addView(txt((cos+acos+crew)+" personil aktif",10,MUTED,false),lp(-2));
          top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
          TextView stateChip=center(state,9,eligible?0xff176b36:0xff8a1d24,true);stateChip.setPadding(dp(7),dp(5),dp(7),dp(5));stateChip.setBackground(shape(eligible?0xffe6f6e8:0xffffeeee,eligible?0xffa9d7ad:0xffffcccc,dp(14)));top.addView(stateChip,lp(-2));card.addView(top,lp(-2));
          LinearLayout metrics=row();metrics.setPadding(0,dp(8),0,dp(6));
          LinearLayout m1=col();m1.setGravity(Gravity.CENTER);m1.addView(txt("Net Sales",10,MUTED,true),lp(-2));m1.addView(txt(pct(salesPct,2),16,salesPct>=100?GREEN:RED,true),lp(-2));
          LinearLayout m2=col();m2.setGravity(Gravity.CENTER);m2.addView(txt("Margin",10,MUTED,true),lp(-2));m2.addView(txt(pct(marginPct,2),16,marginPct>=100?GREEN:RED,true),lp(-2));
          metrics.addView(m1,new LinearLayout.LayoutParams(0,-2,1));metrics.addView(m2,new LinearLayout.LayoutParams(0,-2,1));card.addView(metrics,lp(-2));
          LinearLayout bottom=row();bottom.setGravity(Gravity.CENTER_VERTICAL);
          TextView tier=center(category.isEmpty()?"BELUM ADA KATEGORI":category,11,0xffffe58a,true);tier.setPadding(dp(10),dp(5),dp(10),dp(5));tier.setBackground(shape(0xffb50025,0xffffd15b,dp(14)));bottom.addView(tier,new LinearLayout.LayoutParams(0,-2,1));
          LinearLayout sum=col();sum.setGravity(Gravity.END);sum.addView(txt("Total Reward",9,MUTED,false),lp(-2));sum.addView(txt(formatRupiah(total),13,0xffb00024,true),lp(-2));bottom.addView(sum,lp(-2));card.addView(bottom,lp(-2));
          card.addView(txt("COS "+cos+"  •  ACOS "+acos+"  •  CREW "+crew+"     |     "+state,9,MUTED,false),field());
        }).addOnFailureListener(e->{card.removeAllViews();card.addView(txt(code+" • "+name,14,0xffa90020,true),lp(-2));card.addView(txt("Gagal membaca personil toko: "+e.getLocalizedMessage(),10,RED,false),field());});
      }).addOnFailureListener(e->{card.removeAllViews();card.addView(txt(code+" • "+name,14,0xffa90020,true),lp(-2));card.addView(txt("Gagal membaca target toko: "+e.getLocalizedMessage(),10,RED,false),field());});
    }).addOnFailureListener(e->{card.removeAllViews();card.addView(txt(code+" • "+name,14,0xffa90020,true),lp(-2));card.addView(txt("Gagal membaca laporan toko: "+e.getLocalizedMessage(),10,RED,false),field());});
  }

private View rewardMessageCard(String title,String message,int bg,int accent){
    LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setPadding(dp(16),dp(20),dp(16),dp(20));box.setBackground(shape(bg,0xffe6d7b8,dp(16)));
    box.addView(center("🏆",30,accent,true),lp(-2));box.addView(center(title,18,accent,true),lp(-2));TextView detail=center(message,12,DARK,false);detail.setMaxLines(3);box.addView(detail,field());return box;
  }

  private void showSalesReport(LinearLayout body){
    LinearLayout.LayoutParams salesHeroParams=field();salesHeroParams.topMargin=dp(14);body.addView(referenceHeroHeader("LAPORAN SALES","Analisis kinerja penjualan toko",R.drawable.dashboard_icon_sales),salesHeroParams);
    LinearLayout tabs=row();tabs.setGravity(Gravity.CENTER_VERTICAL);tabs.setPadding(dp(1),dp(2),dp(1),dp(2));
    LinearLayout day=salesModeCard("Harian","Rekap per hari","▦",0xffc9002b,true);
    LinearLayout month=salesModeCard("Bulanan","Rekap per bulan","▦",0xffd99b00,false);
    LinearLayout year=salesModeCard("Tahunan","Tren per tahun","▥",0xff0878d1,false);
    LinearLayout[] modeCards={day,month,year};
    for(int i=0;i<modeCards.length;i++){LinearLayout.LayoutParams tile=new LinearLayout.LayoutParams(0,dp(112),1);if(i>0)tile.leftMargin=dp(7);tabs.addView(modeCards[i],tile);}body.addView(tabs,field());
    Calendar now=Calendar.getInstance();final int[] selected={now.get(Calendar.YEAR),now.get(Calendar.MONTH),now.get(Calendar.DAY_OF_MONTH)};
    LinearLayout filters=col(),result=col();body.addView(filters,lp(-2));body.addView(result,lp(-2));final String[] mode={"Harian"};
    Runnable[] render={null};
    render[0]=()->{
      filters.removeAllViews();result.removeAllViews();
      if("Harian".equals(mode[0])){
        TextView label=txt("Pilih Tanggal",13,DARK,true);filters.addView(label,field());
        TextView pick=txt(String.format(new Locale("id","ID"),"%02d %tB %04d",selected[2],new GregorianCalendar(selected[0],selected[1],selected[2]).getTime(),selected[0])+"  ▾",14,DARK,true);
        pick.setPadding(dp(14),dp(13),dp(14),dp(13));pick.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));filters.addView(pick,field());
        pick.setOnClickListener(v->new DatePickerDialog(this,(a,y,m,d)->{selected[0]=y;selected[1]=m;selected[2]=d;render[0].run();},selected[0],selected[1],selected[2]).show());
        Button show=primary("▥   Tampilkan Laporan   »");styleSalesReportButton(show);filters.addView(show,field());show.setOnClickListener(v->loadSalesPeriod(result,"Harian",selected[0],selected[1],selected[2]));
        result.addView(emptyReportHint("Pilih tanggal kemudian klik Tampilkan Laporan untuk melihat data harian."),field());
      }else if("Bulanan".equals(mode[0])){
        LinearLayout labels=row();labels.addView(txt("Bulan",12,DARK,true),new LinearLayout.LayoutParams(0,-2,1));labels.addView(txt("Tahun",12,DARK,true),new LinearLayout.LayoutParams(0,-2,1));filters.addView(labels,field());
        String[] names={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};
        LinearLayout selectors=row();Spinner months=new Spinner(this);months.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));months.setSelection(selected[1]);
        int currentYear=Calendar.getInstance().get(Calendar.YEAR);Integer[] years=new Integer[Math.max(1,currentYear-2019)];for(int i=0;i<years.length;i++)years[i]=2020+i;
        Spinner ys=new Spinner(this);ys.setAdapter(new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_dropdown_item,years));ys.setSelection(Math.max(0,Math.min(years.length-1,selected[0]-2020)));
        selectors.addView(months,new LinearLayout.LayoutParams(0,dp(50),1));selectors.addView(ys,new LinearLayout.LayoutParams(0,dp(50),1));filters.addView(selectors,field());
        Button show=primary("▥   Tampilkan Laporan   »");styleSalesReportButton(show);filters.addView(show,field());show.setOnClickListener(v->{selected[0]=(Integer)ys.getSelectedItem();selected[1]=months.getSelectedItemPosition();selected[2]=1;loadSalesPeriod(result,"Bulanan",selected[0],selected[1],1);});
        result.addView(emptyReportHint("Pilih bulan dan tahun kemudian klik Tampilkan Laporan untuk melihat rekap bulanan."),field());
      }else{
        LinearLayout labels=row();labels.addView(txt("Dari Tahun",12,DARK,true),new LinearLayout.LayoutParams(0,-2,1));labels.addView(txt("Sampai Tahun",12,DARK,true),new LinearLayout.LayoutParams(0,-2,1));filters.addView(labels,field());
        int currentYear=Calendar.getInstance().get(Calendar.YEAR);Integer[] years=new Integer[Math.max(1,currentYear-2019)];for(int i=0;i<years.length;i++)years[i]=2020+i;
        LinearLayout selectors=row();Spinner from=new Spinner(this),to=new Spinner(this);ArrayAdapter<Integer> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,years);from.setAdapter(adapter);to.setAdapter(new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_dropdown_item,years));from.setSelection(Math.max(0,years.length-2));to.setSelection(years.length-1);
        selectors.addView(from,new LinearLayout.LayoutParams(0,dp(50),1));selectors.addView(to,new LinearLayout.LayoutParams(0,dp(50),1));filters.addView(selectors,field());
        Button show=primary("▥   Tampilkan Laporan   »");styleSalesReportButton(show);filters.addView(show,field());show.setOnClickListener(v->{result.removeAllViews();result.addView(emptyAnnualReport(),field());});
        result.addView(emptyReportHint("Pilih rentang tahun kemudian klik Tampilkan Laporan untuk melihat perbandingan target dan realisasi."),field());
      }
    };
    String[] modeNames={"Harian","Bulanan","Tahunan"};
    for(int i=0;i<modeCards.length;i++){final int selectedMode=i;modeCards[i].setOnClickListener(v->{mode[0]=modeNames[selectedMode];for(int j=0;j<modeCards.length;j++)setSalesModeCardActive(modeCards[j],j==selectedMode);render[0].run();});}
    render[0].run();
  }
  private void styleSalesReportButton(Button button){
    button.setText("▥   Tampilkan Laporan   »");
    button.setTextColor(Color.WHITE);
    button.setTextSize(15);
    button.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
    button.setAllCaps(false);
    button.setElevation(dp(3));
    button.setPadding(dp(12),dp(12),dp(12),dp(12));
    button.setBackground(gradient(0xffc9002b,0xffe3132d,dp(14)));
  }
  private LinearLayout salesModeCard(String title,String subtitle,String symbol,int accent,boolean active){
    LinearLayout card=col();
    card.setGravity(Gravity.CENTER);
    card.setPadding(dp(6),dp(7),dp(6),dp(6));
    int pastel=accent==0xffc9002b?0xffffe6eb:(accent==0xffd99b00?0xfffff4d3:0xffe5f2ff);
    card.setBackground(shape(pastel,accent,dp(16)));
    card.setElevation(dp(active?4:3));
    card.setTag(accent);
    TextView icon=center(symbol,29,accent,true);
    icon.setBackground(shape(0x22ffffff,0,dp(12)));
    LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(48),dp(42));
    iconParams.bottomMargin=dp(3);
    card.addView(icon,iconParams);
    TextView name=center(title,15,DARK,true);
    card.addView(name,lp(-2));
    TextView desc=center(subtitle,10,MUTED,false);
    desc.setMaxLines(2);
    desc.setGravity(Gravity.CENTER);
    card.addView(desc,lp(-2));
    TextView arrow=center("›",24,Color.WHITE,true);
    arrow.setGravity(Gravity.CENTER);
    arrow.setBackground(shape(accent,0,dp(20)));
    LinearLayout.LayoutParams arrowParams=new LinearLayout.LayoutParams(dp(28),dp(28));
    arrowParams.gravity=Gravity.RIGHT;
    arrowParams.topMargin=dp(2);
    card.addView(arrow,arrowParams);
    return card;
  }
  private void setSalesModeCardActive(LinearLayout card,boolean active){
    int accent=card.getTag() instanceof Integer?(Integer)card.getTag():RED;
    card.setBackground(shape(active?0xfffff0f2:Color.WHITE,accent,dp(16)));
    card.setElevation(dp(active?4:3));
    if(card.getChildCount()>0&&card.getChildAt(0) instanceof TextView)
      ((TextView)card.getChildAt(0)).setTextColor(accent);
    if(card.getChildCount()>1&&card.getChildAt(1) instanceof TextView)
      ((TextView)card.getChildAt(1)).setTextColor(DARK);
    if(card.getChildCount()>3&&card.getChildAt(3) instanceof TextView)
      ((TextView)card.getChildAt(3)).setBackground(shape(accent,0,dp(20)));
  }
  private View emptyReportHint(String message){
    FrameLayout frame=new FrameLayout(this);
    frame.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(18)));
    frame.setClipToOutline(true);
    LinearLayout box=col();
    box.setGravity(Gravity.CENTER);
    box.setPadding(dp(18),dp(24),dp(18),dp(34));
    box.addView(center("▤",42,0xff9aa6b8,true),field());
    TextView description=center(message,13,MUTED,false);
    description.setMaxLines(3);
    box.addView(description,field());
    frame.addView(box,new FrameLayout.LayoutParams(-1,-1));
    View wave=new View(this){
      Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
      Path path=new Path();
      @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(dp(9));
        paint.setColor(0x33f2a2b4);
        path.reset();path.moveTo(-dp(4),h-dp(15));path.cubicTo(w*.28f,h-dp(1),w*.52f,h-dp(29),w*.78f,h-dp(22));path.cubicTo(w*.9f,h-dp(18),w*.96f,h-dp(5),w+dp(5),h-dp(12));canvas.drawPath(path,paint);
        paint.setColor(0x55ffd21f);paint.setStrokeWidth(dp(5));
        path.reset();path.moveTo(-dp(4),h-dp(8));path.cubicTo(w*.28f,h+dp(1),w*.52f,h-dp(20),w*.78f,h-dp(14));path.cubicTo(w*.9f,h-dp(11),w*.96f,h-dp(1),w+dp(5),h-dp(6));canvas.drawPath(path,paint);
      }
    };
    frame.addView(wave,new FrameLayout.LayoutParams(-1,dp(30),Gravity.BOTTOM));
    frame.setMinimumHeight(dp(145));
    return frame;
  }
  private View emptyAnnualReport(){
    LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setPadding(dp(20),dp(34),dp(20),dp(34));box.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(16)));
    box.addView(center("▥  !",38,0xff9aa6b8,true),field());box.addView(center("Data Penjualan Tahunan Belum Tersedia",18,DARK,true),field());
    box.addView(center("Belum terdapat data perbandingan penjualan sales antar-tahun. Laporan akan tersedia setelah data target dan realisasi penjualan tahunan tersedia.",13,MUTED,false),field());return box;
  }
  private void loadSalesPeriod(LinearLayout out,String mode,int y,int m,int d){
    out.removeAllViews();if(db==null){out.addView(txt("Database belum siap.",13,RED,false),field());return;}
    if(storeCode==null||storeCode.trim().isEmpty()){out.addView(txt("Kode toko tidak tersedia untuk akun ini.",13,RED,false),field());return;}
    Calendar first=new GregorianCalendar(y,m,d),last=(Calendar)first.clone();
    if("Bulanan".equals(mode)){first.set(Calendar.DAY_OF_MONTH,1);last.set(Calendar.DAY_OF_MONTH,last.getActualMaximum(Calendar.DAY_OF_MONTH));Calendar today=Calendar.getInstance();if(y==today.get(Calendar.YEAR)&&m==today.get(Calendar.MONTH))last.set(Calendar.DAY_OF_MONTH,Math.min(last.get(Calendar.DAY_OF_MONTH),today.get(Calendar.DAY_OF_MONTH)));}
    String from=new SimpleDateFormat("yyyyMMdd",Locale.US).format(first.getTime()),to=new SimpleDateFormat("yyyyMMdd",Locale.US).format(last.getTime());
    out.addView(txt("Memuat laporan...",12,MUTED,false),field());
    db.collection("DailyStoreReports").whereEqualTo("storeCode",storeCode).whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to).get()
      .addOnSuccessListener(snapshot->{
        java.util.TreeMap<String,DocumentSnapshot> reports=new java.util.TreeMap<>();
        for(DocumentSnapshot doc:snapshot.getDocuments()){String key=doc.getString("dateKey");if(key!=null&&key.compareTo(from)>=0&&key.compareTo(to)<=0)reports.put(key,doc);}
        out.removeAllViews();if(reports.isEmpty()){out.addView(txt("Belum ada data Input Data Toko pada periode ini.",13,MUTED,false),field());return;}
        if("Harian".equals(mode)){DocumentSnapshot doc=reports.get(from);if(doc==null){out.addView(txt("Data penjualan pada tanggal tersebut belum tersedia.",13,MUTED,false),field());return;}renderSalesDaily(out,doc,first);return;}
        renderSalesMonthly(out,reports,first,last);
      }).addOnFailureListener(e->{out.removeAllViews();out.addView(txt("Gagal membaca laporan sales: "+e.getLocalizedMessage(),12,RED,false),field());});
  }
  private void renderSalesDaily(LinearLayout out,DocumentSnapshot doc,Calendar date){
    LinearLayout head=col();head.setPadding(dp(14),dp(12),dp(14),dp(12));head.setBackground(gradient(0xffb9002b,0xffe3132d,dp(13)));
    head.addView(txt("Laporan Harian",16,Color.WHITE,true));head.addView(txt(new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(date.getTime()).toUpperCase(new Locale("id","ID")),12,Color.WHITE,false));out.addView(head,field());
    salesMetric(out,"SPD","Sales Per Day",formatRupiah(doc.get("Net Sales")),"🛒",0xffffe4e8,0xffc9002b);
    salesMetric(out,"STD","Struk Transaction Per Day",String.valueOf(Math.round(num(doc.get("STD")))),"👥",0xffe5f0ff,0xff2382d8);
    salesMetric(out,"NSB","Nota Selisih Barang",formatRupiah(doc.get("NSB")),"📦",0xfffff0d8,0xffe18a00);
    salesMetric(out,"APC","Average Purchase Per Customer",formatRupiah(doc.get("APC")),"🛍",0xfff2e5ff,0xff8c36c9);
    salesMetric(out,"MARGIN","Margin",String.format(new Locale("id","ID"),"%.2f%%",num(doc.get("Margin %"))),"%",0xffe2f5e9,0xff159447);
  }
  private void renderSalesMonthly(LinearLayout out,java.util.TreeMap<String,DocumentSnapshot> reports,Calendar first,Calendar last){
    double spdTotal=0,nsbTotal=0,stdSum=0,apcSum=0,marginSum=0;int count=0;
    LinearLayout head=col();head.setPadding(dp(14),dp(12),dp(14),dp(12));head.setBackground(gradient(0xffb9002b,0xffe3132d,dp(13)));
    head.addView(txt("Rekap Bulanan",16,Color.WHITE,true));head.addView(txt(new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(first.getTime()).toUpperCase(new Locale("id","ID")),12,Color.WHITE,false));out.addView(head,field());
    LinearLayout table=col();table.setPadding(dp(8),dp(9),dp(8),dp(9));table.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(13)));table.setElevation(dp(1));
    table.addView(txt("Data Input Harian",14,DARK,true),field());
    HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(true);hsv.setFillViewport(true);
    LinearLayout tableInner=col();tableInner.setMinimumWidth(dp(520));
    String[] cols={"Tgl","SPD (Rp)","STD","APC (Rp)","MARGIN","NSB (Rp)"};
    LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(3),dp(9),dp(3),dp(9));header.setBackground(shape(0xffedf0f5,0,dp(8)));
    int[] widths={70,112,52,94,76,104};
    for(int i=0;i<cols.length;i++){TextView cell=center(cols[i],10,DARK,true);header.addView(cell,new LinearLayout.LayoutParams(dp(widths[i]),-2));}
    tableInner.addView(header,field());
    for(Map.Entry<String,DocumentSnapshot> entry:reports.entrySet()){
      DocumentSnapshot doc=entry.getValue();double spd=num(doc.get("Net Sales")),std=num(doc.get("STD")),apc=num(doc.get("APC")),margin=num(doc.get("Margin %")),nsbDaily=num(doc.get("NSB"));
      spdTotal+=spd;nsbTotal+=nsbDaily;stdSum+=std;apcSum+=apc;marginSum+=margin;count++;
      LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(3),dp(9),dp(3),dp(9));
      String[] vals={entry.getKey().substring(6),formatGroupedInteger(spd),String.valueOf(Math.round(std)),formatGroupedInteger(apc),String.format(new Locale("id","ID"),"%.2f%%",margin),formatGroupedInteger(nsbDaily)};
      for(int i=0;i<vals.length;i++){TextView cell=center(vals[i],10,DARK,false);r.addView(cell,new LinearLayout.LayoutParams(dp(widths[i]),-2));}
      tableInner.addView(r,field());View divider=new View(this);divider.setBackgroundColor(0xffedf0f5);tableInner.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));
    }
    LinearLayout recap=row();recap.setGravity(Gravity.CENTER_VERTICAL);recap.setPadding(dp(3),dp(10),dp(3),dp(10));recap.setBackground(shape(0xffffe5e8,0xffe6a0aa,dp(7)));
    String[] recapVals={"REKAP",formatGroupedInteger(spdTotal),String.valueOf(Math.round(stdSum/count)),formatRupiah(apcSum/count),String.format(new Locale("id","ID"),"%.2f%%",marginSum/count),formatGroupedInteger(nsbTotal)};
    for(int i=0;i<recapVals.length;i++)recap.addView(center(recapVals[i],10,RED,true),new LinearLayout.LayoutParams(dp(widths[i]),-2));
    tableInner.addView(recap,field());hsv.addView(tableInner);table.addView(hsv,new LinearLayout.LayoutParams(-1,-2));out.addView(table,field());
  }
  private void salesMetric(LinearLayout parent,String label,String description,String value,String symbol,int iconBg,int iconColor){
    LinearLayout c=row();c.setGravity(Gravity.CENTER_VERTICAL);c.setMinimumHeight(dp(76));c.setPadding(dp(11),dp(10),dp(12),dp(10));c.setBackground(shape(Color.WHITE,0xffe1e5eb,dp(14)));c.setElevation(dp(1));
    TextView icon=center(symbol,20,iconColor,true);icon.setBackground(shape(iconBg,0,dp(24)));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(42),dp(42));ip.rightMargin=dp(10);c.addView(icon,ip);
    LinearLayout left=col();left.setGravity(Gravity.CENTER_VERTICAL);
    TextView labelView=txt(label,14,DARK,true);labelView.setMaxLines(1);left.addView(labelView);
    TextView descView=txt(description,10,MUTED,false);descView.setMaxLines(2);left.addView(descView);
    c.addView(left,new LinearLayout.LayoutParams(0,-2,1.0f));
    TextView val=txt(value,14,DARK,true);val.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);val.setMaxLines(2);val.setIncludeFontPadding(false);
    c.addView(val,new LinearLayout.LayoutParams(0,-2,1.25f));
    LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(8);parent.addView(c,p);
  }

  private void showSalesReportMenu(LinearLayout body){
    LinearLayout hero=col();hero.setPadding(dp(18),dp(14),dp(18),dp(14));hero.setBackground(gradient(0xffb9002b,0xffe3132d,dp(22)));hero.setElevation(dp(3));
    LinearLayout heroRow=row();heroRow.setGravity(Gravity.CENTER_VERTICAL);TextView icon=center("📈",40,Color.WHITE,true);heroRow.addView(icon,new LinearLayout.LayoutParams(dp(78),dp(82)));
    LinearLayout titleBox=col();titleBox.setPadding(dp(12),0,0,0);titleBox.addView(txt("Laporan",26,Color.WHITE,true));titleBox.addView(txt("Penjualan",29,0xffffdf22,true));titleBox.addView(txt("Rekap & Analisis Kinerja Penjualan Toko",12,Color.WHITE,true));heroRow.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));hero.addView(heroRow);LinearLayout.LayoutParams heroParams=field();heroParams.topMargin=dp(8);body.addView(hero,heroParams);
    reportMenuCard(body,"📊","Laporan Sales","Tanggal 1 s/d Tanggal Berjalan","SALES, STD, APC, MARGIN, NSB dan Rata-rata Keseluruhan",0xff0878d1,0xff0046a8,()->showDashboard("Laporan Sales"));
    reportMenuCard(body,"📋","Laporan Penawaran Langsung Sementara","Tanggal 1 s/d Tanggal Berjalan","Rekap penawaran langsung sementara",0xff29b765,0xff08783e,()->showDashboard("Laporan Penawaran Langsung Sementara"));
    reportMenuCard(body,"🗓️","Laporan Penawaran Langsung Per Periode","Rekap berdasarkan Periode","PSM, PWP, Serba Gratis, dan SUEGER",0xffffb52b,0xffed6500,()->showDashboard("Laporan Penawaran Langsung Per Periode"));
    reportMenuCard(body,"📅","Laporan Penawaran Langsung Per Bulan","Rekap Keseluruhan Selama Satu Bulan","Ringkasan penawaran langsung bulanan",0xff9638e8,0xff6515bd,()->showDashboard("Laporan Penawaran Langsung Per Bulan"));
  }
  private GradientDrawable gradient(int start,int end,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{start,end});d.setCornerRadius(radius);return d;}
  private void reportMenuCard(LinearLayout parent,String symbol,String title,String subtitle,String detail,int start,int end,Runnable action){
    LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(12),dp(11),dp(12),dp(11));card.setBackground(gradient(start,end,dp(19)));card.setElevation(dp(3));
    TextView art=center(symbol,37,Color.WHITE,true);card.addView(art,new LinearLayout.LayoutParams(dp(76),dp(82)));
    View divider=new View(this);divider.setBackgroundColor(0x99ffffff);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(dp(1),dp(68));dl.setMargins(dp(5),0,dp(10),0);card.addView(divider,dl);
    LinearLayout words=col();words.addView(txt(title,18,Color.WHITE,true));TextView sub=txt("▦  "+subtitle,12,Color.WHITE,true);sub.setPadding(0,dp(4),0,dp(3));words.addView(sub);words.addView(txt(detail,11,Color.WHITE,false));card.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    TextView arrow=center("❯",23,end,true);arrow.setBackground(shape(Color.WHITE,0,dp(24)));card.addView(arrow,new LinearLayout.LayoutParams(dp(38),dp(38)));
    LinearLayout.LayoutParams cp=lp(-2);cp.bottomMargin=dp(8);parent.addView(card,cp);card.setOnClickListener(v->action.run());
  }

  private static class PLTemporaryTotals { double[] actual=new double[4]; double[] target=new double[4]; java.util.Set<String> stores=new java.util.LinkedHashSet<>(); boolean targetFailed=false; }

  private static class PLPeriodSummary {
    double[] target=new double[4];
    double[][] periodTarget={{0,0,0,0},{0,0},{0,0},{0,0}};
    double[][] periodActual={{0,0,0,0},{0,0},{0,0},{0,0}};
    boolean targetFailed=false;
    ArrayList<String> stores=new ArrayList<>();
  }

  private void showPLPeriodReport(LinearLayout body){
    cardTitle(body,"Laporan Penawaran Langsung");
    Calendar now=Calendar.getInstance();
    final int[] selectedMonth={now.get(Calendar.MONTH)};
    final int[] selectedYear={now.get(Calendar.YEAR)};
    DatePicker monthPicker=new DatePicker(this);monthPicker.setVisibility(View.GONE);monthPicker.updateDate(selectedYear[0],selectedMonth[0],1);body.addView(monthPicker,new LinearLayout.LayoutParams(1,1));
    TextView monthLabel=txt("Bulan\n"+new SimpleDateFormat("MMMM",new Locale("id","ID")).format(now.getTime())+"   ▾",14,DARK,true);
    TextView yearLabel=txt("Tahun\n"+selectedYear[0]+"   ▾",14,DARK,true);
    LinearLayout selectors=row();selectors.setGravity(Gravity.CENTER_VERTICAL);selectors.setPadding(dp(12),dp(10),dp(12),dp(10));selectors.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(13)));
    LinearLayout monthBox=col();monthBox.setPadding(dp(8),dp(3),dp(8),dp(3));monthBox.addView(txt("PILIH BULAN",10,MUTED,true),lp(-2));monthBox.addView(monthLabel,lp(-2));selectors.addView(monthBox,new LinearLayout.LayoutParams(0,-2,1));
    View divider=new View(this);divider.setBackgroundColor(0xffe5e8ee);selectors.addView(divider,new LinearLayout.LayoutParams(dp(1),dp(38)));
    LinearLayout yearBox=col();yearBox.setPadding(dp(14),dp(3),dp(8),dp(3));yearBox.addView(txt("PILIH TAHUN",10,MUTED,true),lp(-2));yearBox.addView(yearLabel,lp(-2));selectors.addView(yearBox,new LinearLayout.LayoutParams(0,-2,1));body.addView(selectors,field());
    LinearLayout results=col();
    Button show=primary("Tampilkan Laporan");body.addView(show,field());
    TextView hint=center("Pilih bulan dan tahun, lalu tekan Tampilkan Laporan.",12,MUTED,false);hint.setPadding(dp(8),dp(12),dp(8),dp(12));body.addView(hint,lp(-2));
    Runnable clear=()->{results.removeAllViews();if(results.getParent()==body)body.removeView(results);};
    monthBox.setOnClickListener(v->{String[] months={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};new AlertDialog.Builder(this).setTitle("Pilih Bulan").setSingleChoiceItems(months,selectedMonth[0],(dialog,which)->{selectedMonth[0]=which;monthLabel.setText(months[which]+"   ▾");monthPicker.updateDate(selectedYear[0],selectedMonth[0],1);clear.run();hint.setVisibility(View.VISIBLE);dialog.dismiss();}).setNegativeButton("Batal",null).show();});
    yearBox.setOnClickListener(v->{int current=Calendar.getInstance().get(Calendar.YEAR);String[] years=new String[11];for(int i=0;i<years.length;i++)years[i]=String.valueOf(current-5+i);int checked=5+(selectedYear[0]-current);new AlertDialog.Builder(this).setTitle("Pilih Tahun").setSingleChoiceItems(years,checked,(dialog,which)->{selectedYear[0]=Integer.parseInt(years[which]);yearLabel.setText(selectedYear[0]+"   ▾");monthPicker.updateDate(selectedYear[0],selectedMonth[0],1);clear.run();hint.setVisibility(View.VISIBLE);dialog.dismiss();}).setNegativeButton("Batal",null).show();});
    show.setOnClickListener(v->{monthPicker.updateDate(selectedYear[0],selectedMonth[0],1);if(results.getParent()!=body)body.addView(results,lp(-2));hint.setVisibility(View.GONE);loadPLPeriodData(results,monthPicker);});
  }

  private void loadPLPeriodData(LinearLayout results,DatePicker picker){
    results.removeAllViews();if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!("crew".equals(currentRole)||"acos".equals(currentRole)||"cos".equals(currentRole)||"admin_utama".equals(currentRole))){results.addView(txt("Akses laporan tidak tersedia untuk jabatan ini.",13,RED,true),field());return;}
    int year=picker.getYear(),month=picker.getMonth()+1,last=monthDays(year,month);
    String from=String.format(Locale.US,"%04d%02d01",year,month),to=String.format(Locale.US,"%04d%02d%02d",year,month,last);
    results.addView(txt("Memuat laporan periode...",12,MUTED,false),field());
    Query q=db.collection("DailyPLReports").whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    if(!"admin_utama".equals(currentRole))q=q.whereEqualTo("storeCode",storeCode);
    q.get().addOnSuccessListener(snapshot->{
      PLPeriodSummary data=new PLPeriodSummary();
      if(!"admin_utama".equals(currentRole)&&storeCode!=null&&!storeCode.isEmpty())data.stores.add(storeCode);
      for(DocumentSnapshot doc:snapshot.getDocuments()){
        String code=doc.getString("storeCode");if(code!=null&&!code.isEmpty()&&!data.stores.contains(code))data.stores.add(code);
        String key=doc.getString("dateKey");if(key==null||key.length()!=8)continue;
        int day;try{day=Integer.parseInt(key.substring(6,8));}catch(Exception ex){continue;}
        Calendar current=Calendar.getInstance();int currentKey=current.get(Calendar.YEAR)*10000+(current.get(Calendar.MONTH)+1)*100+current.get(Calendar.DAY_OF_MONTH);
        if(Integer.parseInt(key)>currentKey)continue;
        int psm=day<=7?0:day<=15?1:day<=23?2:3;int half=day<=15?0:1;
        data.periodActual[0][psm]+=num(doc.get("PSM"));data.periodActual[1][half]+=num(doc.get("PWP"));data.periodActual[2][half]+=num(doc.get("Serba Gratis"));data.periodActual[3][half]+=num(doc.get("SUEGER"));
      }
      if(data.stores.isEmpty()){results.removeAllViews();results.addView(txt("Data toko untuk laporan periode belum tersedia.",13,MUTED,false),field());return;}
      loadPLPeriodTargets(results,data,0,year,month,last);
    }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca laporan: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private void loadPLPeriodTargets(LinearLayout results,PLPeriodSummary data,int index,int year,int month,int last){
    if(index>=data.stores.size()){renderPLPeriodReport(results,data,year,month,last);return;}
    String code=data.stores.get(index);db.collection("MonthlyPLTargets").document(code+"_"+String.format(Locale.US,"%04d%02d",year,month)).get().addOnSuccessListener(doc->{
      if(doc.exists()){
        String[][] keys={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};
        for(int c=0;c<4;c++)for(int j=0;j<keys[c].length;j++)data.periodTarget[c][j]+=num(doc.get(keys[c][j]));
      }
      loadPLPeriodTargets(results,data,index+1,year,month,last);
    }).addOnFailureListener(e->{data.targetFailed=true;loadPLPeriodTargets(results,data,index+1,year,month,last);});
  }

  private void renderPLPeriodReport(LinearLayout results,PLPeriodSummary data,int year,int month,int last){
    results.removeAllViews();Calendar today=Calendar.getInstance();int todayKey=today.get(Calendar.YEAR)*10000+(today.get(Calendar.MONTH)+1)*100+today.get(Calendar.DAY_OF_MONTH);int selectedMonth=year*100+month;
    String[] names={"PSM","PWP","SERBA GRATIS","SUEGER"};String[][] periods={{"Week 1","Week 2","Week 3","Week 4"},{"Periode 1","Periode 2"},{"Periode 1","Periode 2"},{"Periode 1","Periode 2"}};
    int[] colors={0xffdf1028,0xff0878d1,0xffff6900,0xff078b45};String[] icons={"🏷️","🛒","🎁","🥤"};
    int[][] starts={{1,8,16,24},{1,16},{1,16},{1,16}};int[][] ends={{7,15,23,last},{15,last},{15,last},{15,last}};
    for(int c=0;c<4;c++){
      int count=periods[c].length;double totalTarget=0,totalActual=0;boolean any=false;
      LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffd9e0e8,dp(16)));card.setElevation(dp(3));card.setPadding(dp(5),dp(5),dp(5),dp(7));card.setMinimumWidth(0);
      LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);header.setOrientation(LinearLayout.HORIZONTAL);header.setPadding(dp(12),0,dp(12),0);header.setBackground(gradient(colors[c],colors[c],dp(12)));
      TextView icon=center(icons[c],22,Color.WHITE,true);header.addView(icon,new LinearLayout.LayoutParams(dp(38),dp(38)));
      TextView title=txt(names[c],16,Color.WHITE,true);title.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);title.setSingleLine(true);title.setVisibility(View.VISIBLE);LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0,-1,1f);titleParams.leftMargin=dp(8);header.addView(title,titleParams);
      double activeT=0,activeA=0;for(int j=0;j<count;j++){int endKey=selectedMonth*100+ends[c][j],startKey=selectedMonth*100+starts[c][j];if(startKey<=todayKey){activeT+=data.periodTarget[c][j];int cap=Math.min(ends[c][j],year==today.get(Calendar.YEAR)&&month==today.get(Calendar.MONTH)+1?today.get(Calendar.DAY_OF_MONTH):(selectedMonth<today.get(Calendar.YEAR)*100+today.get(Calendar.MONTH)+1?ends[c][j]:0));if(cap>=starts[c][j])activeA+=data.periodActual[c][j];}}
      double headPct=activeT>0?activeA/activeT*100:0;String headlineText=activeT>0?pct(headPct,2):"--";TextView headline=center(headlineText,14,achievementColor(headlineText),true);headline.setPadding(dp(10),dp(7),dp(10),dp(7));headline.setBackground(shape(Color.WHITE,0,dp(22)));LinearLayout.LayoutParams headlineParams=new LinearLayout.LayoutParams(dp(112),-2);header.addView(headline,headlineParams);card.addView(header,new LinearLayout.LayoutParams(-1,dp(72)));
      LinearLayout table=col();table.setPadding(dp(4),dp(5),dp(4),0);LinearLayout h=row();h.setPadding(dp(5),dp(7),dp(5),dp(7));h.setBackground(shape(0xffedf1f5,0,dp(10)));addPLPeriodCell(h,"Periode",0,0xff253247,true);addPLPeriodCell(h,"Target",1,0xff253247,true);addPLPeriodCell(h,"Aktual",2,0xff253247,true);addPLPeriodCell(h,"Pencapaian",3,0xff253247,true);table.addView(h,lp(-2));
      for(int j=0;j<count;j++){
        int startKey=selectedMonth*100+starts[c][j];boolean active=startKey<=todayKey;int endKey=selectedMonth*100+ends[c][j];int capDay=(selectedMonth==today.get(Calendar.YEAR)*100+today.get(Calendar.MONTH)+1)?Math.min(ends[c][j],today.get(Calendar.DAY_OF_MONTH)):(selectedMonth<today.get(Calendar.YEAR)*100+today.get(Calendar.MONTH)+1?ends[c][j]:0);
        double target=active?data.periodTarget[c][j]:0,actual=active&&capDay>=starts[c][j]?data.periodActual[c][j]:0;double pc=target>0?actual/target*100:0;if(active){totalTarget+=target;totalActual+=actual;any=true;}
        LinearLayout r=row();r.setPadding(dp(5),dp(7),dp(5),dp(7));addPLPeriodCell(r,periods[c][j],0,DARK,false);addPLPeriodCell(r,active?formatGroupedInteger(target):"--",1,DARK,false);addPLPeriodCell(r,active?formatGroupedInteger(actual):"--",2,DARK,false);TextView value=center(active&&target>0?pct(pc,2):active?"0,00%":"--",11,active?achievementColor(pct(pc,2)):MUTED,true);value.setPadding(dp(5),dp(4),dp(5),dp(4));value.setBackground(shape(active?pc>=80?0xffb8edc7:pc>50?0xffffe58a:0xffffc6ca:0xffdfe3e9,0,dp(18)));r.addView(value,new LinearLayout.LayoutParams(0,-2,1.25f));table.addView(r,lp(-2));View line=new View(this);line.setBackgroundColor(0xffe6e9ee);table.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
      }
      LinearLayout total=row();total.setPadding(dp(8),dp(8),dp(8),dp(8));total.setBackground(gradient(0xffd80b22,0xffee172d,dp(10)));addPLPeriodCell(total,"TOTAL KESELURUHAN",0,Color.WHITE,true);addPLPeriodCell(total,any?formatGroupedInteger(totalTarget):"--",1,Color.WHITE,true);addPLPeriodCell(total,any?formatGroupedInteger(totalActual):"--",2,Color.WHITE,true);String totalPctText=any&&totalTarget>0?pct(totalActual/totalTarget*100,2):"--";TextView totalPct=center(totalPctText,12,achievementColor(totalPctText),true);totalPct.setPadding(dp(5),dp(5),dp(5),dp(5));totalPct.setBackground(shape(0xffffe77a,0,dp(18)));total.addView(totalPct,new LinearLayout.LayoutParams(0,-2,1.25f));LinearLayout.LayoutParams tp=lp(-2);tp.topMargin=dp(4);table.addView(total,tp);card.addView(table,lp(-2));LinearLayout.LayoutParams cp=field();cp.bottomMargin=dp(12);results.addView(card,cp);
    }
    if(data.targetFailed)results.addView(txt("Sebagian target tidak berhasil dibaca. Periksa koneksi dan izin Firestore.",11,RED,false),field());
  }

  private void addPLPeriodCell(LinearLayout row,String value,int column,int color,boolean bold){
    TextView t=txt(value,column==0?11:11,color,bold);t.setGravity(column==0?Gravity.CENTER_VERTICAL:Gravity.CENTER);if(column==0){row.addView(t,new LinearLayout.LayoutParams(0,-2,1.45f));}else{row.addView(t,new LinearLayout.LayoutParams(0,-2,column==3?1.25f:0.75f));}
  }

  private void loadPLReport(LinearLayout results,DatePicker startPicker,DatePicker endPicker){
    results.removeAllViews(); if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    Calendar start=new GregorianCalendar(startPicker.getYear(),startPicker.getMonth(),startPicker.getDayOfMonth()); Calendar end=new GregorianCalendar(endPicker.getYear(),endPicker.getMonth(),endPicker.getDayOfMonth());
    if(end.before(start)){results.addView(txt("Tanggal akhir tidak boleh lebih awal dari tanggal awal.",13,RED,true),field());return;}
    String from=new SimpleDateFormat("yyyyMMdd",Locale.US).format(start.getTime()),to=new SimpleDateFormat("yyyyMMdd",Locale.US).format(end.getTime());
    String fromLabel=selectedDate(startPicker),toLabel=selectedDate(endPicker); int jhk=(int)((end.getTimeInMillis()-start.getTimeInMillis())/86400000L)+1;
    results.addView(txt("Memuat rekap seluruh pencapaian...",12,MUTED,false),field()); Query q=db.collection("DailyPLReports");
    if("crew".equals(currentRole)||"cos".equals(currentRole)||"acos".equals(currentRole))q=q.whereEqualTo("storeCode",storeCode); else if(!"admin_utama".equals(currentRole)){results.removeAllViews();results.addView(txt("Akses laporan tidak tersedia untuk jabatan ini.",13,RED,true),field());return;}
    q=q.whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    final int days=jhk; final String fl=fromLabel,tl=toLabel; final Calendar st=(Calendar)start.clone(),en=(Calendar)end.clone();
    q.get().addOnSuccessListener(snapshot->{PLTemporaryTotals t=new PLTemporaryTotals(); if(("crew".equals(currentRole)||"cos".equals(currentRole)||"acos".equals(currentRole))&&storeCode!=null&&!storeCode.isEmpty())t.stores.add(storeCode); for(DocumentSnapshot d:snapshot.getDocuments()){String code=firstNonEmpty(d.getString("storeCode"),storeCode);if(!code.isEmpty())t.stores.add(code);t.actual[0]+=num(d.get("PSM"));t.actual[1]+=num(d.get("PWP"));t.actual[2]+=num(d.get("Serba Gratis"));t.actual[3]+=num(d.get("SUEGER"));} results.removeAllViews(); if(t.stores.isEmpty()){renderPLTemporaryDashboard(results,t,days,fl,tl);return;} loadPLDashboardTargets(results,t,new ArrayList<>(t.stores),0,st,en,days,fl,tl);}).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca DailyPLReports: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private void loadPLDashboardTargets(LinearLayout results,PLTemporaryTotals t,ArrayList<String> stores,int index,Calendar start,Calendar end,int jhk,String from,String to){
    if(index>=stores.size()){renderPLTemporaryDashboard(results,t,jhk,from,to);return;} String code=stores.get(index);
    if("admin_utama".equals(currentRole))db.collection("Stores").document(code).get().addOnSuccessListener(sd->{String type=firstNonEmpty(sd.getString("storeType"),sd.getString("type"));fetchPLDashboardTargets(results,t,stores,index,code,start,end,jhk,from,to,"24_JAM".equals(type)?3.0:2.0);}).addOnFailureListener(e->{t.targetFailed=true;loadPLDashboardTargets(results,t,stores,index+1,start,end,jhk,from,to);});
    else fetchPLDashboardTargets(results,t,stores,index,code,start,end,jhk,from,to,"24_JAM".equals(storeType)?3.0:2.0);
  }

  private void fetchPLDashboardTargets(LinearLayout results,PLTemporaryTotals t,ArrayList<String> stores,int index,String code,Calendar start,Calendar end,int jhk,String from,String to,double shifts){
    ArrayList<String> months=new ArrayList<>();Calendar c=(Calendar)start.clone();while(!c.after(end)){String m=String.format(Locale.US,"%04d%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1);if(!months.contains(m))months.add(m);c.add(Calendar.MONTH,1);c.set(Calendar.DAY_OF_MONTH,1);} Map<String,DocumentSnapshot> docs=new HashMap<>();final int[] left={months.size()};final boolean[] fail={false};
    for(String m:months)db.collection("MonthlyPLTargets").document(code+"_"+m).get().addOnSuccessListener(d->{docs.put(m,d);if(--left[0]==0){accumulatePLDashboardTarget(t,docs,start,end,shifts);if(fail[0])t.targetFailed=true;loadPLDashboardTargets(results,t,stores,index+1,start,end,jhk,from,to);}}).addOnFailureListener(e->{fail[0]=true;if(--left[0]==0){accumulatePLDashboardTarget(t,docs,start,end,shifts);t.targetFailed=true;loadPLDashboardTargets(results,t,stores,index+1,start,end,jhk,from,to);}});
  }

  // Dashboard dan Laporan Sementara memakai TARGET TOKO mentah dari input.
  // Setiap periode yang bersinggungan dengan rentang tanggal dihitung satu kali.
  // Konversi target individu (pembagian shift dan pembulatan) hanya untuk Ranking/Raport Crew.
  private void accumulatePLDashboardTarget(PLTemporaryTotals t,Map<String,DocumentSnapshot> docs,Calendar start,Calendar end,double shifts){
    java.util.Set<String>[] counted=new java.util.Set[]{new java.util.HashSet<>(),new java.util.HashSet<>(),new java.util.HashSet<>(),new java.util.HashSet<>()};
    Calendar c=(Calendar)start.clone();
    while(!c.after(end)){
      String m=String.format(Locale.US,"%04d%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1);
      DocumentSnapshot d=docs.get(m);int day=c.get(Calendar.DAY_OF_MONTH);
      if(d!=null&&d.exists())for(int i=0;i<4;i++){
        String key=i==0?"PSM_W"+(day<=7?1:day<=15?2:day<=23?3:4):i==1?"PWP_P"+(day<=15?1:2):i==2?"SG_P"+(day<=15?1:2):"SUEGER_P"+(day<=15?1:2);
        if(counted[i].add(m+"_"+key)){
          double storeTarget=num(d.get(key));
          if(storeTarget>0)t.target[i]+=storeTarget;
        }
      }
      c.add(Calendar.DAY_OF_MONTH,1);
    }
  }

  private void renderPLTemporaryDashboard(LinearLayout results,PLTemporaryTotals t,int jhk,String from,String to){
    results.removeAllViews(); LinearLayout summary=col();summary.setPadding(dp(14),dp(12),dp(14),dp(12));summary.setBackground(shape(0xfffff7e5,0xffeadfc4,dp(15)));LinearLayout sr=row();LinearLayout period=col();period.addView(txt("PERIODE LAPORAN",10,MUTED,true));period.addView(txt(from+" – "+to,15,0xffb4232f,true));sr.addView(period,new LinearLayout.LayoutParams(0,-2,1));View sep=new View(this);sep.setBackgroundColor(0xffe5d6b8);sr.addView(sep,new LinearLayout.LayoutParams(dp(1),dp(40)));LinearLayout days=col();days.setPadding(dp(12),0,0,0);days.addView(txt("JHK",10,MUTED,true));days.addView(txt(jhk+" Hari Kerja",15,0xffb4232f,true));sr.addView(days,new LinearLayout.LayoutParams(0,-2,1));summary.addView(sr,lp(-2));results.addView(summary,field());
    String[] labels={"PSM","PWP","SERBA GRATIS","SUEGER"};int[] colors={0xffd20b32,0xffffb400,0xff1687df,0xff8a27d8};
    for(int i=0;i<4;i++){double target=t.target[i],actual=t.actual[i],gap=Math.max(0,target-actual),excess=Math.max(0,actual-target),pct=target>0?actual/target*100:0;boolean ok=target>0&&actual>=target;int status=ok?0xff168b43:0xffbd2638;
      LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setBackground(shape(Color.WHITE,0xffe2e5eb,dp(15)));LinearLayout tag=col();tag.setGravity(Gravity.CENTER);tag.setPadding(dp(5),dp(10),dp(5),dp(10));tag.setBackground(gradient(plCategoryStart(i),plCategoryEnd(i),dp(12)));tag.addView(center(new String[]{"🛒","🧺","🎁","🥤"}[i],22,Color.WHITE,true));tag.addView(center(labels[i],10,Color.WHITE,true));card.addView(tag,new LinearLayout.LayoutParams(dp(82),-1));
      LinearLayout body=col();body.setPadding(dp(7),dp(8),dp(7),dp(8));LinearLayout met=row();addPLMetric(met,"JHK",String.valueOf(jhk),0xff263238,true);addPLMetric(met,"TARGET",target>0?formatGroupedInteger(target):"—",0xff263238,true);addPLMetric(met,"AKTUAL",formatGroupedInteger(actual),0xff16834b,true);if(target>0&&actual>target)addPLMetric(met,"+Qty","+"+formatGroupedInteger(excess)+" Qty",0xff16864b,false);else addPLMetric(met,"GAP",target>0?formatGroupedInteger(gap):"—",gap>0?0xffbd2638:0xff16834b,false);body.addView(met,lp(-2));LinearLayout st=row();st.addView(txt(target<=0?(t.targetFailed?"Target gagal dibaca":"Target belum diatur"):ok?"✓ Tercapai":"✕ Tidak Tercapai",10,status,true),new LinearLayout.LayoutParams(0,-2,1));st.addView(txt("PENCAPAIAN  "+(target>0?String.format(Locale.US,"%.2f%%",pct).replace('.',','):"—"),11,status,true));body.addView(st,topMargin(5));if(target>0){View bar=plGradientBar(pct,plCategoryStart(i),plCategoryEnd(i),String.format(Locale.US,"%.2f%%",pct));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(27));bp.topMargin=dp(7);body.addView(bar,bp);}card.addView(body,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams cp=field();cp.bottomMargin=dp(8);results.addView(card,cp);
    }
    LinearLayout charts=row();LinearLayout bar=col();bar.setPadding(dp(9),dp(9),dp(9),dp(9));bar.setBackground(shape(Color.WHITE,0xffe2e5eb,dp(13)));bar.addView(txt("▮ Grafik Pencapaian Per Indikator",10,DARK,true));View bars=new View(this){final android.graphics.Paint p=new android.graphics.Paint(3);protected void onDraw(android.graphics.Canvas c){float w=getWidth(),h=getHeight(),base=h-23;double max=1;for(int i=0;i<4;i++)max=Math.max(max,Math.max(t.target[i],t.actual[i]));for(int i=0;i<4;i++){float x=w/4*i,bw=w/16,bh=(float)(t.target[i]/max*(h-42)),ah=(float)(t.actual[i]/max*(h-42));p.setColor(0xff2386e8);c.drawRect(x+w/16,base-bh,x+w/16+bw,base,p);p.setColor(0xff20a34a);c.drawRect(x+w/16+bw+dp(3),base-ah,x+w/16+2*bw+dp(3),base,p);p.setColor(0xff263238);p.setTextSize(dp(8));p.setTextAlign(android.graphics.Paint.Align.CENTER);c.drawText(new String[]{"PSM","PWP","SG","SUE"}[i],x+w/8, h-5,p);}}};bar.addView(bars,new LinearLayout.LayoutParams(-1,dp(140)));charts.addView(bar,new LinearLayout.LayoutParams(0,-2,1));
    LinearLayout donut=col();donut.setPadding(dp(9),dp(9),dp(9),dp(9));donut.setBackground(shape(Color.WHITE,0xffe2e5eb,dp(13)));donut.addView(txt("◔ Komposisi Aktual",10,DARK,true));View pie=new View(this){final android.graphics.Paint p=new android.graphics.Paint(3);protected void onDraw(android.graphics.Canvas c){float size=Math.min(getWidth(),getHeight())-dp(8),x=(getWidth()-size)/2,y=(getHeight()-size)/2;android.graphics.RectF r=new android.graphics.RectF(x,y,x+size,y+size);double total=t.actual[0]+t.actual[1]+t.actual[2]+t.actual[3];int[] cs={0xffd20b32,0xffffb400,0xff1687df,0xff8a27d8};float angle=-90;for(int i=0;i<4;i++){float sw=total>0?(float)(t.actual[i]/total*360):0;p.setColor(cs[i]);c.drawArc(r,angle,sw,true,p);angle+=sw;}p.setColor(Color.WHITE);c.drawCircle(getWidth()/2f,getHeight()/2f,size*.27f,p);}};donut.addView(pie,new LinearLayout.LayoutParams(-1,dp(112)));double total=t.actual[0]+t.actual[1]+t.actual[2]+t.actual[3];for(int i=0;i<4;i++)donut.addView(txt(labels[i]+"  "+formatGroupedInteger(t.actual[i])+"  ("+(total>0?String.format(Locale.US,"%.1f%%",t.actual[i]/total*100):"0.0%")+")",8,DARK,false),lp(-2));LinearLayout.LayoutParams dp2=new LinearLayout.LayoutParams(0,-2,1);dp2.leftMargin=dp(6);charts.addView(donut,dp2);LinearLayout.LayoutParams chartP=field();chartP.topMargin=dp(4);results.addView(charts,chartP);
  }

  private LinearLayout.LayoutParams topMargin(int margin){LinearLayout.LayoutParams p=lp(-2);p.topMargin=dp(margin);return p;}

  private void addPLMetric(LinearLayout parent,String label,String value,int color,boolean divider){
    LinearLayout cell=col();cell.setPadding(dp(7),0,dp(5),0);cell.addView(txt(label,9,MUTED,true));TextView val=txt(value,14,color,true);LinearLayout.LayoutParams vp=lp(-2);vp.topMargin=dp(3);cell.addView(val,vp);parent.addView(cell,new LinearLayout.LayoutParams(0,-2,1));
    if(divider){View line=new View(this);line.setBackgroundColor(0xffe5e9ef);parent.addView(line,new LinearLayout.LayoutParams(dp(1),dp(31)));}
  }

  private void loadPendingRegistrations(LinearLayout body){if(!"admin_utama".equals(currentRole)){toast("Khusus Admin Utama.");return;}db.collection("RegistrationRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pendaftaran menunggu verifikasi.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("name"),role=d.getString("requestedRole"),code=d.getString("storeCode"),shop=d.getString("storeName"),email=d.getString("email");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(role+" | "+code+" - "+shop,12,MUTED,false));LinearLayout buttons=row();Button approve=primary("Setujui");Button reject=smallButton("Tolak");buttons.addView(approve,weight());buttons.addView(reject,weight());card.addView(buttons,field());body.addView(card,field());approve.setOnClickListener(v->approveRegistration(d));reject.setOnClickListener(v->rejectRequest("RegistrationRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pendaftaran: "+e.getLocalizedMessage()));}
  private void approveRegistration(DocumentSnapshot req){
    if(!"admin_utama".equals(currentRole))return;
    String nik=req.getString("nik"),code=req.getString("storeCode"),shop=req.getString("storeName"),role=req.getString("requestedRole");
    if(nik==null||code==null||shop==null||role==null)return;
    db.collection("Stores").document(code).get().addOnSuccessListener(storeDoc->{
      String officialType=storeDoc.exists()?normalizeStoreType(firstNonEmpty(storeDoc.getString("storeType"),storeDoc.getString("type"))):"";
      String chosenType=officialType.isEmpty()?normalizeStoreType(req.getString("requestedStoreType")):officialType;
      if(chosenType.isEmpty()){toast("Jenis toko belum valid. Minta personil mengajukan ulang.");return;}
      Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",req.getString("name"));profile.put("role",role);profile.put("storeCode",code);profile.put("storeName",shop);profile.put("storeType",chosenType);profile.put("email",req.getString("email"));profile.put("isActive",true);profile.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
      Map<String,Object> person=new HashMap<>(profile);person.put("currentRole",role);person.put("currentStoreCode",code);person.put("currentStoreName",shop);
      db.runBatch(batch->{
        batch.set(db.collection("Stores").document(code).collection("Users").document(nik),profile);
        batch.set(db.collection("Personnel").document(nik),person,SetOptions.merge());
        if(!storeDoc.exists()){Map<String,Object> master=new HashMap<>();master.put("storeCode",code);master.put("storeName",shop);master.put("storeType",chosenType);master.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());master.put("createdBy","RegistrationApproval");batch.set(db.collection("Stores").document(code),master,SetOptions.merge());}
        batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy",currentNik.isEmpty()?"AdminUtama":currentNik);
      }).addOnSuccessListener(v->showDashboard("Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menyetujui. Periksa Rules: "+e.getLocalizedMessage()));
    }).addOnFailureListener(e->toast("Gagal memeriksa master toko. Pastikan Admin Utama memiliki akses: "+e.getLocalizedMessage()));
  }
  private void loadPendingCareer(LinearLayout body){if(!"admin_utama".equals(currentRole))return;db.collection("CareerRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pengajuan karir menunggu persetujuan.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("personName"),from=d.getString("currentRole"),to=d.getString("requestedRole"),why=d.getString("reason");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(String.valueOf(from)+" → "+String.valueOf(to)+"\n"+String.valueOf(why),12,MUTED,false));LinearLayout buttons=row();Button yes=primary("Setujui");Button no=smallButton("Tolak");buttons.addView(yes,weight());buttons.addView(no,weight());card.addView(buttons,field());body.addView(card,field());yes.setOnClickListener(v->approveCareer(d));no.setOnClickListener(v->rejectRequest("CareerRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pengajuan karir: "+e.getLocalizedMessage()));}
  private void approveCareer(DocumentSnapshot req){if(!"admin_utama".equals(currentRole))return;String nik=req.getString("nik"),from=req.getString("currentRole"),to=req.getString("requestedRole"),code=req.getString("storeCode");boolean sequence=("crew".equals(from)&&"acos".equals(to))||("acos".equals(from)&&"cos".equals(to));if(!sequence){toast("Urutan jabatan tidak valid.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()||!from.equals(person.getString("currentRole"))){toast("Jabatan personil sudah berubah. Pengajuan perlu diperiksa ulang.");return;}Map<String,Object> update=new HashMap<>();update.put("currentRole",to);update.put("role",to);update.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());String effective=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());Map<String,Object> history=new HashMap<>();history.put("previousRole",from);history.put("newRole",to);history.put("effectiveDate",effective);history.put("approvedBy","AdminUtama");history.put("notes",req.getString("reason"));db.runBatch(batch->{batch.update(db.collection("Personnel").document(nik),update);batch.update(db.collection("Stores").document(code).collection("Users").document(nik),"role",to);batch.set(db.collection("Personnel").document(nik).collection("CareerHistory").document(),history);batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy","AdminUtama");}).addOnSuccessListener(v->showDashboard("Permohonan Karir")).addOnFailureListener(e->toast("Gagal menyetujui karir: "+e.getLocalizedMessage()));});}
  private void rejectRequest(String collection,String id){Map<String,Object> u=new HashMap<>();u.put("status","rejected");u.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());u.put("reviewedBy","AdminUtama");db.collection(collection).document(id).update(u).addOnSuccessListener(v->showDashboard(collection.equals("CareerRequests")?"Permohonan Karir":"Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menolak permohonan: "+e.getLocalizedMessage()));}
  private void processMutation(String nik,String newCode,String newName){if(!"admin_utama".equals(currentRole)||!nik.matches("\\d{8}")||newCode.isEmpty()||newName.isEmpty()){toast("Periksa NIK, kode toko, dan nama toko.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()){toast("Data personil tidak ditemukan di Personnel.");return;}String oldCode=person.getString("currentStoreCode"),oldName=person.getString("currentStoreName"),role=person.getString("currentRole"),name=person.getString("name");Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",name);profile.put("role",role);profile.put("storeCode",newCode);profile.put("storeName",newName);profile.put("email",person.getString("email"));profile.put("isActive",true);Map<String,Object> pupdate=new HashMap<>();pupdate.put("currentStoreCode",newCode);pupdate.put("currentStoreName",newName);pupdate.put("storeCode",newCode);pupdate.put("storeName",newName);Map<String,Object> hist=new HashMap<>();hist.put("previousStoreCode",oldCode);hist.put("previousStoreName",oldName);hist.put("newStoreCode",newCode);hist.put("newStoreName",newName);hist.put("effectiveDate",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()));hist.put("updatedBy","AdminUtama");db.runBatch(batch->{batch.set(db.collection("Stores").document(newCode).collection("Users").document(nik),profile);if(oldCode!=null&&!oldCode.isEmpty()&&!oldCode.equals(newCode))batch.update(db.collection("Stores").document(oldCode).collection("Users").document(nik),"isActive",false);batch.update(db.collection("Personnel").document(nik),pupdate);batch.set(db.collection("Personnel").document(nik).collection("MutationHistory").document(),hist);}).addOnSuccessListener(v->toast("Mutasi berhasil dicatat. Pastikan profil toko lama dinonaktifkan oleh Admin.")).addOnFailureListener(e->toast("Mutasi gagal: "+e.getLocalizedMessage()));});}
  private void showCareerRequest(){if(currentNik.isEmpty()||db==null)return;String next="";if("crew".equals(currentRole))next="acos";else if("acos".equals(currentRole))next="cos";if(next.isEmpty()){toast("COS adalah jenjang tertinggi.");return;}LinearLayout page=col();page.setPadding(dp(18),dp(18),dp(18),dp(18));page.setBackgroundColor(BG);page.addView(txt("PENGAJUAN JENJANG KARIR",20,DARK,true),field());page.addView(txt("Jabatan saat ini: "+roleLabel()+"\nJabatan yang dapat diajukan: "+next.toUpperCase(Locale.US),14,MUTED,false),field());EditText reason=registerField(page,"Alasan pengajuan",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);final String requestedRole=next;Button send=primary("Kirim Pengajuan");page.addView(send,field());Button back=smallButton("Kembali");page.addView(back,field());back.setOnClickListener(v->showDashboard("Profil"));send.setOnClickListener(v->{String why=reason.getText().toString().trim();if(why.isEmpty()){toast("Isi alasan pengajuan terlebih dahulu.");return;}String id=currentNik+"_"+System.currentTimeMillis();Map<String,Object> data=new HashMap<>();data.put("nik",currentNik);data.put("personName",currentName);data.put("currentRole",currentRole);data.put("requestedRole",requestedRole);data.put("storeCode",storeCode);data.put("reason",why);data.put("status","pending");data.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());db.collection("CareerRequests").document(id).set(data).addOnSuccessListener(vv->toast("Pengajuan dikirim ke Admin Utama.")).addOnFailureListener(e->toast("Pengajuan gagal: "+e.getLocalizedMessage()));});setContentView(page);}
  // Kinerja Toko: sebelum closing 22.00 gunakan H-1; setelah closing gunakan hari ini
  // hanya jika laporan hari ini sudah tersimpan. Status dan rekap berasal dari satu query
  // yang dibatasi storeCode agar tetap sesuai Firestore Rules toko aktif.
  private void loadDashboardIKT(TextView[][] fields,TextView titleView){
    Calendar now=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"),new Locale("id","ID"));
    Calendar today=(Calendar)now.clone();
    Calendar yesterday=(Calendar)today.clone(); yesterday.add(Calendar.DAY_OF_MONTH,-1);
    boolean afterClosing=now.get(Calendar.HOUR_OF_DAY)>=22;
    if(db==null||storeCode==null||storeCode.trim().isEmpty()){
      setKinerjaTitle(titleView,yesterday.getTime(),false,"Tidak dapat memeriksa data toko");
      setDashboardValues(fields,"--","--","--","DATA BELUM TERSEDIA","--","--","--","--","--","--");
      return;
    }
    int todayYear=today.get(Calendar.YEAR), todayMonth=today.get(Calendar.MONTH);
    // PENTING: jangan get() dokumen yang belum ada. Rules get berbasis resource.data
    // dapat menolak dokumen kosong. Query storeCode mematuhi allow list berbasis toko.
    db.collection("DailyStoreReports").whereEqualTo("storeCode",storeCode).get()
      .addOnSuccessListener(snapshot->{
        java.util.Map<String,DocumentSnapshot> reports=new java.util.HashMap<>();
        for(DocumentSnapshot doc:snapshot.getDocuments()){
          String key=doc.getString("dateKey");
          if(key!=null && key.matches("\\d{8}")) reports.put(key,doc);
        }
        String todayKey=String.format(Locale.US,"%04d%02d%02d",todayYear,todayMonth+1,today.get(Calendar.DAY_OF_MONTH));
        Calendar reportDate;
        if(afterClosing && reports.containsKey(todayKey)) reportDate=(Calendar)today.clone();
        else reportDate=(Calendar)yesterday.clone();
        int year=reportDate.get(Calendar.YEAR), month=reportDate.get(Calendar.MONTH);
        String monthPrefix=String.format(Locale.US,"%04d%02d",year,month+1);
        int cutoff=reportDate.get(Calendar.DAY_OF_MONTH);
        String reportKey=String.format(Locale.US,"%04d%02d%02d",year,month+1,cutoff);
        boolean selectedUpdated=reports.containsKey(reportKey);
        java.util.List<Integer> missingDays=new java.util.ArrayList<>();
        double[] sums=new double[5]; int count=0,latestInputDay=0;
        for(int day=1;day<=cutoff;day++){
          String key=String.format(Locale.US,"%04d%02d%02d",year,month+1,day);
          DocumentSnapshot doc=reports.get(key);
          if(doc==null){missingDays.add(day);continue;}
          sums[0]+=num(doc.get("Net Sales"));
          sums[1]+=num(doc.get("Margin %"));
          sums[2]+=num(doc.get("NSB"));
          sums[3]+=num(doc.get("APC"));
          sums[4]+=num(doc.get("STD"));
          count++; latestInputDay=day;
        }
        StringBuilder warning=new StringBuilder();
        SimpleDateFormat monthFmt=new SimpleDateFormat("MMM",new Locale("id","ID"));
        for(Integer day:missingDays){
          if(warning.length()>0)warning.append(", ");
          warning.append(day).append(" ").append(monthFmt.format(reportDate.getTime()));
        }
        setKinerjaTitle(titleView,reportDate.getTime(),selectedUpdated,warning.toString());
        final int reportCount=count;
        final int reportLatestInputDay=latestInputDay;
        final double[] reportSums=sums;
        String targetId=storeCode+"_"+monthPrefix;
        db.collection("MonthlyIKTTargets").document(targetId).get().addOnSuccessListener(targetDoc->{
          if(!targetDoc.exists()){
            setDashboardValues(fields,"--","--","--","TARGET BELUM DIISI","--","--","--","--","--","--");
            return;
          }
          double targetSales=num(targetDoc.get("Net Sales")), targetMargin=num(targetDoc.get("Margin %")), targetApc=num(targetDoc.get("APC")), targetStd=num(targetDoc.get("STD"));
          renderDashboardIKT(fields,titleView,reportSums,reportCount,reportLatestInputDay,cutoff,year,month,targetSales,targetMargin,targetApc,targetStd);
        }).addOnFailureListener(e->{
          setDashboardValues(fields,"--","--","--","GAGAL MEMBACA TARGET","--","--","--","--","--","--");
          toast("Gagal membaca target Kinerja Toko: "+e.getLocalizedMessage());
        });
      })
      .addOnFailureListener(e->{
        setKinerjaTitle(titleView,yesterday.getTime(),false,"Gagal memeriksa laporan sales: "+e.getLocalizedMessage());
        setDashboardValues(fields,"--","--","--","GAGAL MEMERIKSA LAPORAN","--","--","--","--","--","--");
        toast("Gagal memeriksa laporan sales toko: "+e.getLocalizedMessage());
      });
  }

  // Helper numerik yang dipakai lintas modul; menerima Number maupun String dari Firestore.
  private double num(Object value){
    if(value==null)return 0.0;
    try{
      String raw=String.valueOf(value).trim().replace("%","").replace(",",".");
      if(raw.isEmpty())return 0.0;
      double parsed=Double.parseDouble(raw);
      return (Double.isNaN(parsed)||Double.isInfinite(parsed))?0.0:parsed;
    }catch(Exception e){return 0.0;}
  }
  private String pct(double value,int decimals){
    return String.format(new Locale("id","ID"),"%."+Math.max(0,Math.min(4,decimals))+"f%%",value);
  }
  private int achievementColor(String value){
    String raw=value==null?"":value.trim().replace("%","").replace(",",".");
    if(raw.isEmpty()||raw.equals("--"))return MUTED;
    double valuePct;try{valuePct=Double.parseDouble(raw);}catch(Exception e){return MUTED;}
    if(valuePct<50.0)return 0xffc62828;
    if(valuePct<80.0)return 0xffffa000;
    return 0xff18864b;
  }
  // Memetakan hasil perhitungan Kinerja Toko ke empat kartu dashboard.
  private void setDashboardValues(TextView[][] fields,String sales,String margin,String nsb,String status,
      String targetSales,String actualSales,String targetMargin,String actualMargin,String nsbAllowance,String actualNsb){
    if(fields==null)return;
    String[] values={sales,margin,nsb,status};
    String[] subtitles={"Pencapaian Net Sales","Rata-rata Margin","Pemakaian toleransi NSB","Status toko"};
    String[] targets={"Target : "+targetSales,"Target : "+targetMargin,"Batas toleransi : "+nsbAllowance,""};
    String[] actuals={"Aktual : "+actualSales,"Aktual : "+actualMargin,"Aktual : "+actualNsb,""};
    for(int i=0;i<Math.min(fields.length,4);i++){
      TextView[] card=fields[i];if(card==null)continue;
      if(card.length>0&&card[0]!=null){card[0].setText(values[i]);card[0].setTextColor(i==3?("MENANG".equals(status)?GREEN:RED):(i==2?achievementColor(nsb):achievementColor(values[i])));}
      if(card.length>1&&card[1]!=null)card[1].setText(subtitles[i]);
      if(card.length>2&&card[2]!=null)card[2].setText(targets[i]);
      if(card.length>3&&card[3]!=null)card[3].setText(actuals[i]);
      if(card.length>4&&card[4]!=null){
        String note=i==3?status:(i==2?(num(nsb.replace(",","."))<=0.15?"Dalam batas toleransi":"Melebihi toleransi"):("--".equals(values[i])?"Menunggu data":"Dalam Progres"));
        card[4].setText("Keterangan : "+note);card[4].setTextColor(i==3?("MENANG".equals(status)?GREEN:RED):(i==2?(num(nsb.replace(",","."))<=0.15?GREEN:RED):achievementColor(values[i])));
      }
    }
  }

  private void setKinerjaTitle(TextView titleView, Date date, boolean updated,String missingDates){
    SimpleDateFormat fmt=new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID"));
    fmt.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Jakarta"));
    String label=fmt.format(date);
    String text="●  Kinerja Toko (s.d. "+label+")";
    if(missingDates!=null&&!missingDates.isEmpty()) text+="\n⚠ Belum input laporan sales: "+missingDates;
    SpannableString styled=new SpannableString(text);
    styled.setSpan(new ForegroundColorSpan(updated?0xff16a34a:0xffdc2626),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    int warningStart=text.indexOf("⚠");
    if(warningStart>=0) styled.setSpan(new ForegroundColorSpan(0xffdc2626),warningStart,text.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    titleView.setText(styled);
    titleView.setMaxLines(4);
  }

  private Date reportDateForTitle(int year,int month,int day){
    Calendar c=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Jakarta"));
    c.set(year,month,day,12,0,0);c.set(Calendar.MILLISECOND,0);return c.getTime();
  }
  private void renderDashboardIKT(TextView[][] fields,TextView titleView,double[] sums,int count,int latestInputDay,int reportDay,int year,int month,double targetSales,double targetMargin,double targetApc,double targetStd){
    if(count==0){setDashboardValues(fields,"--","--","--","BELUM ADA DATA","--","Rp 0","--","--","--","--");return;}
    double avgMargin=sums[1]/count,avgApc=sums[3]/count,avgStd=sums[4]/count;
    double nsbAllowance=sums[0]*0.0015; double nsbRemaining=nsbAllowance-sums[2];
    // Dashboard classification uses absolute NSB actual; sign is preserved in the displayed Rupiah value.
    double nsbPercent=sums[0]<=0?0:(Math.abs(sums[2])/sums[0])*100.0;
    double salesAchievement=targetSales<=0?0:(sums[0]/targetSales)*100.0; double marginAchievement=targetMargin<=0?0:(avgMargin/targetMargin)*100.0;
    boolean salesOk=targetSales>0&&sums[0]>=targetSales, marginOk=targetMargin>0&&avgMargin>=targetMargin, nsbOk=nsbPercent<=0.15, apcOk=targetApc>0&&avgApc>=targetApc, stdOk=targetStd>0&&avgStd>=targetStd;
    String status=(salesOk&&marginOk&&nsbOk&&apcOk&&stdOk)?"MENANG":"DALAM PROGRES";
    setDashboardValues(fields,pct(salesAchievement,2),pct(marginAchievement,2),pct(nsbPercent,3),status,formatRupiah(targetSales),formatRupiah(sums[0]),pct(targetMargin,2),pct(avgMargin,2),formatRupiah(nsbAllowance),formatRupiah(sums[2]));
    if(fields!=null&&fields.length>0&&fields[0]!=null&&fields[0].length>5&&fields[0][5]!=null){
      Calendar monthCalendar=Calendar.getInstance(new java.util.Locale("id","ID"));
      monthCalendar.set(Calendar.YEAR,year);monthCalendar.set(Calendar.MONTH,month);monthCalendar.set(Calendar.DAY_OF_MONTH,1);
      int daysInMonth=monthCalendar.getActualMaximum(Calendar.DAY_OF_MONTH);
      // Sisa hari kalender dihitung mulai H+1 setelah tanggal laporan yang sedang ditampilkan.
      int remainingCalendarDays=Math.max(0,daysInMonth-reportDay);
      double difference=targetSales-sums[0];
      String targetGapText;
      if(difference>0){
        if(remainingCalendarDays>0){
          targetGapText="Kekurangan : "+formatRupiah(difference/remainingCalendarDays)+" / hari ("+remainingCalendarDays+" hari kalender tersisa)";
        }else{
          targetGapText="Kekurangan : "+formatRupiah(difference)+" (Periode berakhir)";
        }
      }else{
        double excess=Math.max(0.0,-difference);
        targetGapText="Kelebihan : "+formatRupiah(excess)+(excess==0?" (Target tercapai)":"");
      }
      fields[0][5].setText(targetGapText);
    }
  }

  private Button profileActionButton(String symbol,String label){
    Button b=new Button(this);b.setAllCaps(false);b.setText(symbol+"    "+label+"                                      ›");b.setTextColor(RED);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);b.setPadding(dp(16),0,dp(10),0);b.setMinHeight(dp(46));b.setMinimumHeight(dp(46));b.setTextSize(14);b.setBackground(shape(0xfffff0f1,0xffffc5cc,dp(15)));b.setElevation(dp(2));return b;
  }

  private void showChangePinDialog(){
    if(auth==null||auth.getCurrentUser()==null||currentNik==null||!currentNik.matches("\\d{8}")){
      toast("Ubah PIN hanya tersedia untuk akun personil yang sedang login.");return;
    }
    LinearLayout form=col();form.setPadding(dp(18),dp(8),dp(18),dp(4));
    EditText oldPin=new EditText(this);oldPin.setSingleLine(true);oldPin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);oldPin.setHint("PIN lama (6 digit)");form.addView(oldPin,field());
    EditText newPin=new EditText(this);newPin.setSingleLine(true);newPin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);newPin.setHint("PIN baru (6 digit)");form.addView(newPin,field());
    EditText confirmPin=new EditText(this);confirmPin.setSingleLine(true);confirmPin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);confirmPin.setHint("Ulangi PIN baru");form.addView(confirmPin,field());
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Ubah PIN").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create();
    dialog.setOnShowListener(v->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn->{
      String oldValue=oldPin.getText().toString().trim(),newValue=newPin.getText().toString().trim(),confirmValue=confirmPin.getText().toString().trim();
      if(!oldValue.matches("\\d{6}")||!newValue.matches("\\d{6}")||!newValue.equals(confirmValue)){
        toast("PIN harus 6 angka dan PIN baru harus sama dengan konfirmasi.");return;
      }
      if(oldValue.equals(newValue)){toast("PIN baru harus berbeda dari PIN lama.");return;}
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
      auth.getCurrentUser().reauthenticate(EmailAuthProvider.getCredential(currentNik+AUTH_DOMAIN,oldValue)).addOnCompleteListener(this,reauth->{
        if(!reauth.isSuccessful()){dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);toast("PIN lama tidak sesuai. PIN belum diubah.");return;}
        auth.getCurrentUser().updatePassword(newValue).addOnCompleteListener(this,update->{
          dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
          if(update.isSuccessful()){dialog.dismiss();toast("PIN berhasil diperbarui.");}
          else toast("Gagal mengubah PIN: "+(update.getException()==null?"Coba lagi.":update.getException().getLocalizedMessage()));
        });
      });
    }));
    dialog.show();
  }

  private TextView addDropdownDatePicker(LinearLayout body,DatePicker picker,boolean monthOnly,Runnable onChanged){
    picker.setVisibility(View.GONE);
    body.addView(picker,new LinearLayout.LayoutParams(1,1));
    TextView selector=txt("Pilih "+(monthOnly?"Bulan":"Tanggal")+"  ▾",14,DARK,true);
    selector.setGravity(Gravity.CENTER_VERTICAL);
    selector.setPadding(dp(14),dp(13),dp(14),dp(13));
    selector.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));
    body.addView(selector,field());
    setDropdownDatePickerListener(selector,picker,monthOnly,onChanged);
    return selector;
  }
  private void setDropdownDatePickerListener(TextView selector,DatePicker picker,boolean monthOnly,Runnable onChanged){
    Runnable updateLabel=()->{
      Calendar selected=Calendar.getInstance();selected.set(picker.getYear(),picker.getMonth(),picker.getDayOfMonth());
      String label=monthOnly?new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(selected.getTime()).toUpperCase(new Locale("id","ID")):new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(selected.getTime()).toUpperCase(new Locale("id","ID"));
      selector.setText(label+"  ▾");
    };
    updateLabel.run();
    selector.setOnClickListener(v->{
      DatePickerDialog dialog=new DatePickerDialog(this,(view,y,m,d)->{
        picker.updateDate(y,m,d);updateLabel.run();if(onChanged!=null)onChanged.run();
      },picker.getYear(),picker.getMonth(),picker.getDayOfMonth());
      dialog.show();
    });
  }

  private String selectedDate(DatePicker date){Calendar c=Calendar.getInstance();c.set(date.getYear(),date.getMonth(),date.getDayOfMonth(),0,0,0);c.set(Calendar.MILLISECOND,0);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
  private String selectedDateKey(DatePicker date){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(date.getYear()-1900,date.getMonth(),date.getDayOfMonth()));}
  private boolean canEditToday(DatePicker date){Calendar now=Calendar.getInstance();return date.getYear()==now.get(Calendar.YEAR)&&date.getMonth()==now.get(Calendar.MONTH)&&date.getDayOfMonth()==now.get(Calendar.DAY_OF_MONTH)&&now.get(Calendar.HOUR_OF_DAY)<24;}
  private void loadDailyInput(String page,DatePicker date,Map<String,EditText> inputs,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null)return;
    boolean store=page.equals("Input Toko");for(EditText input:inputs.values())input.setText("0");String day=selectedDateKey(date);String targetNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();if(!store&&!targetNik.matches("\\d{8}"))return;String id=store?storeCode+"_"+day:targetNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    if(store){
      // Query berdasarkan storeCode agar Firestore Rules dapat memvalidasi cakupan toko.
      // Jangan membaca dokumen berdasarkan ID langsung: dokumen yang belum ada dapat memicu PERMISSION_DENIED.
      db.collection("DailyStoreReports").whereEqualTo("storeCode",storeCode).get()
        .addOnSuccessListener(snapshot->{for(DocumentSnapshot doc:snapshot.getDocuments())if(day.equals(doc.getString("dateKey"))){for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}break;}})
        .addOnFailureListener(e->toast("Gagal membaca data toko: "+e.getLocalizedMessage()));
    }else{
      db.collection(collection).document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca data: "+e.getLocalizedMessage()));
    }
  }
  private void saveDailyInput(String page,DatePicker date,Map<String,EditText> inputs,Button save,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    boolean store=page.equals("Input Toko");
    boolean elevated="cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole);
    if(store&&!elevated){toast("Hanya COS/ACOS yang dapat menginput data toko.");return;}
    if(!store&&!("crew".equals(currentRole)||elevated)){toast("Jabatan ini tidak memiliki akses input PL.");return;}
    String selectedNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();
    if(!store&&!selectedNik.matches("\\d{8}")){toast("NIK Crew harus 8 angka.");return;}
    if(!store&&!elevated&&!selectedNik.equals(currentNik)){toast("Crew hanya dapat menginput data miliknya sendiri.");return;}
    String dateText=selectedDate(date),day=selectedDateKey(date);String id=store?storeCode+"_"+day:selectedNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    Map<String,Object> data=new HashMap<>();data.put("date",dateText);data.put("dateKey",day);data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("ownerNik",currentNik);data.put("ownerName",currentName);data.put("ownerRole",currentRole);
    if(!store){data.put("targetNik",selectedNik);data.put("targetName",selectedNik.equals(currentNik)?currentName:"Crew "+selectedNik);}
    try{
      for(String key:inputs.keySet()){
        String raw=inputs.get(key).getText().toString().trim().replace("%","");
        if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');
        if(raw.isEmpty()){toast("Indikator "+key+" wajib diisi.");return;}
        double value=Double.parseDouble(raw);
        if((!key.equalsIgnoreCase("NSB")&&value<0)||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Nilai "+key+" tidak valid.");return;}
        if(!key.equalsIgnoreCase("NSB")&&value<=0){toast(key+" harus lebih dari 0.");return;}
        data.put(key,isDecimalMetric(key)?value:(long)value);
      }
    }catch(NumberFormatException ex){toast("Pastikan semua indikator diisi dengan angka yang valid.");return;}
    StringBuilder summary=new StringBuilder("Tanggal: ").append(dateText).append("\nToko: ").append(storeCode).append(" - ").append(storeName).append("\n\n");
    for(String key:inputs.keySet())summary.append(key).append(": ").append(inputs.get(key).getText().toString()).append("\n");
    new AlertDialog.Builder(this).setTitle("Konfirmasi Data Harian").setMessage(summary.toString()).setNegativeButton("Periksa Kembali",(d,w)->{}).setPositiveButton("Konfirmasi & Simpan",(d,w)->{
      save.setEnabled(false);save.setText("Menyimpan...");
      java.util.function.Consumer<DocumentSnapshot> persistAfterRead = oldDoc -> {
        boolean existed=oldDoc!=null&&oldDoc.exists();Map<String,Object> oldValues=existed?new HashMap<>(oldDoc.getData()):new HashMap<>();
        data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
        data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedByRole",currentRole);
        if(!existed){data.put("firstSavedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());Calendar now=Calendar.getInstance();data.put("isLate",now.get(Calendar.HOUR_OF_DAY)>=23);}
        else {Object first=oldDoc.get("firstSavedAt");if(first!=null)data.put("firstSavedAt",first);Object late=oldDoc.get("isLate");data.put("isLate",late instanceof Boolean?(Boolean)late:false);}
        com.google.firebase.firestore.WriteBatch batch=db.batch();com.google.firebase.firestore.DocumentReference reportRef=db.collection(collection).document(id);batch.set(reportRef,data,SetOptions.merge());
        if(existed){Map<String,Object> audit=new HashMap<>();audit.put("date",dateText);audit.put("storeCode",storeCode);audit.put("editedByNik",currentNik);audit.put("editedByName",currentName);audit.put("editedByRole",currentRole);audit.put("editedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());audit.put("oldValues",oldValues);audit.put("newValues",new HashMap<>(data));batch.set(reportRef.collection("EditHistory").document(),audit);}
        batch.commit().addOnSuccessListener(unused->{
          save.setEnabled(true);save.setText("Simpan");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));
          toast(existed?"Data berhasil diperbarui. Riwayat koreksi dicatat.":"Data harian berhasil disimpan.");
          if(store) showDashboard("Beranda");
        }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal menyimpan. Periksa Firestore Rules: "+e.getLocalizedMessage());});
      };
      if(store){
        // Cek keberadaan laporan melalui query toko, bukan get() langsung pada ID yang mungkin belum ada.
        db.collection("DailyStoreReports").whereEqualTo("storeCode",storeCode).get()
          .addOnSuccessListener(snapshot->{DocumentSnapshot found=null;for(DocumentSnapshot candidate:snapshot.getDocuments())if(day.equals(candidate.getString("dateKey"))){found=candidate;break;}persistAfterRead.accept(found);})
          .addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal memeriksa laporan toko: "+e.getLocalizedMessage());});
      }else{
        db.collection(collection).document(id).get().addOnSuccessListener(persistAfterRead::accept)
          .addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal memeriksa data sebelumnya: "+e.getLocalizedMessage());});
      }
    }).show();
  }


  private void showStoreTypeSettings(LinearLayout body){
    cardTitle(body,"PENGATURAN JENIS TOKO");
    body.addView(txt("Atur jenis toko satu kali. Aplikasi akan membacanya otomatis saat personil login.",12,MUTED,false),field());
    EditText code=registerField(body,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText name=registerField(body,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    Spinner type=new Spinner(this);String[] types={"Pilih Jenis Toko","24 Jam","Normal"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));body.addView(type,field());
    Button load=smallButton("Cek Data Toko");body.addView(load,field());
    load.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US);if(c.isEmpty()){toast("Masukkan kode toko.");return;}db.collection("Stores").document(c).get().addOnSuccessListener(d->{if(d.exists()){name.setText(d.getString("storeName")==null?"":d.getString("storeName"));String t=firstNonEmpty(d.getString("storeType"),d.getString("type"));type.setSelection("24_JAM".equals(t)?1:"NORMAL".equals(t)?2:0);toast("Data toko ditemukan.");}else toast("Dokumen master toko belum ada. Simpan untuk membuatnya.");}).addOnFailureListener(e->toast("Gagal membaca toko: "+e.getLocalizedMessage()));});
    Button save=primary("Simpan Jenis Toko");body.addView(save,field());
    save.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US),n=name.getText().toString().trim();int selected=type.getSelectedItemPosition();if(c.isEmpty()||n.isEmpty()||selected==0){toast("Lengkapi kode, nama, dan jenis toko.");return;}String t=selected==1?"24_JAM":"NORMAL";Map<String,Object> data=new HashMap<>();data.put("storeCode",c);data.put("storeName",n);data.put("storeType",t);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());data.put("updatedBy","AdminUtama");save.setEnabled(false);db.collection("Stores").document(c).set(data,SetOptions.merge()).addOnSuccessListener(x->{save.setEnabled(true);toast("Jenis toko "+t.replace('_',' ')+" berhasil disimpan untuk "+c+".");}).addOnFailureListener(e->{save.setEnabled(true);toast("Gagal menyimpan. Pastikan Firestore Rules mengizinkan Admin Utama mengubah master Stores: "+e.getLocalizedMessage());});});
  }


  private void openDrawerDestination(FrameLayout screen,String choice){
    screen.removeViewAt(screen.getChildCount()-1);
    if("Keluar".equals(choice)){if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();}
    else if("Input PL Crew".equals(choice)){showDashboard("Input PL Crew");}
    else if("Input Laporan Sales".equals(choice)){showDashboard("Input Toko");}
    else{showDashboard(choice);}
  }
  private void showNavigationDrawer(FrameLayout screen){
    if(screen.getChildCount()>1)return;
    LinearLayout overlay= new LinearLayout(this);overlay.setOrientation(0);overlay.setBackgroundColor(0x66000000);
    LinearLayout drawer=col();drawer.setBackground(shape(Color.WHITE,0xffe5e7eb,dp(22)));drawer.setClipToPadding(false);drawer.setPadding(dp(14),dp(14),dp(14),dp(10));
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);scroll.addView(drawer);
    int width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(58),dp(390));
    overlay.addView(scroll,new LinearLayout.LayoutParams(width,-1));
    View dim=new View(this);overlay.addView(dim,new LinearLayout.LayoutParams(0,-1,1));
    dim.setOnClickListener(v->screen.removeView(overlay));
    LinearLayout profile=row();profile.setPadding(dp(16),dp(17),dp(14),dp(17));profile.setBackgroundResource(R.drawable.drawer_profile_header);
    FrameLayout drawerAvatarFrame=new FrameLayout(this);
    LinearLayout.LayoutParams drawerPhotoParams=new LinearLayout.LayoutParams(dp(58),dp(58));drawerPhotoParams.rightMargin=dp(13);
    profile.addView(drawerAvatarFrame,drawerPhotoParams);
    ImageView drawerPhoto=new ImageView(this);drawerPhoto.setImageResource(R.drawable.profile_icon_user);drawerPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);drawerPhoto.setBackground(shape(Color.WHITE,Color.WHITE,dp(30)));drawerPhoto.setClipToOutline(true);
    FrameLayout.LayoutParams drawerPhotoInnerParams=new FrameLayout.LayoutParams(dp(36),dp(36),Gravity.TOP|Gravity.CENTER_HORIZONTAL);drawerPhotoInnerParams.topMargin=dp(5);drawerAvatarFrame.addView(drawerPhoto,drawerPhotoInnerParams);
    int profileFrameRes=getRoleProfileFrameResource();
    if(profileFrameRes!=0){ImageView roleFrame=new ImageView(this);roleFrame.setImageResource(profileFrameRes);roleFrame.setScaleType(ImageView.ScaleType.FIT_CENTER);drawerAvatarFrame.addView(roleFrame,new FrameLayout.LayoutParams(-1,-1));}
    else{drawerPhoto.setBackground(shape(Color.WHITE,Color.WHITE,dp(40)));}
    loadDrawerProfilePhoto(drawerPhoto);
    LinearLayout profileInfo=col();profileInfo.setGravity(Gravity.CENTER_VERTICAL);
    TextView profileName=txt(currentName==null||currentName.isEmpty()?"Personil":currentName,17,Color.WHITE,true);
    profileInfo.addView(profileName,lp(-2));
    String role=roleLabel();String identity=("admin_utama".equals(currentRole)?"Admin Utama":"NIK "+currentNik);
    profileInfo.addView(txt(role+" • "+identity,12,Color.WHITE,false),lp(-2));
    profileInfo.addView(txt("Toko "+(storeCode==null?"":storeCode)+" - "+(storeName==null?"":storeName),12,Color.WHITE,false),lp(-2));
    profile.addView(profileInfo,new LinearLayout.LayoutParams(0,-2,1));
    drawer.addView(profile,lp(-2));
    drawer.addView(drawerHeading("MENU UTAMA"));
    addDrawerItem(drawer,"⌂","Beranda",screen);
    if("admin_utama".equals(currentRole)){
      drawer.addView(drawerHeading("ADMINISTRASI"));
      addDrawerItem(drawer,"▣","Pengaturan Jenis Toko",screen);
      addDrawerItem(drawer,"✓","Verifikasi Pendaftaran",screen);
      addDrawerItem(drawer,"↗","Permohonan Karir",screen);
      addDrawerItem(drawer,"⇄","Mutasi Personil",screen);
    }else{
      drawer.addView(drawerHeading("INPUT DATA"));
      if("cos".equals(currentRole)||"acos".equals(currentRole)){
        addDrawerItem(drawer,"◎","Input Target IKT",screen);
        addDrawerItem(drawer,"◇","Input Target Penawaran Langsung",screen);
        addDrawerItem(drawer,"▤","Input Laporan Sales",screen);
        addDrawerItem(drawer,"♧","Input PL Crew",screen);
      }else{
        addDrawerItem(drawer,"✎","Input PL",screen);
      }
      drawer.addView(drawerHeading("MONITORING & EVALUASI"));
      addDrawerItem(drawer,"🏆","Ranking Crew",screen);
      addDrawerItem(drawer,"♙","Reward",screen);
      addDrawerItem(drawer,"▤","Laporan Penjualan",screen);
      drawer.addView(drawerHeading("AKUN"));
      addDrawerItem(drawer,"♙","Profil",screen);
    }
    addDrawerItem(drawer,"⇥","Keluar",screen);
    View separator=new View(this);separator.setBackgroundColor(0xffd9dce2);LinearLayout.LayoutParams sep=new LinearLayout.LayoutParams(-1,dp(1));sep.topMargin=dp(14);sep.bottomMargin=dp(14);drawer.addView(separator,sep);
    ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.alfamart_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(150),dp(48));logoParams.gravity=Gravity.CENTER;drawer.addView(logo,logoParams);
    drawer.addView(center("IKT Monitoring  "+BuildConfig.VERSION_NAME,13,MUTED,true),lp(-2));
    FrameLayout.LayoutParams overlayParams=new FrameLayout.LayoutParams(-1,-1);screen.addView(overlay,overlayParams);
  }
  private TextView drawerHeading(String label){
    TextView h=txt(label,12,MUTED,true);h.setPadding(dp(5),dp(12),0,dp(5));return h;
  }
  private int drawerIconFor(String label){
    if("Beranda".equals(label))return R.drawable.nav_icon_home;
    if("Input PL".equals(label)||"Input PL Crew".equals(label))return R.drawable.nav_icon_ticket;
    if("Ranking Crew".equals(label))return R.drawable.nav_icon_trophy;
    if("Input Laporan Sales".equals(label))return R.drawable.dashboard_icon_clipboard;
    if("Laporan Penjualan".equals(label))return R.drawable.nav_icon_report;
    if("Profil".equals(label))return R.drawable.nav_icon_profile;
    if("Reward".equals(label))return R.drawable.dashboard_icon_gift;
    if("Input Target IKT".equals(label))return R.drawable.dashboard_icon_target;
    if("Input Target Penawaran Langsung".equals(label))return R.drawable.drawer_icon_tag;
    if("Keluar".equals(label))return R.drawable.drawer_icon_logout;
    if("Pengaturan Jenis Toko".equals(label))return R.drawable.profile_icon_store;
    if("Verifikasi Pendaftaran".equals(label))return R.drawable.dashboard_icon_clipboard;
    if("Permohonan Karir".equals(label))return R.drawable.profile_icon_job;
    if("Mutasi Personil".equals(label))return R.drawable.profile_icon_layers;
    return R.drawable.nav_icon_report;
  }
  private void addDrawerItem(LinearLayout drawer,String glyph,String label,FrameLayout screen){
    boolean active="Beranda".equals(label);
    LinearLayout item=row();item.setPadding(dp(10),dp(7),dp(8),dp(7));item.setBackground(active?shape(SOFT_RED,0,dp(12)):shape(Color.WHITE,0,dp(12)));
    ImageView icon=new ImageView(this);int iconRes=drawerIconFor(label);icon.setImageResource(iconRes);icon.setColorFilter(RED);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(36),dp(32));item.addView(icon,iconParams);
    TextView title=txt(label,15,DARK,true);LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0,-2,1);titleParams.leftMargin=dp(10);item.addView(title,titleParams);
    if(!"Keluar".equals(label)){item.addView(txt("›",25,DARK,true));}
    drawer.addView(item,lp(-2));
    View line=new View(this);line.setBackgroundColor(0xffe3e5e9);LinearLayout.LayoutParams lineParams=new LinearLayout.LayoutParams(-1,dp(1));lineParams.leftMargin=dp(54);drawer.addView(line,lineParams);
    item.setOnClickListener(v->openDrawerDestination(screen,label));
  }
  private String[] menuEntries(){
    if("admin_utama".equals(currentRole))return new String[]{"Beranda","Pengaturan Jenis Toko","Verifikasi Pendaftaran","Permohonan Karir","Mutasi Personil"};
    if("cos".equals(currentRole)||"acos".equals(currentRole))return new String[]{"Beranda","Input Target IKT","Input Target Penawaran Langsung","Input Laporan Sales","Input PL Crew","Ranking Crew","Reward","Laporan Penjualan","Profil","Keluar"};
    return new String[]{"Beranda","Input PL","Ranking Crew","Laporan Penjualan","Profil","Keluar"};
  }
  private String monthKey(DatePicker date){return String.format(Locale.US,"%04d%02d",date.getYear(),date.getMonth()+1);}
  // Tampilan angka tidak mengubah nilai numerik yang disimpan di Firestore.
  private String cleanNumber(Object value, boolean decimalAllowed){
    if(value==null)return "0";
    try{
      double n=Double.parseDouble(String.valueOf(value).replace(",","."));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0";
      if(!decimalAllowed || n==Math.rint(n))return String.format(Locale.US,"%.0f",n);
      return String.format(Locale.US,"%s",new java.math.BigDecimal(String.valueOf(n)).stripTrailingZeros().toPlainString());
    }catch(Exception e){return String.valueOf(value);}
  }
  // Margin disimpan sebagai angka (mis. 12.52), tetapi selalu ditampilkan 2 desimal dengan koma dan %.
  private String formatMargin(Object value){
    try{
      double n=Double.parseDouble(String.valueOf(value).trim().replace("%","").replace(',','.'));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0,00%";
      return String.format(new Locale("id","ID"),"%.2f%%",n);
    }catch(Exception e){return "0,00%";}
  }
  private String formatGroupedInteger(Object value){
    try{java.math.BigDecimal n=new java.math.BigDecimal(String.valueOf(value).replace(",","."));return String.format(new Locale("id","ID"),"%,.0f",n.doubleValue());}catch(Exception e){return "0";}
  }
  private int getRoleProfileFrameResource(){
    if("cos".equals(currentRole))return R.drawable.profile_frame_cos;
    if("acos".equals(currentRole))return R.drawable.profile_frame_acos;
    if("crew".equals(currentRole))return R.drawable.profile_frame_crew;
    return 0;
  }
  private FrameLayout createRoleProfileAvatar(int frameSize,int photoSize){
    FrameLayout frame=new FrameLayout(this);frame.setClipChildren(false);frame.setClipToPadding(false);
    ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.profile_icon_user);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(shape(Color.WHITE,Color.WHITE,dp(photoSize/2)));photo.setClipToOutline(true);
    FrameLayout.LayoutParams photoParams=new FrameLayout.LayoutParams(photoSize,photoSize,Gravity.TOP|Gravity.CENTER_HORIZONTAL);photoParams.topMargin=dp(Math.max(2,(frameSize-photoSize)/3));frame.addView(photo,photoParams);
    int frameRes=getRoleProfileFrameResource();if(frameRes!=0){ImageView emblem=new ImageView(this);emblem.setImageResource(frameRes);emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);frame.addView(emblem,new FrameLayout.LayoutParams(-1,-1));}
    loadDrawerProfilePhoto(photo);return frame;
  }
  private String profileDocumentId(){return currentRole!=null&&currentRole.equals("admin_utama")?"AdminUtama":currentNik;}
  private void chooseProfilePhoto(){Intent intent=new Intent(Intent.ACTION_GET_CONTENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(intent,"Pilih foto profil"),PICK_PROFILE_PHOTO);}
  private void loadProfilePhoto(){if(db==null)return;String docId=profileDocumentId();if(docId==null||docId.isEmpty())return;db.collection("Users").document(docId).get().addOnSuccessListener(doc->{String url=doc.getString("profilePhotoUrl");if(url!=null&&!url.isEmpty()&&storage!=null){storage.getReferenceFromUrl(url).getBytes(4*1024*1024).addOnSuccessListener(bytes->{if(profileAvatar!=null)profileAvatar.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length));}).addOnFailureListener(e->toast("Foto profil gagal dimuat."));}});}
  private void loadDrawerProfilePhoto(ImageView target){if(db==null||target==null)return;String docId=profileDocumentId();if(docId==null||docId.isEmpty())return;db.collection("Users").document(docId).get().addOnSuccessListener(doc->{String url=doc.getString("profilePhotoUrl");if(url!=null&&!url.isEmpty()&&storage!=null){storage.getReferenceFromUrl(url).getBytes(4*1024*1024).addOnSuccessListener(bytes->{if(target.getParent()!=null)target.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length));});}});}
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_PROFILE_PHOTO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri source=data.getData();Uri destination=Uri.fromFile(new File(getCacheDir(),"profile_crop_"+System.currentTimeMillis()+".jpg"));UCrop.of(source,destination).withAspectRatio(1,1).withMaxResultSize(900,900).start(this);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==RESULT_OK&&data!=null){Uri cropped=UCrop.getOutput(data);if(cropped!=null)uploadProfilePhoto(cropped);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==UCrop.RESULT_ERROR&&data!=null){Throwable error=UCrop.getError(data);toast("Gagal memotong foto: "+(error==null?"coba foto lain":error.getLocalizedMessage()));}}
  private void uploadProfilePhoto(Uri uri){if(profileAvatar!=null)profileAvatar.setImageURI(uri);if(storage==null||auth==null||auth.getCurrentUser()==null||db==null){toast("Firebase Storage belum siap.");return;}String docId=profileDocumentId();String uid=auth.getCurrentUser().getUid();StorageReference ref=storage.getReference().child("profile_photos").child(uid+".jpg");toast("Mengunggah foto profil...");ref.putFile(uri).continueWithTask(task->{if(!task.isSuccessful())throw task.getException();return ref.getDownloadUrl();}).addOnSuccessListener(download->{Map<String,Object> update=new HashMap<>();update.put("profilePhotoUrl",download.toString());db.collection("Users").document(docId).update(update).addOnSuccessListener(v->toast("Foto profil berhasil disimpan.")).addOnFailureListener(e->toast("Foto terunggah, tetapi profil Firestore menolak penyimpanan URL. Periksa Rules."));}).addOnFailureListener(e->toast("Gagal mengunggah foto: "+e.getLocalizedMessage()));}
  private void configureMetricInput(EditText input,String key){
    if(isDecimalMetric(key)){
      input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
      input.setKeyListener(DigitsKeyListener.getInstance("0123456789,.%"));
      input.setHint("0,0 %");
    }else{
      input.setInputType(InputType.TYPE_CLASS_NUMBER);
      input.setKeyListener(DigitsKeyListener.getInstance(key.equalsIgnoreCase("NSB")?"-0123456789.":(isRupiahMetric(key)?"0123456789.":"0123456789")));
    }
  }
  private void applyZeroFocusStyle(EditText input){
    input.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
    input.setOnFocusChangeListener((v,focused)->{
      String raw=input.getText().toString().trim().replace(",",".");
      boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
      input.setTypeface(Typeface.create("sans-serif",focused&&zero?Typeface.BOLD:Typeface.NORMAL));
    });
    input.addTextChangedListener(new TextWatcher(){
      boolean fixing=false;
      public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){
        if(input.hasFocus()){
          String raw=s.toString().trim().replace(",",".").replace("%","");
          boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
          input.setTypeface(Typeface.create("sans-serif",zero?Typeface.BOLD:Typeface.NORMAL));
        }
      }
      public void afterTextChanged(Editable e){
        if(fixing||!input.hasFocus()||e.length()<=1)return;
        if(e.charAt(0)=='0' && Character.isDigit(e.charAt(1))){fixing=true;e.delete(0,1);fixing=false;}
      }
    });
  }
  private boolean isDecimalMetric(String key){return key!=null&&key.toLowerCase(Locale.ROOT).contains("margin");}
  private boolean isRupiahMetric(String key){return key!=null&&(key.equalsIgnoreCase("Net Sales")||key.equalsIgnoreCase("NSB")||key.equalsIgnoreCase("APC")||key.equalsIgnoreCase("netSales")||key.equalsIgnoreCase("nsb")||key.equalsIgnoreCase("apc"));}
  private String formatRupiah(Object value){return "Rp "+String.format(Locale.US,"%,.0f",Double.parseDouble(cleanNumber(value,false))).replace(',','.');}
  private void loadMonthlyTarget(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return;String id=storeCode+"_"+monthKey(date);db.collection("MonthlyIKTTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca target: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyTarget(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target IKT.");return;}if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","");if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyIKTTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));toast("Target IKT bulanan berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target");toast("Gagal menyimpan target. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }
  private void addTargetPeriod(LinearLayout body,Map<String,EditText> inputs,String category,String period,String key){
    LinearLayout card=col(); card.setBackground(shape(Color.WHITE,0xffe5e9ef,dp(13))); card.setPadding(dp(12),dp(10),dp(12),dp(10));
    card.setTag("PLPERIOD:"+key); card.addView(txt(category+"  •  "+period,13,DARK,true)); EditText value=new EditText(this); value.setSingleLine(true); value.setText(""); value.setHint("Masukkan target"); value.setInputType(InputType.TYPE_CLASS_NUMBER); applyZeroFocusStyle(value); card.addView(value,lp(-2));
    LinearLayout.LayoutParams q=lp(-2); q.bottomMargin=dp(7); body.addView(card,q); inputs.put(key,value);
  }
  private LinearLayout rankingMenuCard(int iconRes,String title,String subtitle,boolean active,Runnable action){
    LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(12),dp(8),dp(12));
    card.setBackground(shape(active?RED:Color.WHITE,active?0xffe0a000:0xffe2e5eb,dp(14)));card.setElevation(dp(active?4:3));card.setClickable(true);card.setFocusable(true);
    ImageView symbol=new ImageView(this);symbol.setImageResource(iconRes);symbol.setScaleType(ImageView.ScaleType.FIT_CENTER);symbol.setColorFilter(active?Color.WHITE:RED);LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(42),dp(42));iconLp.rightMargin=dp(7);card.addView(symbol,iconLp);
    LinearLayout texts=col();texts.setGravity(Gravity.CENTER_VERTICAL);texts.addView(txt(title,14,active?Color.WHITE:DARK,true));TextView desc=txt(subtitle,10,active?0xffffeeee:MUTED,false);desc.setMaxLines(2);texts.addView(desc,lp(-2));card.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
    card.addView(txt("›",25,active?Color.WHITE:RED,true),new LinearLayout.LayoutParams(-2,-2));card.setOnClickListener(v->{if(action!=null)action.run();});
    return card;
  }

  private void setRankingMenuCardActive(LinearLayout card,boolean active){
    card.setBackground(shape(active?RED:Color.WHITE,active?0xffe0a000:0xffe2e5eb,dp(14)));card.setElevation(dp(active?4:3));
    if(card.getChildCount()>0&&card.getChildAt(0) instanceof ImageView)((ImageView)card.getChildAt(0)).setColorFilter(active?Color.WHITE:RED);
    if(card.getChildCount()>1&&card.getChildAt(1) instanceof LinearLayout){LinearLayout texts=(LinearLayout)card.getChildAt(1);if(texts.getChildCount()>0&&texts.getChildAt(0) instanceof TextView)((TextView)texts.getChildAt(0)).setTextColor(active?Color.WHITE:DARK);if(texts.getChildCount()>1&&texts.getChildAt(1) instanceof TextView)((TextView)texts.getChildAt(1)).setTextColor(active?0xffffeeee:MUTED);}
    if(card.getChildCount()>2&&card.getChildAt(2) instanceof TextView)((TextView)card.getChildAt(2)).setTextColor(active?Color.WHITE:RED);
  }

  private void loadCrewRanking(LinearLayout results,DatePicker picker,boolean monthly){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){results.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",13,RED,true),field());return;}
    if(!("acos".equals(currentRole)||"cos".equals(currentRole)||"crew".equals(currentRole))){results.addView(txt("Ranking perlu dibuka dari akun toko.",13,MUTED,false),field());return;}
    final int y=picker.getYear(),m=picker.getMonth()+1,d=picker.getDayOfMonth();
    final String month=String.format(Locale.US,"%04d%02d",y,m);
    final String from=monthly?String.format(Locale.US,"%04d%02d01",y,m):String.format(Locale.US,"%04d%02d%02d",y,m,d);
    final String to=monthly?String.format(Locale.US,"%04d%02d31",y,m):from;
    results.addView(txt("Menghitung ranking...",12,MUTED,false),field());
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()){results.removeAllViews();results.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",13,RED,false),field());return;}
      Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode).whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
      q.get().addOnSuccessListener(snapshot->{
        class RankRow {String nik,name;double score;double[] actual=new double[4];RankRow(String n,String nm){nik=n;name=nm;}}
        Map<String,RankRow> rows=new HashMap<>();
        Object rosterValue=targetDoc.get("crewRoster");
        if(rosterValue instanceof java.util.List){for(Object item:(java.util.List<?>)rosterValue){if(item instanceof Map){Map<?,?> member=(Map<?,?>)item;String memberNik=String.valueOf(member.get("nik"));if(memberNik.matches("\\d{8}")){String memberName=member.get("name")==null?memberNik:String.valueOf(member.get("name"));rows.put(memberNik,new RankRow(memberNik,memberName));}}}}
        for(DocumentSnapshot doc:snapshot.getDocuments()){
          String nik=doc.getString("targetNik");if(nik==null||nik.isEmpty())continue;
          String name=firstNonEmpty(doc.getString("targetName"),nik);RankRow rr=rows.get(nik);if(rr==null){rr=new RankRow(nik,name);rows.put(nik,rr);}
          rr.actual[0]+=num(doc.get("PSM"));rr.actual[1]+=num(doc.get("PWP"));rr.actual[2]+=num(doc.get("Serba Gratis"));rr.actual[3]+=num(doc.get("SUEGER"));
        }
        String[] categories={"PSM","PWP","Serba Gratis","SUEGER"};String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};double[] weights={.25,.25,.30,.20};double shifts="24_JAM".equals(storeType)?3.0:2.0;
        double[] denominators=new double[4];
        if(monthly){
          // Ranking Bulanan: akumulasi target Crew setiap periode (target harian x hari kerja).
          // Tidak dibagi jumlah Crew aktif.
          for(int c=0;c<4;c++)for(String key:periods[c]){
            double target=num(targetDoc.get(key)),days=num(targetDoc.get(key+"_DAYS"));
            if(target>0&&days>0)denominators[c]+=Math.ceil(target/days/shifts)*days;
          }
        }
        else {
          // Ranking Harian: target toko / hari kerja / jumlah shift. Tidak dibagi jumlah Crew.
          // Hasil pecahan dibulatkan ke atas agar target harian berupa bilangan bulat.
          int dayIndex=d;
          for(int c=0;c<4;c++){
            String key;
            if(c==0)key="PSM_W"+(dayIndex<=7?1:dayIndex<=15?2:dayIndex<=23?3:4);
            else key=categories[c].equals("PWP")?"PWP_P"+(dayIndex<=15?1:2):categories[c].equals("Serba Gratis")?"SG_P"+(dayIndex<=15?1:2):"SUEGER_P"+(dayIndex<=15?1:2);
            double target=num(targetDoc.get(key)),days=num(targetDoc.get(key+"_DAYS"));
            if(target>0&&days>0)denominators[c]=Math.ceil(target/days/shifts);
          }
        }
        ArrayList<RankRow> sorted=new ArrayList<>(rows.values());for(RankRow rr:sorted){double score=0;for(int c=0;c<4;c++){if(denominators[c]>0)score+=(rr.actual[c]/denominators[c])*weights[c]*100.0;}rr.score=score;}
        Collections.sort(sorted,(a,b)->Double.compare(b.score,a.score));results.removeAllViews();Calendar rankingDisplayDate=Calendar.getInstance();rankingDisplayDate.set(y,m-1,monthly?1:d);String rankingDateLabel=new SimpleDateFormat(monthly?"MMMM yyyy":"dd MMMM yyyy",new Locale("id","ID")).format(rankingDisplayDate.getTime()).toUpperCase(new Locale("id","ID"));cardTitle(results,(monthly?"Ranking Bulanan • ":"Ranking Harian • ")+rankingDateLabel);
        if(sorted.isEmpty()){results.addView(txt("Belum ada laporan Crew pada periode ini.",13,MUTED,false),field());return;}
        int rank=1;for(RankRow rr:sorted){
          int accent=rank==1?0xffd4a900:rank==2?0xff9aa0a8:rank==3?0xffb87333:0xffe5e9ef;
          int badgeColor=rank==1?0xffc99b00:rank==2?0xff858b94:rank==3?0xffad6b32:MUTED;
          LinearLayout card=col();card.setBackground(shape(Color.WHITE,rank<=3?accent:0xffe5e9ef,dp(14)));card.setPadding(dp(12),dp(10),dp(12),dp(10));
          if(rank<=3){View topBand=new View(this);topBand.setBackground(shape(accent,0,dp(5)));LinearLayout.LayoutParams bandLp=new LinearLayout.LayoutParams(-1,dp(6));bandLp.bottomMargin=dp(8);card.addView(topBand,bandLp);}
          LinearLayout content=row();content.setGravity(Gravity.CENTER_VERTICAL);
          LinearLayout emblem=col();emblem.setGravity(Gravity.CENTER);emblem.setMinimumWidth(dp(54));
          if(rank<=3){
            int medalBg=rank==1?0xfffff0bd:rank==2?0xffeef1f5:0xffffe7d9;
            int medalStroke=rank==1?0xffd4a900:rank==2?0xff9aa0a8:0xffb87333;
            LinearLayout medal=col();medal.setGravity(Gravity.CENTER);medal.setPadding(dp(5),dp(5),dp(5),dp(5));
            medal.setBackground(shape(medalBg,medalStroke,dp(12)));
            ImageView trophyIcon=new ImageView(this);trophyIcon.setImageResource(rank==1?R.drawable.rank_trophy_gold:rank==2?R.drawable.rank_trophy_silver:R.drawable.rank_trophy_bronze);trophyIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams trophyLp=new LinearLayout.LayoutParams(dp(48),dp(48));medal.addView(trophyIcon,trophyLp);
            TextView medalNo=center("#"+rank,15,Color.WHITE,true);medalNo.setBackground(shape(medalStroke,0,dp(18)));medalNo.setPadding(dp(10),dp(3),dp(10),dp(3));LinearLayout.LayoutParams noLp=lp(-2);noLp.topMargin=dp(2);medal.addView(medalNo,noLp);
            TextView medalLabel=center(rank==1?"JUARA EMAS":rank==2?"JUARA PERAK":"JUARA PERUNGGU",8,badgeColor,true);LinearLayout.LayoutParams labelLp=lp(-2);labelLp.topMargin=dp(2);medal.addView(medalLabel,labelLp);
            emblem.addView(medal,new LinearLayout.LayoutParams(dp(50),-2));
          }else{
            TextView plainRank=center(String.valueOf(rank),23,MUTED,true);plainRank.setBackground(shape(0xfff3f4f6,0xffe5e9ef,dp(10)));plainRank.setPadding(0,0,0,0);LinearLayout.LayoutParams plainRankLp=new LinearLayout.LayoutParams(dp(50),dp(48));plainRankLp.gravity=Gravity.CENTER;emblem.addView(plainRank,plainRankLp);
          }
          content.addView(emblem,new LinearLayout.LayoutParams(dp(58),-2));
          LinearLayout details=col();details.addView(txt(rr.name,14,DARK,true));details.addView(txt("NIK "+rr.nik+"  •  Nilai "+String.format(Locale.US,"%.2f",rr.score)+"%",12,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true));
          for(int c=0;c<4;c++)details.addView(txt(categories[c]+": "+formatGroupedInteger(rr.actual[c])+" / target "+(denominators[c]>0?formatGroupedInteger(denominators[c]):"belum diatur"),11,MUTED,false));
          content.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView scorePill=center(String.format(Locale.US,"%.2f",rr.score)+"%",14,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true);scorePill.setPadding(dp(10),dp(10),dp(10),dp(10));scorePill.setBackground(shape(rank==1?0xffffedb0:rank==2?0xffedf0f3:rank==3?0xffffe1d2:0xffedf0f4,0,dp(24)));content.addView(scorePill,new LinearLayout.LayoutParams(-2,-2));card.addView(content,lp(-2));results.addView(card,field());rank++;}
      }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca laporan ranking: "+e.getLocalizedMessage(),13,RED,false),field());});
    }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca target ranking: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private static class AdvancedRankRow { String nik,name; double score; double[] actual=new double[4]; AdvancedRankRow(String n,String nm){nik=n;name=nm;} }

  private void loadCrewRankingAdvanced(LinearLayout results,DatePicker picker,boolean annual){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){results.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",13,RED,true),field());return;}
    if(!("acos".equals(currentRole)||"cos".equals(currentRole)||"crew".equals(currentRole))){results.addView(txt("Ranking perlu dibuka dari akun toko.",13,MUTED,false),field());return;}
    final int year=picker.getYear(),month=picker.getMonth()+1,day=picker.getDayOfMonth();
    final String from=annual?String.format(Locale.US,"%04d0101",year):String.format(Locale.US,"%04d%02d01",year,month);
    final String to=annual?String.format(Locale.US,"%04d1231",year):String.format(Locale.US,"%04d%02d%02d",year,month,monthDays(year,month));
    results.addView(txt(annual?"Menyusun raport Crew Januari–Desember...":"Menghitung ranking sesuai periode target...",12,MUTED,false),field());
    // Ranking Periode dan Raport Crew selalu satu toko penuh untuk semua akun toko.
    // Pembatasan data tetap dilakukan pada storeCode; jangan filter berdasarkan NIK login.
    Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode).whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    q.get().addOnSuccessListener(snapshot->{
      Map<String,AdvancedRankRow> rows=new HashMap<>();
      for(DocumentSnapshot doc:snapshot.getDocuments()){
        String nik=doc.getString("targetNik");if(nik==null||nik.isEmpty())continue;
        String dateKey=doc.getString("dateKey");if(dateKey==null)continue;
        AdvancedRankRow rr=rows.get(nik);if(rr==null){rr=new AdvancedRankRow(nik,firstNonEmpty(doc.getString("targetName"),nik));rows.put(nik,rr);}
        int docMonth=Integer.parseInt(dateKey.substring(4,6));int docDay=Integer.parseInt(dateKey.substring(6,8));
        for(int c=0;c<4;c++){
          boolean include=annual || (c==0 ? (docDay<=15)==(day<=15) : (docDay<=15)==(day<=15));
          if(include)rr.actual[c]+=num(doc.get(new String[]{"PSM","PWP","Serba Gratis","SUEGER"}[c]));
        }
      }
      if(annual)loadAnnualTargets(results,year,0,new double[4],rows);
      else db.collection("MonthlyPLTargets").document(storeCode+"_"+String.format(Locale.US,"%04d%02d",year,month)).get().addOnSuccessListener(target->{
        if(!target.exists()){results.removeAllViews();results.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",13,RED,false),field());return;}
        // Ranking Periode: tanggal 1-15 memakai PSM W1+W2; tanggal 16-akhir memakai W3+W4.
        // PWP, Serba Gratis, dan SUEGER memakai P1/P2. Target Crew = target harian x hari kerja.
        Object rosterValue=target.get("crewRoster");
        if(rosterValue instanceof java.util.List){for(Object item:(java.util.List<?>)rosterValue){if(item instanceof Map){Map<?,?> member=(Map<?,?>)item;String memberNik=String.valueOf(member.get("nik"));if(memberNik.matches("\\d{8}")){String memberName=member.get("name")==null?memberNik:String.valueOf(member.get("name"));rows.put(memberNik,new AdvancedRankRow(memberNik,memberName));}}}}
        double[] denominators=new double[4];
        String[][] keys=day<=15
          ?new String[][]{{"PSM_W1","PSM_W2"},{"PWP_P1"},{"SG_P1"},{"SUEGER_P1"}}
          :new String[][]{{"PSM_W3","PSM_W4"},{"PWP_P2"},{"SG_P2"},{"SUEGER_P2"}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        for(int c=0;c<4;c++)for(String key:keys[c]){
          double storeTarget=num(target.get(key)),days=num(target.get(key+"_DAYS"));
          if(storeTarget>0&&days>0)denominators[c]+=Math.ceil(storeTarget/days/shifts)*days;
        }
        renderAdvancedRanking(results,rows,denominators,"Ranking Periode • "+String.format(Locale.US,"%04d%02d",year,month),new String[]{"PSM","PWP","Serba Gratis","SUEGER"});
      }).addOnFailureListener(e->showRankingError(results,e));
    }).addOnFailureListener(e->showRankingError(results,e));
  }

  private int monthDays(int year,int month){Calendar c=new GregorianCalendar(year,month-1,1);return c.getActualMaximum(Calendar.DAY_OF_MONTH);}
  private interface AnnualTargetDone { void done(double[] denominators); }
  private void loadAnnualTargets(LinearLayout results,int year,int index,double[] denominators,Map<String,AdvancedRankRow> rows){
    if(index>=12){renderAdvancedRanking(results,rows,denominators,"Raport Crew • Tahun "+year,new String[]{"PSM","PWP","Serba Gratis","SUEGER"});return;}
    String month=String.format(Locale.US,"%04d%02d",year,index+1);
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(doc->{
      if(doc.exists()){
        Object rosterValue=doc.get("crewRoster");
        if(rosterValue instanceof java.util.List){for(Object item:(java.util.List<?>)rosterValue){if(item instanceof Map){Map<?,?> member=(Map<?,?>)item;String memberNik=String.valueOf(member.get("nik"));if(memberNik.matches("\\d{8}")){String memberName=member.get("name")==null?memberNik:String.valueOf(member.get("name"));if(!rows.containsKey(memberNik))rows.put(memberNik,new AdvancedRankRow(memberNik,memberName));}}}}
        String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        // Raport Crew tahunan: akumulasi target toko per periode / jumlah shift.
        // Tidak dibagi jumlah Crew aktif.
        for(int c=0;c<4;c++)for(String key:periods[c]){
          double storeTarget=num(doc.get(key)),days=num(doc.get(key+"_DAYS"));
          if(storeTarget>0&&days>0)denominators[c]+=Math.ceil(storeTarget/days/shifts)*days;
        }
      }
      loadAnnualTargets(results,year,index+1,denominators,rows);
    }).addOnFailureListener(e->showRankingError(results,e));
  }
  private void renderAdvancedRanking(LinearLayout results,Map<String,AdvancedRankRow> rows,double[] denominators,String title,String[] categories){
    results.removeAllViews();cardTitle(results,title);
    ArrayList<AdvancedRankRow> sorted=new ArrayList<>(rows.values());
    for(AdvancedRankRow rr:sorted){double score=0;for(int c=0;c<4;c++)if(denominators[c]>0)score+=(rr.actual[c]/denominators[c])*new double[]{.25,.25,.30,.20}[c]*100.0;rr.score=score;}
    Collections.sort(sorted,(a,b)->Double.compare(b.score,a.score));
    if(sorted.isEmpty()){results.addView(txt("Belum ada laporan Crew pada periode ini.",13,MUTED,false),field());return;}
    int rank=1;for(AdvancedRankRow rr:sorted){int accent=rank==1?0xffd4a900:rank==2?0xff9aa0a8:rank==3?0xffb87333:0xffe5e9ef;int badgeColor=rank==1?0xffc99b00:rank==2?0xff858b94:rank==3?0xffad6b32:MUTED;LinearLayout card=col();card.setBackground(shape(Color.WHITE,rank<=3?accent:0xffe5e9ef,dp(14)));card.setPadding(dp(12),dp(10),dp(12),dp(10));if(rank<=3){View band=new View(this);band.setBackground(shape(accent,0,dp(5)));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(6));bp.bottomMargin=dp(8);card.addView(band,bp);}LinearLayout content=row();content.setGravity(Gravity.CENTER_VERTICAL);LinearLayout emblem=col();emblem.setGravity(Gravity.CENTER);emblem.setMinimumWidth(dp(54));if(rank<=3){int medalBg=rank==1?0xfffff0bd:rank==2?0xffeef1f5:0xffffe7d9;int medalStroke=rank==1?0xffd4a900:rank==2?0xff9aa0a8:0xffb87333;LinearLayout medal=col();medal.setGravity(Gravity.CENTER);medal.setPadding(dp(5),dp(5),dp(5),dp(5));medal.setBackground(shape(medalBg,medalStroke,dp(12)));ImageView trophyIcon=new ImageView(this);trophyIcon.setImageResource(rank==1?R.drawable.rank_trophy_gold:rank==2?R.drawable.rank_trophy_silver:R.drawable.rank_trophy_bronze);trophyIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams trophyLp=new LinearLayout.LayoutParams(dp(48),dp(48));medal.addView(trophyIcon,trophyLp);TextView medalNo=center("#"+rank,15,Color.WHITE,true);medalNo.setBackground(shape(medalStroke,0,dp(18)));medalNo.setPadding(dp(10),dp(3),dp(10),dp(3));LinearLayout.LayoutParams noLp=lp(-2);noLp.topMargin=dp(2);medal.addView(medalNo,noLp);TextView medalLabel=center(rank==1?"JUARA EMAS":rank==2?"JUARA PERAK":"JUARA PERUNGGU",8,badgeColor,true);LinearLayout.LayoutParams labelLp=lp(-2);labelLp.topMargin=dp(2);medal.addView(medalLabel,labelLp);emblem.addView(medal,new LinearLayout.LayoutParams(dp(50),-2));}else{TextView plainRank=center(String.valueOf(rank),23,MUTED,true);plainRank.setBackground(shape(0xfff3f4f6,0xffe5e9ef,dp(10)));plainRank.setPadding(0,0,0,0);LinearLayout.LayoutParams plainRankLp=new LinearLayout.LayoutParams(dp(50),dp(48));plainRankLp.gravity=Gravity.CENTER;emblem.addView(plainRank,plainRankLp);}content.addView(emblem,new LinearLayout.LayoutParams(dp(58),-2));LinearLayout details=col();details.setPadding(dp(10),0,dp(6),0);details.addView(txt(rr.name,14,DARK,true));details.addView(txt("NIK "+rr.nik+"  •  Nilai "+String.format(Locale.US,"%.2f",rr.score)+"%",12,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true));for(int c=0;c<4;c++)details.addView(txt(categories[c]+": "+formatGroupedInteger(rr.actual[c])+" / target "+(denominators[c]>0?formatGroupedInteger(denominators[c]):"belum diatur"),11,MUTED,false));content.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView pill=center(String.format(Locale.US,"%.2f",rr.score)+"%",14,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true);pill.setPadding(dp(10),dp(10),dp(10),dp(10));pill.setBackground(shape(rank==1?0xffffedb0:rank==2?0xffedf0f3:rank==3?0xffffe1d2:0xffedf0f4,0,dp(24)));content.addView(pill,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));card.addView(content,lp(-2));results.addView(card,field());rank++;}
  }
  private void showRankingError(LinearLayout results,Exception e){results.removeAllViews();results.addView(txt("Gagal membaca ranking: "+e.getLocalizedMessage(),13,RED,false),field());}

  private void addWorkdays(LinearLayout body,Map<String,EditText> inputs,String key){
    LinearLayout row=row();row.setTag("PLDAYS:"+key);row.setPadding(dp(8),dp(2),dp(8),dp(2));row.addView(txt("Hari kerja periode",11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));
    EditText days=new EditText(this);days.setSingleLine(true);days.setText("");days.setHint("Jumlah hari kerja");days.setInputType(InputType.TYPE_CLASS_NUMBER);days.setEms(5);applyZeroFocusStyle(days);row.addView(days);body.addView(row,field());inputs.put(key+"_DAYS",days);
  }
  private String activePLPeriodKey(DatePicker date){
    Calendar now=Calendar.getInstance();int y=date.getYear(),m=date.getMonth(),day=now.get(Calendar.DAY_OF_MONTH);
    if(y!=now.get(Calendar.YEAR)||m!=now.get(Calendar.MONTH))return "";
    if(day<=7)return "PSM_W1";if(day<=15)return "PSM_W2";if(day<=23)return "PSM_W3";return "PSM_W4";
  }
  private String activePLPeriodForCategory(String category,DatePicker date){
    Calendar now=Calendar.getInstance();if(date.getYear()!=now.get(Calendar.YEAR)||date.getMonth()!=now.get(Calendar.MONTH))return "";
    int day=now.get(Calendar.DAY_OF_MONTH);
    if("PSM".equals(category))return "PSM_W"+(day<=7?1:day<=15?2:day<=23?3:4);
    String suffix=day<=15?"P1":"P2";
    if("PWP".equals(category))return "PWP_"+suffix;
    if("Serba Gratis".equals(category))return "SG_"+suffix;
    return "SUEGER_"+suffix;
  }
  private void loadMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,String targetCode){
    if(db==null||targetCode==null||targetCode.isEmpty())return;String id=targetCode+"_"+monthKey(date);
    db.collection("MonthlyPLTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object v=doc.get(key);if(v!=null)inputs.get(key).setText(cleanNumber(v,false));}}).addOnFailureListener(e->toast("Gagal membaca target PL: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,Button save,String targetCode,String targetName){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS/Admin Utama yang dapat mengatur target.");return;}
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    if(!"admin_utama".equals(currentRole)&&!storeCode.equals(targetCode)){toast("COS/ACOS hanya dapat mengatur toko sendiri.");return;}
    Calendar now=Calendar.getInstance();if(date.getYear()!=now.get(Calendar.YEAR)||date.getMonth()!=now.get(Calendar.MONTH)){toast("Target hanya dapat disiapkan untuk bulan berjalan.");return;}
    int today=now.get(Calendar.DAY_OF_MONTH);int lastDay=now.getActualMaximum(Calendar.DAY_OF_MONTH);
    String[] keys={"PSM_W1","PSM_W2","PSM_W3","PSM_W4","PWP_P1","PWP_P2","SG_P1","SG_P2","SUEGER_P1","SUEGER_P2"};
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",targetCode);data.put("storeName",targetName==null||targetName.trim().isEmpty()?targetCode:targetName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedByRole",currentRole);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    int count=0;
    try{
      for(String key:keys){
        int periodEnd;
        if(key.equals("PSM_W1"))periodEnd=7;else if(key.equals("PSM_W2"))periodEnd=15;else if(key.equals("PSM_W3"))periodEnd=23;else if(key.equals("PSM_W4")||key.endsWith("_P2"))periodEnd=lastDay;else periodEnd=15;
        if(periodEnd<today)continue;
        EditText targetInput=inputs.get(key),daysInput=inputs.get(key+"_DAYS");
        String targetRaw=targetInput==null?"":targetInput.getText().toString().trim();
        String daysRaw=daysInput==null?"":daysInput.getText().toString().trim();
        if(targetRaw.isEmpty()&&daysRaw.isEmpty())continue;
        if(targetRaw.isEmpty()||daysRaw.isEmpty()){toast("Lengkapi target dan hari kerja untuk "+key+".");return;}
        double target=Double.parseDouble(targetRaw),days=Double.parseDouble(daysRaw);
        if(target<0||days<0||target!=Math.rint(target)||days!=Math.rint(days)||Double.isInfinite(target)||Double.isInfinite(days)||Double.isNaN(target)||Double.isNaN(days)){toast("Target dan hari kerja harus bilangan bulat tidak negatif.");return;}
        // Nilai awal 0/0 berarti periode belum disiapkan; lewati tanpa menggagalkan periode lain.
        if(target==0&&days==0)continue;
        if(days<=0){toast("Hari kerja harus lebih dari 0 untuk target "+key+".");return;}
        data.put(key,(long)target);data.put(key+"_DAYS",(long)days);count++;
      }
    }catch(NumberFormatException e){toast("Target dan hari kerja harus berupa angka bulat.");return;}
    if(count==0){toast("Isi minimal satu pasangan target dan hari kerja pada periode aktif atau mendatang.");return;}
    save.setEnabled(false);save.setText("Menghitung Crew...");
    // Hitung personil Crew aktif di toko saat target disimpan. Snapshot ini dipakai
    // konsisten oleh target individu, ranking harian/periode/bulanan, dan raport tahunan.
    // Roster diambil hanya dari subkoleksi Users milik toko target.
    // Tidak membaca koleksi global Personnel, sehingga tidak meminta akses lintas toko.
    db.collection("Stores").document(targetCode).collection("Users").get().addOnSuccessListener(personnel->{
      int activeCrew=0;
      ArrayList<Map<String,Object>> crewRoster=new ArrayList<>();
      for(DocumentSnapshot person:personnel.getDocuments()){
        String role=firstNonEmpty(person.getString("currentRole"),person.getString("role"));
        boolean active=Boolean.TRUE.equals(person.getBoolean("isActive"));
        if("crew".equals(role)&&active){
          activeCrew++;
          Map<String,Object> member=new HashMap<>();
          member.put("nik",firstNonEmpty(person.getString("nik"),person.getId()));
          member.put("name",firstNonEmpty(person.getString("name"),person.getId()));
          crewRoster.add(member);
        }
      }
      if(activeCrew<1){save.setEnabled(true);save.setText("Simpan Target Periode");toast("Tidak ditemukan Crew aktif di toko "+targetCode+". Periksa roster Users toko.");return;}
      final int savedCrewCount=activeCrew;
      data.put("crewCount",savedCrewCount);
      data.put("crewRoster",crewRoster);
      data.put("crewCountUpdatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
      db.collection("MonthlyPLTargets").document(targetCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target Periode");toast("Target periode berhasil disimpan untuk "+savedCrewCount+" Crew aktif. Target individu diperbarui.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target Periode");toast("Gagal menyimpan target PL: "+e.getLocalizedMessage());});
    }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target Periode");toast("Gagal menghitung Crew aktif dari roster toko "+targetCode+": "+e.getLocalizedMessage());});
  }

  private String roleLabel(){if("cos".equals(currentRole))return "COS";if("acos".equals(currentRole))return "ACOS";if("crew".equals(currentRole))return "Crew";return "Admin Utama";}
  private LinearLayout dashboardMenuTile(int iconResource,String label,String destination){
    LinearLayout tile=row();tile.setGravity(Gravity.CENTER_VERTICAL);tile.setPadding(dp(10),dp(10),dp(8),dp(10));tile.setBackground(shape(Color.WHITE,0xffffcbd3,dp(18)));tile.setElevation(dp(2));
    FrameLayout iconBox=new FrameLayout(this);iconBox.setBackground(shape(RED,0,dp(12)));ImageView icon=new ImageView(this);icon.setImageResource(iconResource);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams iconImageParams=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.CENTER);iconBox.addView(icon,iconImageParams);tile.addView(iconBox,new LinearLayout.LayoutParams(dp(48),dp(48)));
    View divider=new View(this);divider.setBackgroundColor(0xffffd5dc);LinearLayout.LayoutParams dividerParams=new LinearLayout.LayoutParams(dp(1),dp(48));dividerParams.leftMargin=dp(8);dividerParams.rightMargin=dp(8);tile.addView(divider,dividerParams);
    TextView title=txt(label,12,DARK,true);title.setMaxLines(3);title.setGravity(Gravity.CENTER_VERTICAL);tile.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    TextView arrow=center("›",27,RED,true);LinearLayout.LayoutParams arrowParams=new LinearLayout.LayoutParams(dp(18),-2);arrowParams.leftMargin=dp(3);tile.addView(arrow,arrowParams);
    tile.setOnClickListener(v->showDashboard(destination));return tile;
  }
  private void cardTitle(LinearLayout p,String s){TextView t=txt(s,16,DARK,true);t.setPadding(0,dp(16),0,dp(9));p.addView(t,lp(-2));}
  private View metricBox(String title,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe4e4e4,dp(10)));c.setPadding(dp(6),dp(12),dp(6),dp(12));c.addView(center(title,10,MUTED,false));c.addView(center(value,16,GREEN,true));return c;}
  private View metric(LinearLayout p,String title,String sub,String val,boolean unused){LinearLayout c=col();c.setBackground(shape(0xfffff5dc,0xffeadcae,dp(12)));c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(txt(title,14,DARK,true));c.addView(txt(sub+"  "+val,14,GREEN,true));p.addView(c,lp(-2));return c;}

  // Khusus Pencapaian per Indikator di Beranda Crew. Aktual hanya milik NIK login.
  // Target individu memakai snapshot jumlah Crew aktif yang disimpan bersama target toko.
  private void loadCrewIndicatorProgress(LinearLayout body){
    if(db==null||auth==null||auth.getCurrentUser()==null||currentNik==null||currentNik.trim().isEmpty()){
      body.addView(txt("Sesi Crew belum siap untuk membaca pencapaian.",12,RED,false),field());return;
    }
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){
      body.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",12,RED,false),field());return;
    }
    Calendar now=Calendar.getInstance();
    int y=now.get(Calendar.YEAR),m=now.get(Calendar.MONTH)+1;
    String month=String.format(Locale.US,"%04d%02d",y,m);
    String from=String.format(Locale.US,"%04d%02d01",y,m);
    String to=String.format(Locale.US,"%04d%02d31",y,m);
    TextView loading=txt("Memuat pencapaian indikator bulan berjalan...",12,MUTED,false);body.addView(loading,field());
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()) {
        body.removeView(loading);
        for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);
        body.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",12,RED,false),field());return;
      }
      Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode)
        .whereEqualTo("targetNik",currentNik)
        .whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
      q.get().addOnSuccessListener(snapshot->{
        body.removeView(loading);
        double[] actuals=new double[4];
        for(DocumentSnapshot doc:snapshot.getDocuments()){
          actuals[0]+=num(doc.get("PSM"));actuals[1]+=num(doc.get("PWP"));
          actuals[2]+=num(doc.get("Serba Gratis"));actuals[3]+=num(doc.get("SUEGER"));
        }
        String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        String[] labels={"PSM","PWP","Serba Gratis","SUEGER"};
        // HANYA target individu Crew: target toko per periode / hari kerja / jumlah shift,
        // dibulatkan ke atas. Tidak dibagi jumlah Crew. Rumus ranking/laporan tidak diubah.
        double[] crewTargets=new double[4];
        for(int c=0;c<4;c++){
          double crewTarget=0;
          for(String key:periods[c]){
            double target=num(targetDoc.get(key));double days=num(targetDoc.get(key+"_DAYS"));
            if(target>0&&days>0)crewTarget+=Math.ceil(target/days/shifts)*days;
          }
          crewTargets[c]=crewTarget;
          addPLProgressCard(body,labels[c],crewTarget,actuals[c]);
        }
        // Total pencapaian individu mengikuti empat indikator dan bobot PL resmi.
        double[] weights={.25,.25,.30,.20};double weighted=0;boolean any=false;
        for(int i=0;i<4;i++)if(crewTargets[i]>0){weighted+=Math.min(100.0,actuals[i]/crewTargets[i]*100.0)*weights[i];any=true;}
        addPLTotalCard(body,"Total Pencapaian Penawaran Langsung Saya",weighted,any);
      }).addOnFailureListener(e->{
        body.removeView(loading);
        body.addView(txt("Gagal membaca pencapaian Crew: "+e.getLocalizedMessage(),12,RED,false),field());
      });
    }).addOnFailureListener(e->{
      body.removeView(loading);
      body.addView(txt("Gagal membaca target PL: "+e.getLocalizedMessage(),12,RED,false),field());
    });
  }

  // Khusus kartu Progress Indikator PL Toko pada Dashboard.
  // Menggunakan rentang awal bulan s.d. hari ini dan akumulasi penuh
  // setiap periode target yang masuk ke rentang, sama dengan laporan sementara.
  private void loadPLStoreProgress(LinearLayout body){
    if(db==null||storeCode==null||storeCode.isEmpty()){
      for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);
      return;
    }
    Calendar end=Calendar.getInstance();
    Calendar start=(Calendar)end.clone();start.set(Calendar.DAY_OF_MONTH,1);
    String month=String.format(Locale.US,"%04d%02d",end.get(Calendar.YEAR),end.get(Calendar.MONTH)+1);
    final double shifts="24_JAM".equals(storeType)?3.0:2.0;
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      Map<String,DocumentSnapshot> docs=new HashMap<>();docs.put(month,targetDoc);
      PLTemporaryTotals totals=new PLTemporaryTotals();
      accumulatePLDashboardTarget(totals,docs,start,end,shifts);
      String from=new SimpleDateFormat("yyyyMMdd",Locale.US).format(start.getTime());
      String to=new SimpleDateFormat("yyyyMMdd",Locale.US).format(end.getTime());
      db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode)
        .whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to)
        .get().addOnSuccessListener(snapshot->{
          for(DocumentSnapshot doc:snapshot.getDocuments()){
            totals.actual[0]+=num(doc.get("PSM"));totals.actual[1]+=num(doc.get("PWP"));
            totals.actual[2]+=num(doc.get("Serba Gratis"));totals.actual[3]+=num(doc.get("SUEGER"));
          }
          String[] labels={"PSM","PWP","Serba Gratis","SUEGER"};
          for(int i=0;i<4;i++)addPLProgressCard(body,labels[i],totals.target[i],totals.actual[i]);
          double[] weights={.25,.25,.30,.20};double weighted=0;boolean any=false;
          for(int i=0;i<4;i++){if(totals.target[i]>0){weighted+=Math.min(100,totals.actual[i]/totals.target[i]*100)*weights[i];any=true;}}
          LinearLayout total=row();total.setGravity(Gravity.CENTER_VERTICAL);total.setPadding(dp(13),dp(12),dp(13),dp(12));
          int totalColor=any?plAchievementColor(weighted):MUTED;
          int totalBg=any?(weighted<=50.0?0xffffebee:weighted<80.0?0xfffff7e0:0xffe8f5e9):0xfff2f3f5;
          int totalBorder=any?(weighted<=50.0?0xffef9a9a:weighted<80.0?0xffffd54f:0xffa5d6a7):0xffd5d9df;
          total.setBackground(shape(totalBg,totalBorder,dp(16)));
          TextView emblem=txt("◎",14,totalColor,true);
          emblem.setPadding(0,0,dp(6),0);
          total.addView(emblem,new LinearLayout.LayoutParams(-2,-2));
          total.addView(txt("Total Pencapaian PL Toko",14,totalColor,true),new LinearLayout.LayoutParams(0,-2,1));
          total.addView(txt(any?String.format(Locale.US,"%.2f%%",weighted):"--",18,totalColor,true));
          LinearLayout.LayoutParams totalLp=lp(-2);totalLp.bottomMargin=dp(8);body.addView(total,totalLp);
        }).addOnFailureListener(e->{for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);});
    }).addOnFailureListener(e->{for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);});
  }
  private int plAchievementColor(double percent){
    if(percent<=50.0)return 0xffc62828;
    if(percent<80.0)return 0xffffb300;
    return 0xff18864b;
  }
  private int plCategoryStart(int index){return new int[]{0xffff1760,0xffffb000,0xff08a9ee,0xffa020f0}[Math.max(0,Math.min(3,index))];}
  private int plCategoryEnd(int index){return new int[]{0xffb00038,0xffe65a00,0xff0755c9,0xff5700b8}[Math.max(0,Math.min(3,index))];}
  private int plCategoryIndex(String name){if(name==null)return 0;String n=name.toLowerCase(Locale.US);if(n.contains("pwp"))return 1;if(n.contains("serba"))return 2;if(n.contains("sueger"))return 3;return 0;}
  private View plGradientBar(double percent,int startColor,int endColor,String label){
    final float progress=(float)Math.max(0,Math.min(100,percent));
    return new View(this){final android.graphics.Paint paint=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);protected void onDraw(android.graphics.Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight(),r=h/2f,fill=w*progress/100f;android.graphics.RectF track=new android.graphics.RectF(0,0,w,h);paint.setShader(null);paint.setColor(0xffe4e8f0);canvas.drawRoundRect(track,r,r,paint);if(fill>0){android.graphics.RectF area=new android.graphics.RectF(0,0,Math.max(h,fill),h);area.right=Math.min(w,fill);paint.setShader(new android.graphics.LinearGradient(0,0,Math.max(1,area.right),h,startColor,endColor,android.graphics.Shader.TileMode.CLAMP));canvas.save();android.graphics.Path clip=new android.graphics.Path();clip.addRoundRect(track,r,r,android.graphics.Path.Direction.CW);canvas.clipPath(clip);canvas.drawRoundRect(area,r,r,paint);paint.setShader(null);paint.setColor(0x44ffffff);paint.setStrokeWidth(dp(7));for(float x=-h;x<fill;x+=dp(28))canvas.drawLine(x,h,x+h,h*0.05f,paint);canvas.restore();}paint.setShader(null);paint.setColor(Color.WHITE);paint.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD));paint.setTextSize(dp(11));paint.setTextAlign(android.graphics.Paint.Align.RIGHT);float tx=progress>=25?Math.max(dp(42),fill-dp(9)):Math.min(w-dp(8),Math.max(dp(48),fill+dp(54)));if(progress<25)paint.setColor(DARK);canvas.drawText(label,tx,h/2f-(paint.ascent()+paint.descent())/2f,paint);}};
  }
  private void addPLProgressCard(LinearLayout parent,String name,double target,double actual){
    boolean ready=target>0;double percent=ready?actual/target*100.0:0;
    int status=ready?plAchievementColor(percent):MUTED;int category=plCategoryIndex(name);
    String icon=new String[]{"🛒","🧺","🎁","🥤"}[category];
    LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(17)));card.setElevation(dp(2));card.setPadding(dp(10),dp(10),dp(10),dp(10));
    LinearLayout tag=col();tag.setGravity(Gravity.CENTER);tag.setPadding(dp(4),dp(8),dp(4),dp(8));tag.setBackground(gradient(plCategoryStart(category),plCategoryEnd(category),dp(13)));
    tag.addView(center(icon,23,Color.WHITE,true));tag.addView(center(name.toUpperCase(Locale.US),10,Color.WHITE,true));card.addView(tag,new LinearLayout.LayoutParams(dp(76),dp(104)));
    LinearLayout content=col();content.setPadding(dp(9),0,0,0);
    LinearLayout metrics=row();metrics.setGravity(Gravity.CENTER_VERTICAL);
    addPLMetric(metrics,"TARGET",ready?formatGroupedInteger(target):"—",DARK,true);
    addPLMetric(metrics,"AKTUAL",formatGroupedInteger(actual),GREEN,true);
    if(ready&&actual>target){addPLMetric(metrics,"+Qty","+"+formatGroupedInteger(actual-target)+" Qty",0xff16864b,false);}
    else addPLMetric(metrics,"GAP",ready?formatGroupedInteger(Math.max(0,target-actual)):"—",ready&&actual<target?0xffc62828:0xff16864b,false);
    content.addView(metrics,lp(-2));
    LinearLayout statusRow=row();statusRow.setGravity(Gravity.CENTER_VERTICAL);
    String statusText=!ready?"Target belum diatur":actual>=target?(actual>target?"✓ Tercapai • Melebihi Target +"+formatGroupedInteger(actual-target)+" Qty":"✓ Tercapai"):"✕ Tidak Tercapai";
    statusRow.addView(txt(statusText,10,ready&&actual>=target?0xff16864b:ready?0xffbd2638:MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
    TextView percentBadge=txt(ready?String.format(Locale.US,"%.2f%%",percent):"—",15,status,true);percentBadge.setGravity(Gravity.CENTER);percentBadge.setPadding(dp(8),dp(4),dp(8),dp(4));percentBadge.setBackground(shape(ready?(percent<=50?0xffffebee:percent<80?0xfffff7e0:0xffe8f5e9):0xfff2f3f5,0,dp(18)));statusRow.addView(percentBadge);content.addView(statusRow,topMargin(5));
    View bar=plGradientBar(percent,plCategoryStart(category),plCategoryEnd(category),ready?String.format(Locale.US,"%.2f%%",percent):"—");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(25));bp.topMargin=dp(7);content.addView(bar,bp);
    card.addView(content,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(9);parent.addView(card,q);
  }

  private void addPLTotalCard(LinearLayout parent,String title,double percent,boolean hasData){
    int color=hasData?plAchievementColor(percent):MUTED;
    int bg=hasData?(percent<=50?0xffffebee:percent<80?0xfffff7e0:0xffe8f5e9):0xfff2f3f5;
    int border=hasData?(percent<=50?0xffef9a9a:percent<80?0xffffd54f:0xffa5d6a7):0xffd5d9df;
    LinearLayout total=row();total.setGravity(Gravity.CENTER_VERTICAL);total.setPadding(dp(13),dp(12),dp(13),dp(12));total.setBackground(shape(bg,border,dp(16)));
    total.addView(txt("🏆",18,color,true),new LinearLayout.LayoutParams(-2,-2));
    TextView label=txt(title,14,color,true);label.setPadding(dp(8),0,dp(5),0);total.addView(label,new LinearLayout.LayoutParams(0,-2,1));
    TextView value=txt(hasData?String.format(Locale.US,"%.2f%%",percent):"--",18,color,true);value.setGravity(Gravity.CENTER);value.setPadding(dp(12),dp(5),dp(12),dp(5));value.setBackground(shape(hasData?(percent<=50?0xffc62828:percent<80?0xffffb300:0xff18864b):0xff9e9e9e,0,dp(22)));if(hasData)value.setTextColor(Color.WHITE);total.addView(value);
    LinearLayout.LayoutParams lp=lp(-2);lp.topMargin=dp(2);lp.bottomMargin=dp(10);parent.addView(total,lp);
  }

  private void progressRow(LinearLayout p,String name,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(15)));c.setElevation(dp(1));c.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout top=row();top.addView(txt(name,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(txt("—",13,MUTED,true));c.addView(top);TextView sub=txt(value,11,MUTED,false);sub.setPadding(0,dp(4),0,dp(8));c.addView(sub);ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffedf0f4));c.addView(bar,lp(7));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(8);p.addView(c,q);}
  private void detail(LinearLayout p,String k,String v){LinearLayout r=row();r.setPadding(dp(10),dp(13),dp(10),dp(13));r.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(14)));r.addView(txt(k,13,DARK,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,DARK,true));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(5);p.addView(r,q);}
  private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setTextColor(RED);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));return b;}
  private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));b.setMinHeight(dp(48));return b;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(auth!=null&&auth.getCurrentUser()!=null){showDashboard("Beranda");}else showLogin();}
}
