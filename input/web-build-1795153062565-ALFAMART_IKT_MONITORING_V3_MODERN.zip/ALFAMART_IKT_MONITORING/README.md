# ALFAMART IKT MONITORING - starter source

## Login implementation in this revision
- Admin Utama: Firebase Authentication Email/Password, then profile validation in `Users/AdminUtama` (`isActive=true`, `role=admin_utama`).
- Personnel: NIK (8 digits) + PIN (6 digits). The app maps NIK to the Firebase Auth email alias `<NIK>@ikt-monitoring.app`, signs in with Firebase Authentication, then reads `Users/<NIK>` and checks `isActive=true` and a non-admin role.
- PIN/password is authenticated by Firebase Authentication; this code does not write PIN values to Firestore.

## Required setup before personnel login can work
1. In Firebase Authentication, create one Email/Password account for each personnel member. Use the email alias `<NIK>@ikt-monitoring.app` and set the initial password to that person's 6-digit PIN.
2. The Firestore `Users` collection must contain a document whose document ID is that person's 8-digit NIK. It must contain `isActive: true` and a valid non-`admin_utama` `role`. The `name` field is optional.
3. Update Firestore Security Rules to permit each authenticated personnel account to read only its own `Users/<NIK>` profile. The current project rules were admin-only and will block personnel profile reads until deliberately updated. Do not open the database to public access.
4. For Admin Utama, keep the existing separate Firebase Auth email/password account and the `Users/AdminUtama` profile. Its `email`, `role: admin_utama`, and `isActive: true` must match.

## Important security note
A six-digit PIN has low entropy. Firebase Authentication password protection and sign-in throttling help, but this is a Spark-plan compromise rather than the stronger server-side NIK/PIN verification with rate limiting that could be implemented using a trusted backend. Never store PINs in Firestore or expose an unrestricted database rule.

## Build
Open this project in Android Studio / AndroidForge with the matching `google-services.json`, then build the APK. This environment did not have Gradle installed, so this source revision has not been compiled into an APK here.


## V2 — penyesuaian referensi visual
- Memakai aset logo Alfamart asli yang diberikan pengguna (bukan teks/logo tiruan).
- Mempertahankan login Personil Toko dan Admin Utama terpisah.
- Kerangka dashboard COS/ACOS/Crew dan halaman input, ranking, reward, profil, laporan mengikuti susunan referensi.
- Pendaftaran mandiri masih berupa rancangan UI; validasi kode aktivasi dan penyimpanan data belum aktif.
- Angka pada dashboard tetap placeholder sampai skema data operasional dan sinkronisasi Firestore diimplementasikan.
