package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.content.Intent;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.yalantis.ucrop.UCrop;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
  private static final int RED=Color.rgb(196,0,35), BLUE=Color.rgb(20,75,130), DARK=Color.rgb(29,37,51), MUTED=Color.rgb(111,121,136), BG=Color.rgb(246,247,250), GREEN=Color.rgb(24,132,83), SOFT_RED=Color.rgb(255,241,244);
  private static final String AUTH_DOMAIN="@ikt-monitoring.app";
  private FirebaseAuth auth; private FirebaseFirestore db; private FirebaseStorage storage; private ImageView profileAvatar; private static final int PICK_PROFILE_PHOTO=412;
  private boolean adminMode=false, loading=false;
  private EditText identityInput,passwordInput; private Button loginButton;
  private String currentName="", currentRole="", currentNik="", storeCode="", storeName="", storeType="";
  private LinearLayout root;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(RED);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();storage=FirebaseStorage.getInstance();}catch(Exception e){toast("Firebase belum siap: "+e.getMessage());} showLogin();}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(Math.max(radius,dp(14)));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private LinearLayout.LayoutParams lp(int h){return new LinearLayout.LayoutParams(-1,h<0?h:dp(h));}
  private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1);}
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  private TextView center(String s,int size,int color,boolean bold){TextView t=txt(s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
  private void showLogin(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);root=col();root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(BG);sc.addView(root);root.setPadding(dp(20),dp(26),dp(20),dp(22));
    LinearLayout hero=col();hero.setGravity(Gravity.CENTER);hero.setBackground(shape(RED,0,dp(22)));hero.setPadding(dp(18),dp(30),dp(18),dp(28));hero.setElevation(dp(5));
    ImageView logo=new ImageView(this); logo.setImageResource(com.adzwan.iktalfamartmonitoring.R.drawable.alfamart_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(150),dp(58)); hero.addView(logo,logoParams);TextView title=center("IKT Alfamart Monitoring",21,Color.WHITE,true);title.setPadding(0,dp(12),0,0);hero.addView(title,lp(-2));root.addView(hero,lp(-2));
    LinearLayout modes=row();modes.setPadding(0,dp(20),0,dp(8));Button p=modeButton("Personil Toko",!adminMode),a=modeButton("Admin Utama",adminMode);modes.addView(p,weight());modes.addView(a,weight());root.addView(modes,lp(-2));
    TextView info=center(adminMode?"LOGIN ADMIN UTAMA":"LOGIN PERSONIL TOKO",17,DARK,true);info.setPadding(0,dp(7),0,dp(8));root.addView(info,lp(-2));
    identityInput=new EditText(this);identityInput.setSingleLine(true);identityInput.setTextSize(15);identityInput.setMaxWidth(dp(420));identityInput.setPadding(dp(15),dp(12),dp(15),dp(12));identityInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));identityInput.setHint(adminMode?"Email Admin Utama":"NIK (8 angka)");identityInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:InputType.TYPE_CLASS_NUMBER);root.addView(identityInput,field());
    passwordInput=new EditText(this);passwordInput.setSingleLine(true);passwordInput.setTextSize(15);passwordInput.setMaxWidth(dp(420));passwordInput.setPadding(dp(15),dp(12),dp(15),dp(12));passwordInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));passwordInput.setHint(adminMode?"Password":"PIN (6 digit)");passwordInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(passwordInput,field());
    loginButton=new Button(this);loginButton.setText("Login");loginButton.setTextColor(Color.WHITE);loginButton.setAllCaps(false);loginButton.setTextSize(16);loginButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));root.addView(loginButton,field());
    TextView note=center(adminMode?"Admin Utama\nLogin menggunakan email dan password.":"Personil Toko: COS, ACOS, dan Crew\nLogin menggunakan NIK dan PIN.",12,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(12)));note.setPadding(dp(12),dp(14),dp(12),dp(14));root.addView(note,field());
    if(!adminMode){ TextView signup=center("Belum punya akun?  Daftar Akun Baru",14,BLUE,true); signup.setPadding(0,dp(12),0,dp(12)); signup.setClickable(true); signup.setOnClickListener(v->showRegister()); root.addView(signup,lp(-2)); }
    TextView credit=center("Design by Adzwan Putera Suswanto",11,MUTED,false); credit.setPadding(0,dp(10),0,dp(6)); root.addView(credit,lp(-2));
    p.setOnClickListener(v->{adminMode=false;showLogin();});a.setOnClickListener(v->{adminMode=true;showLogin();});loginButton.setOnClickListener(v->doLogin());setContentView(sc);
  }
  private void showRegister(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout page=col();page.setGravity(Gravity.CENTER_HORIZONTAL);page.setPadding(dp(22),dp(22),dp(22),dp(22));page.setBackgroundColor(BG);sc.addView(page);
    TextView title=center("DAFTAR AKUN PERSONIL",22,DARK,true);title.setPadding(0,dp(16),0,dp(8));page.addView(title,lp(-2));
    TextView desc=center("Isi data personil dan toko. Akun menunggu verifikasi Admin Utama.",13,MUTED,false);page.addView(desc,lp(-2));
    EditText name=registerField(page,"Nama Lengkap",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    EditText nik=registerField(page,"NIK (8 angka)",InputType.TYPE_CLASS_NUMBER);
    Spinner role=new Spinner(this);String[] roles={"Pilih Jabatan","Crew","ACOS","COS"};role.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,roles));page.addView(role,field());
    EditText code=registerField(page,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText shop=registerField(page,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    TextView storeTypeLabel=txt("Jenis Toko",13,DARK,true);storeTypeLabel.setPadding(dp(12),dp(8),0,dp(2));page.addView(storeTypeLabel,lp(-2));
    Spinner storeTypeChoice=new Spinner(this);String[] storeTypes={"Pilih Jenis Toko","Normal (2 Shift)","24 Jam (3 Shift)"};storeTypeChoice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,storeTypes));page.addView(storeTypeChoice,field());
    EditText pin=registerField(page,"Buat PIN (6 digit)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    EditText confirm=registerField(page,"Ulangi PIN",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    Button submit=primary("Daftar Akun");page.addView(submit,field());
    TextView info=txt("Pendaftaran tidak memakai kode aktivasi. Akun baru belum dapat login sampai Admin Utama memverifikasi data dan mengaktifkannya.",12,BLUE,false);info.setBackground(shape(0xffe8f0fc,0,dp(12)));info.setPadding(dp(12),dp(12),dp(12),dp(12));page.addView(info,field());
    TextView back=center("Kembali ke Login",14,BLUE,true);back.setPadding(0,dp(12),0,dp(12));page.addView(back,lp(-2));back.setOnClickListener(v->showLogin());
    submit.setOnClickListener(v->{String nm=name.getText().toString().trim(),n=nik.getText().toString().trim(),r=role.getSelectedItemPosition()==1?"crew":role.getSelectedItemPosition()==2?"acos":role.getSelectedItemPosition()==3?"cos":"",c=code.getText().toString().trim().toUpperCase(Locale.US),sn=shop.getText().toString().trim(),requestedStoreType=storeTypeChoice.getSelectedItemPosition()==1?"NORMAL":storeTypeChoice.getSelectedItemPosition()==2?"24_JAM":"",pw=pin.getText().toString(),cp=confirm.getText().toString();if(nm.isEmpty()||!n.matches("\\d{8}")||r.isEmpty()||c.isEmpty()||sn.isEmpty()||requestedStoreType.isEmpty()||!pw.matches("\\d{6}")||!pw.equals(cp)){toast("Periksa semua data, jabatan, NIK, dan PIN.");return;}if(auth==null||db==null){toast("Firebase belum siap.");return;}submit.setEnabled(false);submit.setText("Mendaftarkan...");String email=n+AUTH_DOMAIN;auth.createUserWithEmailAndPassword(email,pw).addOnCompleteListener(this,task->{if(!task.isSuccessful()){submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran gagal: "+(task.getException()==null?"periksa koneksi":task.getException().getLocalizedMessage()));return;}Map<String,Object> req=new HashMap<>();req.put("nik",n);req.put("name",nm);req.put("requestedRole",r);req.put("storeCode",c);req.put("storeName",sn);req.put("requestedStoreType",requestedStoreType);req.put("email",email);req.put("status","pending");req.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());req.put("authUid",auth.getCurrentUser().getUid());db.collection("RegistrationRequests").document(n).set(req).addOnSuccessListener(vv->{auth.signOut();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran terkirim. Tunggu verifikasi Admin Utama.");showLogin();}).addOnFailureListener(e->{if(auth.getCurrentUser()!=null)auth.getCurrentUser().delete();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Permohonan gagal disimpan. Rules Firestore perlu diperbarui: "+e.getLocalizedMessage());});});});
    setContentView(sc);
  }
  private EditText registerField(LinearLayout parent,String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setInputType(type);e.setPadding(dp(17),dp(14),dp(17),dp(14));e.setBackground(shape(Color.WHITE,0xffe4e8ef,dp(16)));parent.addView(e,field());return e;}
  private Button modeButton(String s,boolean selected){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(selected?Color.WHITE:DARK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(selected?RED:Color.WHITE));return b;}
  private LinearLayout.LayoutParams field(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(10);return p;}
  private void doLogin(){if(auth==null||db==null){toast("Firebase belum siap.");return;}String id=identityInput.getText().toString().trim(),pw=passwordInput.getText().toString().trim();if(adminMode){if(id.isEmpty()||pw.isEmpty()){toast("Masukkan email dan password.");return;}signIn(id,pw,true,null);}else{if(!id.matches("\\d{8}")||!pw.matches("\\d{6}")){toast("NIK harus 8 angka dan PIN harus 6 digit.");return;}signIn(id+AUTH_DOMAIN,pw,false,id);}}
  private void signIn(String email,String password,boolean admin,String nik){
    loginButton.setEnabled(false);loginButton.setText("Memeriksa...");
    auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,task->{
      if(!task.isSuccessful()){restoreLogin();toast("Login gagal. Periksa NIK/email dan PIN/password.");return;}
      if(admin){db.collection("Users").document("AdminUtama").get().addOnSuccessListener(d->finishLogin(d,true,nik,email)).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil Admin: "+e.getLocalizedMessage());});return;}
      // Personil: baca identitas kanonis langsung dari Personnel/{NIK}; tidak memakai collectionGroup/index.
      db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{
        if(!person.exists()){restoreLogin();auth.signOut();toast("Profil Personnel tidak ditemukan. Minta Admin Utama memeriksa data personil.");return;}
        if(!Boolean.TRUE.equals(person.getBoolean("isActive"))){restoreLogin();auth.signOut();toast("Akun personil belum aktif. Hubungi Admin Utama.");return;}
        String role=firstNonEmpty(person.getString("currentRole"),person.getString("role"));
        String code=firstNonEmpty(person.getString("currentStoreCode"),person.getString("storeCode"));
        String shop=firstNonEmpty(person.getString("currentStoreName"),person.getString("storeName"));
        if(role.isEmpty()||code.isEmpty()||shop.isEmpty()){restoreLogin();auth.signOut();toast("Data jabatan atau toko aktif di Personnel belum lengkap. Hubungi Admin Utama.");return;}
        db.collection("Stores").document(code).collection("Users").document(nik).get().addOnSuccessListener(profile->{
          if(!profile.exists()||!Boolean.TRUE.equals(profile.getBoolean("isActive"))||!nik.equals(profile.getString("nik"))){restoreLogin();auth.signOut();toast("Profil toko aktif tidak ditemukan atau belum aktif. Periksa Stores/"+code+"/Users/"+nik+".");return;}
          String storeRole=firstNonEmpty(profile.getString("role"),role);
          if(!role.equals(storeRole)){restoreLogin();auth.signOut();toast("Jabatan di Personnel dan profil toko berbeda. Minta Admin Utama menyamakan data.");return;}
          // Jangan membaca Stores/{kode} di proses login karena Firestore Rules aktif
          // hanya mengizinkan akses ke Personnel dan profil Stores/{kode}/Users/{NIK}.
          // Jenis toko sudah disalin oleh Admin Utama ke dokumen personil/profil pengguna.
          String rawType=firstNonEmpty(person.getString("storeType"),profile.getString("storeType"));
          String type=normalizeStoreType(rawType);
          currentName=firstNonEmpty(person.getString("name"),profile.getString("name"));
          currentRole=role;currentNik=nik;storeCode=code;storeName=shop;storeType=type;
          restoreLogin();showDashboard("Beranda");
        }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil toko: "+e.getLocalizedMessage());});
      }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca Personnel: "+e.getLocalizedMessage());});
    });
  }
  private String normalizeStoreType(String value){
    if(value==null)return "";
    String v=value.trim().toUpperCase(Locale.US).replace(' ','_');
    if(v.equals("24_JAM")||v.equals("24JAM")||v.equals("24_JAM_STORE"))return "24_JAM";
    if(v.equals("NORMAL")||v.equals("TOKO_NORMAL"))return "NORMAL";
    return "";
  }
  private String firstNonEmpty(String a,String b){if(a!=null&&!a.trim().isEmpty()&&!"...".equals(a.trim())&&!".".equals(a.trim()))return a;return b==null?"":b;}
  private void finishLogin(DocumentSnapshot d,boolean admin,String nik,String email){restoreLogin();String role=d.getString("role"),registered=d.getString("email");boolean valid=Boolean.TRUE.equals(d.getBoolean("isActive"))&&(admin?"admin_utama".equals(role):(role!=null&&("crew".equals(role)||"acos".equals(role)||"cos".equals(role))&&nik.equals(d.getString("nik"))));if(admin&&registered!=null&&!registered.equalsIgnoreCase(email))valid=false;if(!valid){auth.signOut();toast("Akun belum aktif atau hak akses tidak sesuai. Jika baru mendaftar, tunggu verifikasi Admin Utama.");return;}currentName=d.getString("name")==null?"Personil":d.getString("name");currentRole=role;currentNik=admin?"":nik;storeCode=d.getString("storeCode")==null?"":d.getString("storeCode");storeName=d.getString("storeName")==null?"":d.getString("storeName");if(!admin&&(storeCode.isEmpty()||storeName.isEmpty())){auth.signOut();toast("Profil belum memiliki data toko aktif. Hubungi Admin Utama.");return;}showDashboard("Beranda");}
  private void restoreLogin(){if(loginButton!=null){loginButton.setEnabled(true);loginButton.setText("Login");}}
  private void showDashboard(String page){
    LinearLayout shell=col(); shell.setBackgroundColor(BG);
    LinearLayout header=row(); header.setBackgroundColor(RED); header.setPadding(dp(16),dp(12),dp(16),dp(12));
    TextView menu=txt("☰",24,Color.WHITE,true); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(8),dp(4),dp(8),dp(4)); menu.setContentDescription("Buka menu"); menu.setClickable(true); menu.setFocusable(true); header.addView(menu);
    menu.setOnClickListener(v->{ PopupMenu popup=new PopupMenu(MainActivity.this,menu); String[] entries=menuEntries(); for(String entry:entries) popup.getMenu().add(entry); popup.setOnMenuItemClickListener(item->{String choice=item.getTitle().toString(); if("Keluar".equals(choice)){if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();}else if("Input PL Crew".equals(choice)){showDashboard("Input PL Crew");}else{showDashboard(choice);} return true;}); popup.show();});
    TextView brand=txt("IKT Alfamart",18,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(14);header.addView(brand,bp);
    TextView bell=txt("♧",22,Color.WHITE,true);header.addView(bell);shell.addView(header,lp(-2));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(14));sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout welcome=row();TextView avatar=center("●",25,RED,true);avatar.setBackground(shape(Color.WHITE,0xffdddddd,dp(28)));avatar.setWidth(dp(50));avatar.setHeight(dp(50));welcome.addView(avatar);
    LinearLayout who=col();who.setPadding(dp(10),0,0,0);who.addView(txt("Halo, "+currentName,15,DARK,true));who.addView(txt(roleLabel()+" • Toko "+storeCode,12,MUTED,false));welcome.addView(who,new LinearLayout.LayoutParams(0,-2,1));
    TextView month=txt("Nov 2026  ▣",11,DARK,true);month.setBackground(shape(Color.WHITE,0xffdddddd,dp(8)));month.setPadding(dp(9),dp(8),dp(9),dp(8));welcome.addView(month);body.addView(welcome,lp(-2));

    if(page.equals("Pengaturan Jenis Toko")){
      if(!"admin_utama".equals(currentRole)){body.addView(txt("Akses hanya untuk Admin Utama.",14,RED,true));}
      else showStoreTypeSettings(body);
    }else if(page.equals("Beranda")){
      if("crew".equals(currentRole)){
        cardTitle(body,"Pencapaian Saya (s.d. 20 Nov)");
        LinearLayout trophy=col();trophy.setBackground(shape(0xfffff6df,0xffeadcae,dp(11)));trophy.setPadding(dp(13),dp(12),dp(13),dp(12));
        trophy.addView(txt("🏆  Ranking Gabungan",14,DARK,true));trophy.addView(txt("Menunggu data pencapaian",18,GREEN,true));body.addView(trophy,lp(-2));
        cardTitle(body,"Pencapaian per Indikator");loadCrewIndicatorProgress(body);
        LinearLayout acts=row();Button input=primary("Input PL Hari Ini");Button rank=smallButton("Lihat Ranking");acts.addView(input,weight());acts.addView(rank,weight());body.addView(acts,field());input.setOnClickListener(v->showDashboard("Input PL"));rank.setOnClickListener(v->showDashboard("Ranking Crew"));
      }else{
        cardTitle(body,"Kinerja Toko (s.d. 20 Nov)");
        LinearLayout metrics=col(); TextView[][] metricFields=new TextView[4][4]; String[] metricLabels={"NET SALES","MARGIN","NSB","STATUS IKT"}; int[] cardColors={0xffFBE3E8,0xffDFEAFA,0xffE2F2E2,0xffFCEBD9};
        for(int rowIndex=0;rowIndex<2;rowIndex++){ LinearLayout metricRow=row(); for(int colIndex=0;colIndex<2;colIndex++){int ix=rowIndex*2+colIndex; LinearLayout c=col(); c.setBackground(shape(cardColors[ix],0xffe7ebf2,dp(20)));c.setElevation(dp(3)); c.setPadding(dp(13),dp(14),dp(13),dp(14)); c.addView(txt(metricLabels[ix],16,BLUE,true)); metricFields[ix][0]=txt("Memuat...",29,Color.BLACK,true); metricFields[ix][0].setPadding(0,dp(9),0,dp(1)); c.addView(metricFields[ix][0]); metricFields[ix][1]=txt(ix==3?"Status toko":"Pencapaian",14,DARK,false); c.addView(metricFields[ix][1]); View gap=new View(this);c.addView(gap,lp(12)); metricFields[ix][2]=txt("Target : --",13,DARK,false); c.addView(metricFields[ix][2]); metricFields[ix][3]=txt("Aktual : --",13,DARK,false); c.addView(metricFields[ix][3]); TextView note=txt("Keterangan : Menunggu data",13,GREEN,true); note.setPadding(0,dp(13),0,0);c.addView(note); metricFields[ix]=new TextView[]{metricFields[ix][0],metricFields[ix][1],metricFields[ix][2],metricFields[ix][3],note}; LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(236),1); q.setMargins(dp(4),dp(4),dp(4),dp(4)); metricRow.addView(c,q);} metrics.addView(metricRow,lp(-2)); } body.addView(metrics,lp(-2)); loadDashboardIKT(metricFields);
        LinearLayout actions=row();String[][] acts={{"▣","Input Target IKT"},{"▤","Target Penawaran Langsung"},{"✎","Penawaran Langsung Crew"},{"♛","Ranking Crew"}};
        for(String[] act:acts){String label=act[1];LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setBackground(shape(Color.WHITE,0xffe8eaf0,dp(15)));tile.setElevation(dp(2));tile.setPadding(dp(3),dp(10),dp(3),dp(10));tile.addView(center(act[0],21,RED,true));tile.addView(center(label,10,DARK,true));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(78),1);q.setMargins(dp(3),dp(8),dp(3),dp(8));actions.addView(tile,q);tile.setOnClickListener(v->showDashboard(label.equals("Penawaran Langsung Crew")?"Input PL Crew":label));}body.addView(actions,lp(-2));
        LinearLayout extra=row();String[][] extraActs={{"♜","Reward"},{"▤","Laporan"}};for(String[] act:extraActs){Button b=smallButton(act[1]);extra.addView(b,weight());b.setOnClickListener(v->showDashboard(act[1]));}body.addView(extra,field());
        cardTitle(body,"Progress Indikator PL Toko");loadPLStoreProgress(body);
      }
    }else if(page.equals("Input Target Penawaran Langsung")) {
      cardTitle(body,"Input Target Penawaran Langsung");
      body.addView(txt("Target diinput bertahap. Periode berikutnya baru terbuka saat tanggal periodenya dimulai.",12,MUTED,false),field());
      final EditText adminCode, adminName;
      if("admin_utama".equals(currentRole)){
        adminCode=registerField(body,"Masukkan Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        adminName=null;
      }else{adminCode=null;adminName=null;body.addView(txt("Toko: "+storeCode+" • "+storeName,12,BLUE,true),field());}
      body.addView(txt("Bulan Target",13,DARK,true)); DatePicker targetMonth=new DatePicker(this); TextView targetMonthSelector=addDropdownDatePicker(body,targetMonth,true,null);
      Map<String,EditText> plTargets=new HashMap<>();
      addTargetPeriod(body,plTargets,"PSM","Week 1 • Tanggal 1–7","PSM_W1"); addWorkdays(body,plTargets,"PSM_W1"); addTargetPeriod(body,plTargets,"PSM","Week 2 • Tanggal 8–15","PSM_W2"); addWorkdays(body,plTargets,"PSM_W2"); addTargetPeriod(body,plTargets,"PSM","Week 3 • Tanggal 16–23","PSM_W3"); addWorkdays(body,plTargets,"PSM_W3"); addTargetPeriod(body,plTargets,"PSM","Week 4 • Tanggal 24–akhir bulan","PSM_W4"); addWorkdays(body,plTargets,"PSM_W4");
      addTargetPeriod(body,plTargets,"PWP","Periode 1 • Tanggal 1–15","PWP_P1"); addWorkdays(body,plTargets,"PWP_P1"); addTargetPeriod(body,plTargets,"PWP","Periode 2 • Tanggal 16–akhir bulan","PWP_P2"); addWorkdays(body,plTargets,"PWP_P2");
      addTargetPeriod(body,plTargets,"Serba Gratis","Periode 1 • Tanggal 1–15","SG_P1"); addWorkdays(body,plTargets,"SG_P1"); addTargetPeriod(body,plTargets,"Serba Gratis","Periode 2 • Tanggal 16–akhir bulan","SG_P2"); addWorkdays(body,plTargets,"SG_P2");
      addTargetPeriod(body,plTargets,"SUEGER","Periode 1 • Tanggal 1–15","SUEGER_P1"); addWorkdays(body,plTargets,"SUEGER_P1"); addTargetPeriod(body,plTargets,"SUEGER","Periode 2 • Tanggal 16–akhir bulan","SUEGER_P2"); addWorkdays(body,plTargets,"SUEGER_P2");
      if("admin_utama".equals(currentRole)){Button loadTarget=smallButton("Muat Target Toko");body.addView(loadTarget,field());loadTarget.setOnClickListener(v->{String c=adminCode.getText().toString().trim().toUpperCase(Locale.US);if(c.isEmpty()){toast("Masukkan kode toko.");return;}loadMonthlyPLTargets(targetMonth,plTargets,c);});}
      String initialCode="admin_utama".equals(currentRole)?"":storeCode;
      loadMonthlyPLTargets(targetMonth,plTargets,initialCode);
      Runnable refreshPeriodLocks=()->{
        Calendar now=Calendar.getInstance();boolean currentMonth=targetMonth.getYear()==now.get(Calendar.YEAR)&&targetMonth.getMonth()==now.get(Calendar.MONTH);int today=now.get(Calendar.DAY_OF_MONTH);int last=now.getActualMaximum(Calendar.DAY_OF_MONTH);
        for(String key:plTargets.keySet()){
          String period=key.endsWith("_DAYS")?key.substring(0,key.length()-5):key;
          int end=period.equals("PSM_W1")?7:period.equals("PSM_W2")?15:period.equals("PSM_W3")?23:period.equals("PSM_W4")||period.endsWith("_P2")?last:15;
          EditText field=plTargets.get(key);field.setEnabled(currentMonth&&end>=today);
        }
      };
      refreshPeriodLocks.run();
      setDropdownDatePickerListener(targetMonthSelector,targetMonth,true,refreshPeriodLocks);
      Button savePLTarget=primary("Simpan Target Periode"); body.addView(savePLTarget,field());
      savePLTarget.setOnClickListener(v->{String c="admin_utama".equals(currentRole)?adminCode.getText().toString().trim().toUpperCase(Locale.US):storeCode;String n="admin_utama".equals(currentRole)?c:storeName;if(c.isEmpty()){toast("Masukkan kode toko.");return;}saveMonthlyPLTargets(targetMonth,plTargets,savePLTarget,c,n);});
      TextView plNote=txt("Semua periode ditampilkan. Periode yang sudah selesai dikunci; periode aktif dan periode mendatang pada bulan berjalan dapat disiapkan.",11,BLUE,false); plNote.setBackground(shape(0xffe8f0fc,0,dp(8))); plNote.setPadding(dp(10),dp(10),dp(10),dp(10)); body.addView(plNote,lp(-2));
    }else if(page.equals("Input Target IKT")||page.equals("Input PL")||page.equals("Input PL Crew")||page.equals("Input Toko")){
      boolean target=page.equals("Input Target IKT");boolean pl=page.equals("Input PL")||page.equals("Input PL Crew");
      cardTitle(body,target?"Input Target IKT Bulanan":pl?("crew".equals(currentRole)?"Penawaran Langsung Hari Ini":"Penawaran Langsung Crew") :"Input Data Toko");
      if(target)body.addView(txt("Atur target IKT bulanan toko: Net Sales, Margin %, NSB, APC, dan STD.",12,MUTED,false),field());
      if(pl && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))body.addView(txt("Masukkan NIK Crew yang akan diinput atau diperbarui. Data tersimpan atas nama Crew yang dipilih.",12,MUTED,false),field());
      body.addView(txt(target?"Pilih bulan target":"Tanggal",13,DARK,true));DatePicker date=new DatePicker(this);TextView dateSelector=addDropdownDatePicker(body,date,target,null);
      EditText targetNik=null;
      if(pl&&("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){body.addView(txt("NIK Crew yang diinput (8 angka)",13,DARK,true));targetNik=registerField(body,"Masukkan NIK Crew",InputType.TYPE_CLASS_NUMBER);targetNik.setText(currentNik);}
      String[] labels=target?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:page.equals("Input Toko")?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:new String[]{"PSM","PWP","Serba Gratis","SUEGER"};
      Map<String,EditText> inputs=new HashMap<>();
      for(String key:labels){LinearLayout r=row();r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));r.addView(txt(key,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));if(isRupiahMetric(key))r.addView(txt("Rp",12,MUTED,true));else if(isDecimalMetric(key))r.addView(txt("%",12,MUTED,true));EditText val=new EditText(this);configureMetricInput(val,key);val.setText("0");val.setEms(5);applyZeroFocusStyle(val);r.addView(val);inputs.put(key,val);LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);body.addView(r,q);}
      final EditText selectedCrewNik=targetNik;
      if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);
      setDropdownDatePickerListener(dateSelector,date,target,()->{if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);});
      Button save=primary(target?"Simpan Target": "Simpan");body.addView(save,field());save.setOnClickListener(v->{if(target)saveMonthlyTarget(date,inputs,save);else saveDailyInput(page,date,inputs,save,selectedCrewNik);});
      TextView note=txt(target?"Target berlaku untuk toko dan bulan yang dipilih.":"Data harian dapat diinput dan dikoreksi kapan saja. Semua indikator wajib diisi; NSB boleh 0. Setiap koreksi dicatat.",11,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(8)));note.setPadding(dp(10),dp(10),dp(10),dp(10));body.addView(note,lp(-2));
    }else if(page.equals("Ranking Crew")){
      LinearLayout rankingHeader=row();rankingHeader.setGravity(Gravity.CENTER_VERTICAL);rankingHeader.setPadding(dp(14),dp(12),dp(14),dp(12));rankingHeader.setBackground(shape(Color.WHITE,0xffe2e5eb,dp(16)));
      TextView signal=center("▂▅▇",25,RED,true);rankingHeader.addView(signal,new LinearLayout.LayoutParams(-2,-2));TextView rankingTitle=txt("RANKING CREW",19,DARK,true);LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-2,-2);titleLp.leftMargin=dp(12);rankingHeader.addView(rankingTitle,titleLp);body.addView(rankingHeader,field());
      body.addView(txt("Peringkat dihitung dari pencapaian berbobot: PSM 25%, PWP 25%, Serba Gratis 30%, SUEGER 20%.",12,MUTED,false),field());
      DatePicker rankDate=new DatePicker(this);rankDate.setVisibility(View.GONE);body.addView(rankDate,new LinearLayout.LayoutParams(1,1));
      LinearLayout menuRow1=row();menuRow1.setGravity(Gravity.CENTER_VERTICAL);
      LinearLayout menuRow2=row();menuRow2.setGravity(Gravity.CENTER_VERTICAL);
      LinearLayout rankResults=col();
      TextView dateSelector=txt("Pilih Tanggal  ▾",14,DARK,true);dateSelector.setGravity(Gravity.CENTER_VERTICAL);dateSelector.setPadding(dp(14),dp(13),dp(14),dp(13));dateSelector.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));
      Runnable updateDateLabel=()->dateSelector.setText(String.format(Locale.forLanguageTag("id-ID"),"%1$te %1$tB %1$tY  ▾",new GregorianCalendar(rankDate.getYear(),rankDate.getMonth(),rankDate.getDayOfMonth()).getTime()));
      Runnable showDaily=()->loadCrewRanking(rankResults,rankDate,false);
      Runnable showMonthly=()->loadCrewRanking(rankResults,rankDate,true);
      LinearLayout dailyCard=rankingMenuCard(R.drawable.ic_rank_daily,"Ranking Harian","Peringkat berdasarkan tanggal yang dipilih.",true,showDaily);
      LinearLayout periodCard=rankingMenuCard(R.drawable.ic_rank_period,"Ranking Periode","Mengikuti periode target masing-masing indikator.",false,()->loadCrewRankingAdvanced(rankResults,rankDate,false));
      LinearLayout monthlyCard=rankingMenuCard(R.drawable.ic_rank_monthly,"Ranking Bulanan","Rekap pencapaian selama satu bulan.",false,showMonthly);
      LinearLayout reportCard=rankingMenuCard(R.drawable.ic_rank_report,"Raport Crew","Rekap total pencapaian dalam setahun (Jan–Des).",false,()->loadCrewRankingAdvanced(rankResults,rankDate,true));
      LinearLayout[] rankingMenuCards={dailyCard,periodCard,monthlyCard,reportCard};
      final int[] selectedRankingMode={0};
      Runnable[] rankingMenuActions={showDaily,()->loadCrewRankingAdvanced(rankResults,rankDate,false),showMonthly,()->loadCrewRankingAdvanced(rankResults,rankDate,true)};
      for(int i=0;i<rankingMenuCards.length;i++){final int selected=i;rankingMenuCards[i].setOnClickListener(v->{selectedRankingMode[0]=selected;for(int j=0;j<rankingMenuCards.length;j++)setRankingMenuCardActive(rankingMenuCards[j],j==selected);rankingMenuActions[selected].run();});}
      menuRow1.setPadding(dp(4),0,dp(4),0);menuRow2.setPadding(dp(4),0,dp(4),0);
      menuRow1.addView(dailyCard,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,-2,1);p2.leftMargin=dp(8);menuRow1.addView(periodCard,p2);body.addView(menuRow1,field());
      menuRow2.addView(monthlyCard,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams p4=new LinearLayout.LayoutParams(0,-2,1);p4.leftMargin=dp(8);menuRow2.addView(reportCard,p4);body.addView(menuRow2,field());
      body.addView(dateSelector,field());body.addView(rankResults,lp(-2));
      dateSelector.setOnClickListener(v->{DatePickerDialog dialog=new DatePickerDialog(this,(view,y,m,d)->{rankDate.updateDate(y,m,d);updateDateLabel.run();rankingMenuActions[selectedRankingMode[0]].run();},rankDate.getYear(),rankDate.getMonth(),rankDate.getDayOfMonth());dialog.show();});
      updateDateLabel.run();showDaily.run();
    }else if(page.equals("Laporan Sales")){
      showSalesReport(body);
    }else if(page.equals("Laporan Penawaran Langsung Per Periode")||page.equals("Laporan Penawaran Langsung Per Bulan")){
      cardTitle(body,page);body.addView(txt("Tampilan submenu ini tetap dipertahankan untuk pengembangan berikutnya.",13,MUTED,false),field());Button back=smallButton("Kembali ke Laporan Penjualan");body.addView(back,field());back.setOnClickListener(v->showDashboard("Laporan Penjualan"));
    }else if(page.equals("Reward")){
      cardTitle(body,"Reward IKT");LinearLayout trophy=col();trophy.setBackground(shape(0xfff0f8e9,0xffd4e8c8,dp(10)));trophy.setPadding(dp(14),dp(14),dp(14),dp(14));trophy.addView(center("🏆",28,GREEN,true));trophy.addView(center("Status IKT Toko",14,DARK,true));trophy.addView(center("Menunggu data kinerja",18,GREEN,true));body.addView(trophy,lp(-2));
      cardTitle(body,"Kategori Reward");progressRow(body,"Kategori A","Menunggu pencapaian Net Sales");progressRow(body,"Penerima","Data reward belum tersedia");
    }else if(page.equals("Profil")){
      cardTitle(body,"Profil Personil");profileAvatar=new ImageView(this);profileAvatar.setImageResource(android.R.drawable.ic_menu_camera);profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);profileAvatar.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(60)));profileAvatar.setClipToOutline(true);LinearLayout.LayoutParams avatarLp=new LinearLayout.LayoutParams(dp(112),dp(112));avatarLp.gravity=Gravity.CENTER_HORIZONTAL;body.addView(profileAvatar,avatarLp);profileAvatar.setOnClickListener(v->chooseProfilePhoto());loadProfilePhoto();TextView name=center(currentName,18,DARK,true);body.addView(name,lp(-2));for(String[] x:new String[][]{{"NIK",currentNik.isEmpty()?"Admin Utama":currentNik},{"Username",currentNik},{"Jabatan",roleLabel()},{"Kode Toko",storeCode},{"Nama Toko",storeName},{"Jenis Toko","24_JAM".equals(storeType)?"24 Jam":"NORMAL".equals(storeType)?"Normal":"Belum diatur"}})detail(body,x[0],x[1]);
      if(!currentNik.isEmpty()){Button career=smallButton("Jenjang Karir / Ajukan Kenaikan");body.addView(career,field());career.setOnClickListener(v->showCareerRequest());}
      Button out=smallButton("Keluar");body.addView(out,field());out.setOnClickListener(v->{if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();});
    }else if(page.equals("Verifikasi Pendaftaran")){
      cardTitle(body,"Verifikasi Pendaftaran Personil");loadPendingRegistrations(body);
    }else if(page.equals("Permohonan Karir")){
      cardTitle(body,"Persetujuan Jenjang Karir");loadPendingCareer(body);
    }else if(page.equals("Mutasi Personil")){
      cardTitle(body,"Mutasi Personil Antar Toko");EditText mn=registerField(body,"NIK Personil (8 angka)",InputType.TYPE_CLASS_NUMBER);EditText mc=registerField(body,"Kode Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);EditText ms=registerField(body,"Nama Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);Button move=primary("Proses Mutasi");body.addView(move,field());move.setOnClickListener(v->processMutation(mn.getText().toString().trim(),mc.getText().toString().trim().toUpperCase(Locale.US),ms.getText().toString().trim()));body.addView(txt("Mutasi memperbarui toko aktif dan mencatat riwayat toko sebelumnya. Hanya Admin Utama.",12,BLUE,false),field());
    }else if(page.equals("Laporan Penjualan")||page.equals("Laporan")){
      showSalesReportMenu(body);
    }else if(page.equals("Laporan Penawaran Langsung Sementara")){
      cardTitle(body,"Laporan Penawaran Langsung Sementara");
      body.addView(txt("Pilih rentang tanggal laporan. JHK dihitung dari jumlah tanggal dalam rentang yang dipilih, termasuk tanggal awal dan akhir.",12,MUTED,false),field());
      Calendar rangeNow=Calendar.getInstance();DatePicker reportStart=new DatePicker(this);reportStart.updateDate(rangeNow.get(Calendar.YEAR),rangeNow.get(Calendar.MONTH),1);
      DatePicker reportEnd=new DatePicker(this);reportEnd.updateDate(rangeNow.get(Calendar.YEAR),rangeNow.get(Calendar.MONTH),rangeNow.get(Calendar.DAY_OF_MONTH));
      body.addView(txt("Tanggal Awal",13,DARK,true),lp(-2));TextView startSelector=addDropdownDatePicker(body,reportStart,false,null);
      body.addView(txt("Tanggal Akhir",13,DARK,true),lp(-2));TextView endSelector=addDropdownDatePicker(body,reportEnd,false,null);
      LinearLayout reportResults=col();body.addView(reportResults,lp(-2));
      Button refresh=primary("Tampilkan Laporan");body.addView(refresh,field());
      refresh.setOnClickListener(v->loadPLReport(reportResults,reportStart,reportEnd));
      loadPLReport(reportResults,reportStart,reportEnd);
    }else{
      cardTitle(body,page);body.addView(txt("Halaman ini disiapkan mengikuti desain referensi. Data dan fungsi operasional akan dihubungkan bertahap.",14,MUTED,false));
    }
    LinearLayout nav=row(); nav.setBackground(shape(Color.WHITE,0xffedf0f5,dp(18))); nav.setElevation(dp(10)); nav.setPadding(dp(2),dp(4),dp(2),dp(8)); String[][] tabs={{"⌂","Beranda"},{"✎","Input PL"},{"♛","Ranking Crew"},{"▤","Laporan Penjualan"},{"♙","Profil"}}; for(String[] tab:tabs){String t=tab[1]; LinearLayout item=col(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2),dp(5),dp(2),dp(5)); item.setClickable(true); item.setFocusable(true); item.setBackgroundResource(android.R.drawable.list_selector_background); TextView ico=center(tab[0],18,t.equals(page)?RED:MUTED,true); TextView label=center(t,9,t.equals(page)?RED:MUTED,true); item.addView(ico,lp(-2)); item.addView(label,lp(-2)); nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1)); item.setOnClickListener(v->showDashboard(("Input PL".equals(t) && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))?"Input PL Crew":t)); } shell.addView(nav,lp(-2)); setContentView(shell);
  }

  private void showSalesReport(LinearLayout body){
    LinearLayout hero=col();hero.setPadding(dp(17),dp(18),dp(17),dp(18));hero.setBackground(gradient(0xffb9002b,0xffe3132d,dp(20)));hero.addView(txt("📈  LAPORAN SALES",23,Color.WHITE,true));hero.addView(txt("Analisis kinerja penjualan toko",12,Color.WHITE,false));body.addView(hero,field());
    LinearLayout tabs=row();tabs.setPadding(dp(3),dp(3),dp(3),dp(3));tabs.setBackground(shape(0xffedf0f5,0,dp(15)));Button day=smallButton("Harian"),month=smallButton("Bulanan"),year=smallButton("Tahunan");tabs.addView(day,weight());tabs.addView(month,weight());tabs.addView(year,weight());body.addView(tabs,field());
    DatePicker selected=new DatePicker(this);selected.setVisibility(View.GONE);body.addView(selected,new LinearLayout.LayoutParams(1,1));LinearLayout filters=col(),result=col();body.addView(filters,lp(-2));body.addView(result,lp(-2));final String[] mode={"Harian"};
    Runnable[] render={null};render[0]=()->{filters.removeAllViews();result.removeAllViews();if("Harian".equals(mode[0])){TextView pick=txt("Pilih tanggal laporan  ▾",14,DARK,true);pick.setPadding(dp(14),dp(13),dp(14),dp(13));pick.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));filters.addView(pick,field());pick.setText(new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(new GregorianCalendar(selected.getYear(),selected.getMonth(),selected.getDayOfMonth()).getTime())+"  ▾");pick.setOnClickListener(v->new DatePickerDialog(this,(a,y,m,d)->{selected.updateDate(y,m,d);render[0].run();},selected.getYear(),selected.getMonth(),selected.getDayOfMonth()).show());loadSalesPeriod(result,"Harian",selected.getYear(),selected.getMonth(),selected.getDayOfMonth());}
      else if("Bulanan".equals(mode[0])){LinearLayout row=row();String[] names={"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"};Spinner months=new Spinner(this);months.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));months.setSelection(selected.getMonth());int now=Calendar.getInstance().get(Calendar.YEAR);Integer[] years=new Integer[Math.max(1,now-2019)];for(int i=0;i<years.length;i++)years[i]=2020+i;Spinner ys=new Spinner(this);ys.setAdapter(new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_dropdown_item,years));ys.setSelection(Math.max(0,Math.min(years.length-1,selected.getYear()-2020)));row.addView(months,new LinearLayout.LayoutParams(0,dp(52),1));row.addView(ys,new LinearLayout.LayoutParams(0,dp(52),1));filters.addView(row,field());Button show=primary("Tampilkan Laporan Bulanan");filters.addView(show,field());show.setOnClickListener(v->{selected.updateDate((Integer)ys.getSelectedItem(),months.getSelectedItemPosition(),1);loadSalesPeriod(result,"Bulanan",selected.getYear(),selected.getMonth(),1);});loadSalesPeriod(result,"Bulanan",selected.getYear(),selected.getMonth(),1);}
      else{filters.addView(txt("Grafik perbandingan total Net Sales setiap tahun",13,MUTED,true),field());loadSalesPeriod(result,"Tahunan",selected.getYear(),selected.getMonth(),1);}};
    day.setOnClickListener(v->{mode[0]="Harian";render[0].run();});month.setOnClickListener(v->{mode[0]="Bulanan";render[0].run();});year.setOnClickListener(v->{mode[0]="Tahunan";render[0].run();});render[0].run();
  }
  private void loadSalesPeriod(LinearLayout out,String mode,int y,int m,int d){
    out.removeAllViews();if(db==null){out.addView(txt("Database belum siap.",13,RED,false));return;}
    if(storeCode==null||storeCode.trim().isEmpty()){out.addView(txt("Kode toko tidak tersedia untuk akun ini.",13,RED,false),field());return;}
    Calendar first=Calendar.getInstance(),last=Calendar.getInstance();
    if("Harian".equals(mode)){first.set(y,m,d);last.set(y,m,d);}
    else if("Bulanan".equals(mode)){first.set(y,m,1);last.set(y,m,1);last.set(Calendar.DAY_OF_MONTH,last.getActualMaximum(Calendar.DAY_OF_MONTH));}
    else{first.set(2020,Calendar.JANUARY,1);last=Calendar.getInstance();}
    first.set(Calendar.HOUR_OF_DAY,0);first.set(Calendar.MINUTE,0);first.set(Calendar.SECOND,0);first.set(Calendar.MILLISECOND,0);
    last.set(Calendar.HOUR_OF_DAY,0);last.set(Calendar.MINUTE,0);last.set(Calendar.SECOND,0);last.set(Calendar.MILLISECOND,0);
    final double[] sums=new double[5];final int[] count={0};final int[] pending={0};
    final Map<Integer,Double> yearlyTotals=new java.util.TreeMap<>();
    Calendar cursor=(Calendar)first.clone();while(!cursor.after(last)){pending[0]++;Calendar date=(Calendar)cursor.clone();String dateKey=new SimpleDateFormat("yyyyMMdd",Locale.US).format(date.getTime());final int year=date.get(Calendar.YEAR);
      db.collection("DailyStoreReports").document(storeCode+"_"+dateKey).get().addOnSuccessListener(doc->{
        if(doc.exists()){
          double salesValue=num(doc.get("Net Sales"));
          if("Tahunan".equals(mode)){yearlyTotals.put(year,(yearlyTotals.containsKey(year)?yearlyTotals.get(year):0d)+salesValue);}
          else{sums[0]+=salesValue;sums[1]+=num(doc.get("STD"));sums[2]+=num(doc.get("APC"));sums[3]+=num(doc.get("Margin %"));sums[4]+=num(doc.get("NSB"));}
          count[0]++;
        }
        pending[0]--;if(pending[0]==0)renderSalesPeriodResult(out,mode,first,sums,count[0],yearlyTotals);
      }).addOnFailureListener(e->{pending[0]--;if(pending[0]==0)renderSalesPeriodResult(out,mode,first,sums,count[0],yearlyTotals);});
      cursor.add(Calendar.DAY_OF_MONTH,1);
    }
    if(pending[0]==0)renderSalesPeriodResult(out,mode,first,sums,count[0],yearlyTotals);
  }
  private void renderSalesPeriodResult(LinearLayout out,String mode,Calendar first,double[] sums,int count,Map<Integer,Double> yearlyTotals){
    out.removeAllViews();if(count==0){out.addView(txt("Belum ada data Input Data Toko pada periode ini.",13,MUTED,false),field());return;}
    if("Tahunan".equals(mode)){cardTitle(out,"Perbandingan Net Sales Tahunan");double max=1;for(double v:yearlyTotals.values())max=Math.max(max,v);for(Map.Entry<Integer,Double> e:yearlyTotals.entrySet()){LinearLayout r=row();r.setPadding(dp(9),dp(8),dp(9),dp(8));r.addView(txt(String.valueOf(e.getKey()),13,DARK,true),new LinearLayout.LayoutParams(dp(52),-2));LinearLayout track=col();track.setBackground(shape(0xffedf0f5,0,dp(8)));TextView bar=txt("Rp "+formatGroupedInteger(e.getValue()),11,Color.WHITE,true);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(8),dp(7),dp(8),dp(7));bar.setBackground(gradient(0xff0878d1,0xff29b765,dp(8)));track.addView(bar,new LinearLayout.LayoutParams(-1,dp(32)));r.addView(track,new LinearLayout.LayoutParams(0,-2,1));out.addView(r,lp(-2));}return;}
    double sales=sums[0],std=sums[1],apc=sums[2],margin=sums[3],nsb=sums[4];
    String period="Harian".equals(mode)?new SimpleDateFormat("dd MMMM yyyy",new Locale("id","ID")).format(first.getTime()):new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(first.getTime());LinearLayout head=col();head.setPadding(dp(14),dp(13),dp(14),dp(13));head.setBackground(gradient(0xffb9002b,0xffe3132d,dp(13)));head.addView(txt("Rekap "+mode,16,Color.WHITE,true));head.addView(txt(period,12,Color.WHITE,false));out.addView(head,field());salesMetric(out,"NET SALES",formatRupiah(sales),"Total periode");salesMetric(out,"STD",String.format(Locale.US,"%.2f",std/count),"Rata-rata per hari data");salesMetric(out,"APC",formatRupiah(apc/count),"Rata-rata per hari data");salesMetric(out,"MARGIN",String.format(Locale.US,"%.2f%%",margin/count),"Rata-rata per hari data");salesMetric(out,"NSB",formatRupiah(nsb),"Total periode");cardTitle(out,"Rata-rata Keseluruhan");salesMetric(out,"RATA-RATA NET SALES",formatRupiah(sales/count),"Berdasarkan "+count+" hari yang memiliki data");
  }
  private void salesMetric(LinearLayout parent,String label,String value,String note){LinearLayout c=col();c.setPadding(dp(13),dp(10),dp(13),dp(10));c.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(12)));c.addView(txt(label,12,MUTED,true));c.addView(txt(value,19,DARK,true));c.addView(txt(note,10,MUTED,false));LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(7);parent.addView(c,p);}

  private void showSalesReportMenu(LinearLayout body){
    LinearLayout hero=col();hero.setPadding(dp(18),dp(22),dp(18),dp(22));hero.setBackground(gradient(0xffb9002b,0xffe3132d,dp(22)));hero.setElevation(dp(3));
    LinearLayout heroRow=row();TextView icon=center("📈",42,Color.WHITE,true);heroRow.addView(icon,new LinearLayout.LayoutParams(dp(78),dp(92)));
    LinearLayout titleBox=col();titleBox.setPadding(dp(12),0,0,0);titleBox.addView(txt("Laporan",27,Color.WHITE,true));titleBox.addView(txt("Penjualan",31,0xffffdf22,true));titleBox.addView(txt("Rekap & Analisis Kinerja Penjualan Toko",12,Color.WHITE,true));heroRow.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));hero.addView(heroRow);body.addView(hero,field());
    reportMenuCard(body,"📊","Laporan Sales","Tanggal 1 s/d Tanggal Berjalan","SALES, STD, APC, MARGIN, NSB dan Rata-rata Keseluruhan",0xff0878d1,0xff0046a8,()->showDashboard("Laporan Sales"));
    reportMenuCard(body,"📋","Laporan Penawaran Langsung Sementara","Tanggal 1 s/d Tanggal Berjalan","Rekap penawaran langsung sementara",0xff29b765,0xff08783e,()->showDashboard("Laporan Penawaran Langsung Sementara"));
    reportMenuCard(body,"🗓️","Laporan Penawaran Langsung Per Periode","Rekap berdasarkan Periode","PSM, PWP, Serba Gratis, dan SUEGER",0xffffb52b,0xffed6500,()->showDashboard("Laporan Penawaran Langsung Per Periode"));
    reportMenuCard(body,"📅","Laporan Penawaran Langsung Per Bulan","Rekap Keseluruhan Selama Satu Bulan","Ringkasan penawaran langsung bulanan",0xff9638e8,0xff6515bd,()->showDashboard("Laporan Penawaran Langsung Per Bulan"));
  }
  private GradientDrawable gradient(int start,int end,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{start,end});d.setCornerRadius(radius);return d;}
  private void reportMenuCard(LinearLayout parent,String symbol,String title,String subtitle,String detail,int start,int end,Runnable action){
    LinearLayout card=row();card.setPadding(dp(12),dp(16),dp(12),dp(16));card.setBackground(gradient(start,end,dp(19)));card.setElevation(dp(3));
    TextView art=center(symbol,37,Color.WHITE,true);card.addView(art,new LinearLayout.LayoutParams(dp(76),dp(94)));
    View divider=new View(this);divider.setBackgroundColor(0x99ffffff);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(dp(1),dp(76));dl.setMargins(dp(5),0,dp(10),0);card.addView(divider,dl);
    LinearLayout words=col();words.addView(txt(title,18,Color.WHITE,true));TextView sub=txt("▦  "+subtitle,12,Color.WHITE,true);sub.setPadding(0,dp(5),0,dp(4));words.addView(sub);words.addView(txt(detail,11,Color.WHITE,false));card.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    TextView arrow=center("❯",23,end,true);arrow.setBackground(shape(Color.WHITE,0,dp(24)));card.addView(arrow,new LinearLayout.LayoutParams(dp(38),dp(38)));
    LinearLayout.LayoutParams cp=lp(-2);cp.bottomMargin=dp(11);parent.addView(card,cp);card.setOnClickListener(v->action.run());
  }

  private static class PLTemporaryRow {
    String nik,name,code,shop; double[] actual=new double[4];
    PLTemporaryRow(String n,String nm,String c,String sn){nik=n;name=nm;code=c;shop=sn;}
  }

  private void loadPLReport(LinearLayout results,DatePicker startPicker,DatePicker endPicker){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    Calendar start= new GregorianCalendar(startPicker.getYear(),startPicker.getMonth(),startPicker.getDayOfMonth());
    Calendar end= new GregorianCalendar(endPicker.getYear(),endPicker.getMonth(),endPicker.getDayOfMonth());
    if(end.before(start)){results.addView(txt("Tanggal akhir tidak boleh lebih awal dari tanggal awal.",13,RED,true),field());return;}
    final String from=new SimpleDateFormat("yyyyMMdd",Locale.US).format(start.getTime());
    final String to=new SimpleDateFormat("yyyyMMdd",Locale.US).format(end.getTime());
    final String fromLabel=selectedDate(startPicker),toLabel=selectedDate(endPicker);
    final int jhk=(int)((end.getTimeInMillis()-start.getTimeInMillis())/86400000L)+1;
    results.addView(txt("Memuat laporan tanggal "+selectedDate(startPicker)+" s/d "+selectedDate(endPicker)+"...",12,MUTED,false),field());
    Query query=db.collection("DailyPLReports");
    if("crew".equals(currentRole)) query=query.whereEqualTo("targetNik",currentNik);
    else if("cos".equals(currentRole)||"acos".equals(currentRole)) query=query.whereEqualTo("storeCode",storeCode);
    else if(!"admin_utama".equals(currentRole)){results.removeAllViews();results.addView(txt("Akses laporan tidak tersedia untuk jabatan ini.",13,RED,true),field());return;}
    query=query.whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    query.get().addOnSuccessListener(snapshot->{
      Map<String,PLTemporaryRow> rows=new java.util.LinkedHashMap<>();
      for(DocumentSnapshot doc:snapshot.getDocuments()){
        String nik=doc.getString("targetNik");if(nik==null||nik.isEmpty())nik=doc.getId().split("_")[0];
        String code=firstNonEmpty(doc.getString("storeCode"),storeCode);
        String key=code+"_"+nik;PLTemporaryRow row=rows.get(key);
        if(row==null){row=new PLTemporaryRow(nik,firstNonEmpty(doc.getString("targetName"),nik),code,firstNonEmpty(doc.getString("storeName"),code));rows.put(key,row);}
        row.actual[0]+=num(doc.get("PSM"));row.actual[1]+=num(doc.get("PWP"));row.actual[2]+=num(doc.get("Serba Gratis"));row.actual[3]+=num(doc.get("SUEGER"));
      }
      results.removeAllViews();
      LinearLayout summary=col();summary.setPadding(dp(14),dp(12),dp(14),dp(12));summary.setBackground(shape(Color.WHITE,0xffe3e7ee,dp(15)));
      summary.addView(txt("RINGKASAN LAPORAN PENAWARAN LANGSUNG",12,DARK,true),lp(-2));
      LinearLayout dateLine=row();dateLine.setGravity(Gravity.CENTER_VERTICAL);dateLine.addView(txt("Rentang tanggal",11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));dateLine.addView(txt(fromLabel+" s/d "+toLabel,11,DARK,true));LinearLayout.LayoutParams dl=lp(-2);dl.topMargin=dp(9);summary.addView(dateLine,dl);
      LinearLayout dayLine=row();dayLine.setGravity(Gravity.CENTER_VERTICAL);dayLine.addView(txt("JHK",11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));dayLine.addView(txt(jhk+" Hari Kerja",12,DARK,true));LinearLayout.LayoutParams jl=lp(-2);jl.topMargin=dp(8);summary.addView(dayLine,jl);
      LinearLayout.LayoutParams sm=field();sm.bottomMargin=dp(12);results.addView(summary,sm);
      if(rows.isEmpty()){LinearLayout empty=col();empty.setPadding(dp(14),dp(18),dp(14),dp(18));empty.setGravity(Gravity.CENTER);empty.setBackground(shape(Color.WHITE,0xffe3e7ee,dp(14)));empty.addView(txt("Belum ada data Penawaran Langsung pada rentang tanggal ini.",13,MUTED,false),lp(-2));results.addView(empty,field());return;}
      final ArrayList<PLTemporaryRow> list=new ArrayList<>(rows.values());final int[] pending={list.size()};
      for(PLTemporaryRow row:list)loadPLTemporaryTargets(results,row,(Calendar)start.clone(),(Calendar)end.clone(),jhk);
    }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca DailyPLReports: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private void loadPLTemporaryTargets(LinearLayout results,PLTemporaryRow row,Calendar start,Calendar end,int jhk){
    if("admin_utama".equals(currentRole))db.collection("Stores").document(row.code).get().addOnSuccessListener(storeDoc->{String type=firstNonEmpty(storeDoc.getString("storeType"),storeDoc.getString("type"));fetchPLTemporaryTargetDocs(results,row,start,end,jhk,"24_JAM".equals(type)?3.0:2.0);}).addOnFailureListener(e->fetchPLTemporaryTargetDocs(results,row,start,end,jhk,2.0));
    else fetchPLTemporaryTargetDocs(results,row,start,end,jhk,"24_JAM".equals(storeType)?3.0:2.0);
  }

  private void fetchPLTemporaryTargetDocs(LinearLayout results,PLTemporaryRow row,Calendar start,Calendar end,int jhk,double shifts){
    Map<String,DocumentSnapshot> monthTargets=new HashMap<>();ArrayList<String> months=new ArrayList<>();Calendar cursor=(Calendar)start.clone();
    while(!cursor.after(end)){String key=String.format(Locale.US,"%04d%02d",cursor.get(Calendar.YEAR),cursor.get(Calendar.MONTH)+1);if(!months.contains(key))months.add(key);cursor.add(Calendar.MONTH,1);cursor.set(Calendar.DAY_OF_MONTH,1);}
    final int[] remaining={months.size()};final boolean[] failed={false};
    for(String month:months)db.collection("MonthlyPLTargets").document(row.code+"_"+month).get().addOnSuccessListener(doc->{monthTargets.put(month,doc);remaining[0]--;if(remaining[0]==0)finishPLTemporaryTargets(results,row,start,end,jhk,monthTargets,failed[0],shifts);}).addOnFailureListener(e->{failed[0]=true;remaining[0]--;if(remaining[0]==0)finishPLTemporaryTargets(results,row,start,end,jhk,monthTargets,failed[0],shifts);});
  }

  private void finishPLTemporaryTargets(LinearLayout results,PLTemporaryRow row,Calendar start,Calendar end,int jhk,Map<String,DocumentSnapshot> monthTargets,boolean failed,double shifts){
    double[] target={0,0,0,0};Calendar cursor=(Calendar)start.clone();
    while(!cursor.after(end)){
      String month=String.format(Locale.US,"%04d%02d",cursor.get(Calendar.YEAR),cursor.get(Calendar.MONTH)+1);DocumentSnapshot doc=monthTargets.get(month);int day=cursor.get(Calendar.DAY_OF_MONTH);
      if(doc!=null&&doc.exists())for(int c=0;c<4;c++){
        String key=c==0?"PSM_W"+(day<=7?1:day<=15?2:day<=23?3:4):c==1?"PWP_P"+(day<=15?1:2):c==2?"SG_P"+(day<=15?1:2):"SUEGER_P"+(day<=15?1:2);
        double periodTarget=num(doc.get(key)),days=num(doc.get(key+"_DAYS"));if(periodTarget>0&&days>0)target[c]+=periodTarget/days/shifts;
      }
      cursor.add(Calendar.DAY_OF_MONTH,1);
    }
    renderPLTemporaryCrew(results,row,target,jhk,failed);
  }

  private void renderPLTemporaryCrew(LinearLayout results,PLTemporaryRow row,double[] targets,int jhk,boolean targetReadFailed){
    // Layout mengikuti referensi: kartu indikator kompak, tanpa ruang kosong antarbagian.
    LinearLayout crewCard=col();crewCard.setPadding(dp(12),dp(12),dp(12),dp(12));crewCard.setBackground(shape(Color.WHITE,0xffe1e5eb,dp(18)));
    LinearLayout crewHeader=row();crewHeader.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout who=col();who.addView(txt(row.name,14,DARK,true));who.addView(txt("NIK "+row.nik+"  •  "+row.shop+" ("+row.code+")",10,MUTED,false));crewHeader.addView(who,new LinearLayout.LayoutParams(0,-2,1));
    TextView days=center(jhk+" HARI KERJA",9,0xff8f1730,true);days.setPadding(dp(9),dp(6),dp(9),dp(6));days.setBackground(shape(0xffffedf1,0xffffd5df,dp(18)));crewHeader.addView(days,lp(-2));crewCard.addView(crewHeader,lp(-2));
    View divider=new View(this);divider.setBackgroundColor(0xffedf0f3);LinearLayout.LayoutParams divLp=lp(1);divLp.topMargin=dp(10);divLp.bottomMargin=dp(2);crewCard.addView(divider,divLp);
    String[] labels={"PSM","PWP","SERBA GRATIS","SUEGER"};int[] accents={0xffb4233e,0xff2767a8,0xff16845b,0xff8b5bb5};
    for(int i=0;i<4;i++){
      double actual=row.actual[i],target=targets[i],gap=Math.max(0,target-actual);boolean achieved=target>0&&actual>=target;double percent=target>0?actual/target*100:0;
      int statusColor=achieved?0xff16834b:0xffb4233e;
      LinearLayout indicator=col();indicator.setPadding(dp(10),dp(9),dp(10),dp(9));indicator.setBackground(shape(0xfffafbfc,0xffe7eaf0,dp(13)));
      LinearLayout heading=row();heading.setGravity(Gravity.CENTER_VERTICAL);View accent=new View(this);accent.setBackground(shape(accents[i],0,dp(5)));heading.addView(accent,new LinearLayout.LayoutParams(dp(5),dp(22)));
      TextView title=txt(labels[i],13,DARK,true);LinearLayout.LayoutParams titleLp=lp(-2);titleLp.leftMargin=dp(8);heading.addView(title,titleLp);heading.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
      TextView status=center(targetReadFailed?"GAGAL BACA TARGET":target<=0?"TARGET BELUM DIATUR":achieved?"TERCAPAI":"TIDAK TERCAPAI",8,statusColor,true);status.setPadding(dp(7),dp(5),dp(7),dp(5));status.setBackground(shape(achieved?0xffe8f6ed:0xffffedf0,0,dp(15)));heading.addView(status,lp(-2));indicator.addView(heading,lp(-2));
      indicator.addView(txt("JHK  "+jhk+" Hari Kerja",10,MUTED,false),topMargin(6));
      LinearLayout metrics=row();metrics.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams metricsLp=lp(-2);metricsLp.topMargin=dp(8);metricsLp.bottomMargin=dp(6);
      addPLMetric(metrics,"TARGET",target>0?formatGroupedInteger(target):"—",0xff536273,true);addPLMetric(metrics,"AKTUAL",formatGroupedInteger(actual),0xff176b50,true);addPLMetric(metrics,"GAP",target>0?formatGroupedInteger(gap):"—",gap>0?0xffb4233e:0xff16834b,false);indicator.addView(metrics,metricsLp);
      if(target>0){
        LinearLayout progressHead=row();progressHead.addView(txt("PROGRES PENCAPAIAN",9,MUTED,true));progressHead.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));progressHead.addView(txt(String.format(Locale.US,"%.2f%%",percent).replace('.',','),10,statusColor,true));indicator.addView(progressHead,lp(-2));
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(1000);bar.setProgress((int)Math.min(1000,Math.max(0,actual/target*1000)));bar.setProgressTintList(android.content.res.ColorStateList.valueOf(statusColor));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffe6eaf0));LinearLayout.LayoutParams barLp=lp(7);barLp.topMargin=dp(6);indicator.addView(bar,barLp);
        indicator.addView(txt("Aktual dibandingkan dengan target pada rentang tanggal terpilih",9,MUTED,false),lp(-2));
      }else indicator.addView(txt(targetReadFailed?"Data target belum dapat dibaca.":"Target indikator belum diatur untuk periode ini.",10,MUTED,false),lp(-2));
      LinearLayout.LayoutParams itemLp=lp(-2);itemLp.topMargin=dp(8);crewCard.addView(indicator,itemLp);
    }
    LinearLayout.LayoutParams cardLp=field();cardLp.bottomMargin=dp(10);results.addView(crewCard,cardLp);
  }

  private LinearLayout.LayoutParams topMargin(int margin){LinearLayout.LayoutParams p=lp(-2);p.topMargin=dp(margin);return p;}

  private void addPLMetric(LinearLayout parent,String label,String value,int color,boolean divider){
    LinearLayout cell=col();cell.setPadding(dp(7),0,dp(5),0);cell.addView(txt(label,9,MUTED,true));TextView val=txt(value,14,color,true);LinearLayout.LayoutParams vp=lp(-2);vp.topMargin=dp(3);cell.addView(val,vp);parent.addView(cell,new LinearLayout.LayoutParams(0,-2,1));
    if(divider){View line=new View(this);line.setBackgroundColor(0xffe5e9ef);parent.addView(line,new LinearLayout.LayoutParams(dp(1),dp(31)));}
  }

  private void loadPendingRegistrations(LinearLayout body){if(!"admin_utama".equals(currentRole)){toast("Khusus Admin Utama.");return;}db.collection("RegistrationRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pendaftaran menunggu verifikasi.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("name"),role=d.getString("requestedRole"),code=d.getString("storeCode"),shop=d.getString("storeName"),email=d.getString("email");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(role+" | "+code+" - "+shop,12,MUTED,false));LinearLayout buttons=row();Button approve=primary("Setujui");Button reject=smallButton("Tolak");buttons.addView(approve,weight());buttons.addView(reject,weight());card.addView(buttons,field());body.addView(card,field());approve.setOnClickListener(v->approveRegistration(d));reject.setOnClickListener(v->rejectRequest("RegistrationRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pendaftaran: "+e.getLocalizedMessage()));}
  private void approveRegistration(DocumentSnapshot req){
    if(!"admin_utama".equals(currentRole))return;
    String nik=req.getString("nik"),code=req.getString("storeCode"),shop=req.getString("storeName"),role=req.getString("requestedRole");
    if(nik==null||code==null||shop==null||role==null)return;
    db.collection("Stores").document(code).get().addOnSuccessListener(storeDoc->{
      String officialType=storeDoc.exists()?normalizeStoreType(firstNonEmpty(storeDoc.getString("storeType"),storeDoc.getString("type"))):"";
      String chosenType=officialType.isEmpty()?normalizeStoreType(req.getString("requestedStoreType")):officialType;
      if(chosenType.isEmpty()){toast("Jenis toko belum valid. Minta personil mengajukan ulang.");return;}
      Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",req.getString("name"));profile.put("role",role);profile.put("storeCode",code);profile.put("storeName",shop);profile.put("storeType",chosenType);profile.put("email",req.getString("email"));profile.put("isActive",true);profile.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
      Map<String,Object> person=new HashMap<>(profile);person.put("currentRole",role);person.put("currentStoreCode",code);person.put("currentStoreName",shop);
      db.runBatch(batch->{
        batch.set(db.collection("Stores").document(code).collection("Users").document(nik),profile);
        batch.set(db.collection("Personnel").document(nik),person,SetOptions.merge());
        if(!storeDoc.exists()){Map<String,Object> master=new HashMap<>();master.put("storeCode",code);master.put("storeName",shop);master.put("storeType",chosenType);master.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());master.put("createdBy","RegistrationApproval");batch.set(db.collection("Stores").document(code),master,SetOptions.merge());}
        batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy",currentNik.isEmpty()?"AdminUtama":currentNik);
      }).addOnSuccessListener(v->showDashboard("Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menyetujui. Periksa Rules: "+e.getLocalizedMessage()));
    }).addOnFailureListener(e->toast("Gagal memeriksa master toko. Pastikan Admin Utama memiliki akses: "+e.getLocalizedMessage()));
  }
  private void loadPendingCareer(LinearLayout body){if(!"admin_utama".equals(currentRole))return;db.collection("CareerRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pengajuan karir menunggu persetujuan.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("personName"),from=d.getString("currentRole"),to=d.getString("requestedRole"),why=d.getString("reason");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(String.valueOf(from)+" → "+String.valueOf(to)+"\n"+String.valueOf(why),12,MUTED,false));LinearLayout buttons=row();Button yes=primary("Setujui");Button no=smallButton("Tolak");buttons.addView(yes,weight());buttons.addView(no,weight());card.addView(buttons,field());body.addView(card,field());yes.setOnClickListener(v->approveCareer(d));no.setOnClickListener(v->rejectRequest("CareerRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pengajuan karir: "+e.getLocalizedMessage()));}
  private void approveCareer(DocumentSnapshot req){if(!"admin_utama".equals(currentRole))return;String nik=req.getString("nik"),from=req.getString("currentRole"),to=req.getString("requestedRole"),code=req.getString("storeCode");boolean sequence=("crew".equals(from)&&"acos".equals(to))||("acos".equals(from)&&"cos".equals(to));if(!sequence){toast("Urutan jabatan tidak valid.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()||!from.equals(person.getString("currentRole"))){toast("Jabatan personil sudah berubah. Pengajuan perlu diperiksa ulang.");return;}Map<String,Object> update=new HashMap<>();update.put("currentRole",to);update.put("role",to);update.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());String effective=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());Map<String,Object> history=new HashMap<>();history.put("previousRole",from);history.put("newRole",to);history.put("effectiveDate",effective);history.put("approvedBy","AdminUtama");history.put("notes",req.getString("reason"));db.runBatch(batch->{batch.update(db.collection("Personnel").document(nik),update);batch.update(db.collection("Stores").document(code).collection("Users").document(nik),"role",to);batch.set(db.collection("Personnel").document(nik).collection("CareerHistory").document(),history);batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy","AdminUtama");}).addOnSuccessListener(v->showDashboard("Permohonan Karir")).addOnFailureListener(e->toast("Gagal menyetujui karir: "+e.getLocalizedMessage()));});}
  private void rejectRequest(String collection,String id){Map<String,Object> u=new HashMap<>();u.put("status","rejected");u.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());u.put("reviewedBy","AdminUtama");db.collection(collection).document(id).update(u).addOnSuccessListener(v->showDashboard(collection.equals("CareerRequests")?"Permohonan Karir":"Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menolak permohonan: "+e.getLocalizedMessage()));}
  private void processMutation(String nik,String newCode,String newName){if(!"admin_utama".equals(currentRole)||!nik.matches("\\d{8}")||newCode.isEmpty()||newName.isEmpty()){toast("Periksa NIK, kode toko, dan nama toko.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()){toast("Data personil tidak ditemukan di Personnel.");return;}String oldCode=person.getString("currentStoreCode"),oldName=person.getString("currentStoreName"),role=person.getString("currentRole"),name=person.getString("name");Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",name);profile.put("role",role);profile.put("storeCode",newCode);profile.put("storeName",newName);profile.put("email",person.getString("email"));profile.put("isActive",true);Map<String,Object> pupdate=new HashMap<>();pupdate.put("currentStoreCode",newCode);pupdate.put("currentStoreName",newName);pupdate.put("storeCode",newCode);pupdate.put("storeName",newName);Map<String,Object> hist=new HashMap<>();hist.put("previousStoreCode",oldCode);hist.put("previousStoreName",oldName);hist.put("newStoreCode",newCode);hist.put("newStoreName",newName);hist.put("effectiveDate",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()));hist.put("updatedBy","AdminUtama");db.runBatch(batch->{batch.set(db.collection("Stores").document(newCode).collection("Users").document(nik),profile);if(oldCode!=null&&!oldCode.isEmpty()&&!oldCode.equals(newCode))batch.update(db.collection("Stores").document(oldCode).collection("Users").document(nik),"isActive",false);batch.update(db.collection("Personnel").document(nik),pupdate);batch.set(db.collection("Personnel").document(nik).collection("MutationHistory").document(),hist);}).addOnSuccessListener(v->toast("Mutasi berhasil dicatat. Pastikan profil toko lama dinonaktifkan oleh Admin.")).addOnFailureListener(e->toast("Mutasi gagal: "+e.getLocalizedMessage()));});}
  private void showCareerRequest(){if(currentNik.isEmpty()||db==null)return;String next="";if("crew".equals(currentRole))next="acos";else if("acos".equals(currentRole))next="cos";if(next.isEmpty()){toast("COS adalah jenjang tertinggi.");return;}LinearLayout page=col();page.setPadding(dp(18),dp(18),dp(18),dp(18));page.setBackgroundColor(BG);page.addView(txt("PENGAJUAN JENJANG KARIR",20,DARK,true),field());page.addView(txt("Jabatan saat ini: "+roleLabel()+"\nJabatan yang dapat diajukan: "+next.toUpperCase(Locale.US),14,MUTED,false),field());EditText reason=registerField(page,"Alasan pengajuan",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);final String requestedRole=next;Button send=primary("Kirim Pengajuan");page.addView(send,field());Button back=smallButton("Kembali");page.addView(back,field());back.setOnClickListener(v->showDashboard("Profil"));send.setOnClickListener(v->{String why=reason.getText().toString().trim();if(why.isEmpty()){toast("Isi alasan pengajuan terlebih dahulu.");return;}String id=currentNik+"_"+System.currentTimeMillis();Map<String,Object> data=new HashMap<>();data.put("nik",currentNik);data.put("personName",currentName);data.put("currentRole",currentRole);data.put("requestedRole",requestedRole);data.put("storeCode",storeCode);data.put("reason",why);data.put("status","pending");data.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());db.collection("CareerRequests").document(id).set(data).addOnSuccessListener(vv->toast("Pengajuan dikirim ke Admin Utama.")).addOnFailureListener(e->toast("Pengajuan gagal: "+e.getLocalizedMessage()));});setContentView(page);}
  // Dashboard IKT membaca dokumen harian per tanggal agar tidak memerlukan query list.
  private void loadDashboardIKT(TextView[][] fields){
    if(db==null||storeCode==null||storeCode.isEmpty()){setDashboardValues(fields,"--","--","--","DATA BELUM TERSEDIA","--","--","--","--","--","--");return;}
    Calendar now=Calendar.getInstance(); int year=now.get(Calendar.YEAR), month=now.get(Calendar.MONTH);
    String monthId=String.format(Locale.US,"%04d%02d",year,month+1); String targetId=storeCode+"_"+monthId;
    db.collection("MonthlyIKTTargets").document(targetId).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()){setDashboardValues(fields,"--","--","--","TARGET BELUM DIISI","--","--","--","--","--","--");return;}
      double targetSales=num(targetDoc.get("Net Sales")), targetMargin=num(targetDoc.get("Margin %")), targetApc=num(targetDoc.get("APC")), targetStd=num(targetDoc.get("STD"));
      Calendar first=(Calendar)now.clone(); first.set(Calendar.DAY_OF_MONTH,1); int days=now.get(Calendar.DAY_OF_MONTH);
      final double[] sums=new double[5]; final int[] count={0}, pending={days};
      for(int day=1;day<=days;day++){Calendar d=(Calendar)first.clone();d.set(Calendar.DAY_OF_MONTH,day);String key=String.format(Locale.US,"%04d%02d%02d",year,month+1,day);String docId=storeCode+"_"+key;
        db.collection("DailyStoreReports").document(docId).get().addOnSuccessListener(doc->{if(doc.exists()){sums[0]+=num(doc.get("Net Sales"));sums[1]+=num(doc.get("Margin %"));sums[2]+=num(doc.get("NSB"));sums[3]+=num(doc.get("APC"));sums[4]+=num(doc.get("STD"));count[0]++;}pending[0]--;if(pending[0]==0)renderDashboardIKT(fields,sums,count[0],targetSales,targetMargin,targetApc,targetStd);
        }).addOnFailureListener(e->{pending[0]--;if(pending[0]==0)renderDashboardIKT(fields,sums,count[0],targetSales,targetMargin,targetApc,targetStd);});
      }
    }).addOnFailureListener(e->setDashboardValues(fields,"--","--","--","GAGAL MEMBACA TARGET","--","--","--","--","--","--"));
  }
  private double num(Object value){if(value instanceof Number)return ((Number)value).doubleValue();if(value==null)return 0;try{return Double.parseDouble(String.valueOf(value).replace(",","."));}catch(Exception e){return 0;}}
  private String pct(double value,int decimals){return String.format(Locale.US,"%."+decimals+"f%%",value).replace('.',',');}
  private int achievementColor(String value){
    if(value==null||value.equals("--"))return Color.BLACK;
    double v=0;try{v=Double.parseDouble(value.replace("%","").replace(',','.'));}catch(Exception ignored){}
    if(v<=50.0)return 0xffc62828;
    if(v<80.0)return 0xffb77900;
    return 0xff18864b;
  }
  private void setDashboardValues(TextView[][] f,String sales,String margin,String nsb,String status,String salesTarget,String salesActual,String marginTarget,String marginActual,String nsbTarget,String nsbActual){
    String[] headline={sales,margin,nsb,status};for(int i=0;i<4;i++)f[i][0].setText(headline[i]);
    // Net Sales and Margin use the achievement thresholds; NSB is handled separately.
    f[0][0].setTextColor(achievementColor(sales));
    f[1][0].setTextColor(achievementColor(margin));
    f[0][1].setText("Pencapaian");f[0][2].setText("Target : "+salesTarget);f[0][3].setText("Aktual : "+salesActual);
    f[1][1].setText("Pencapaian");f[1][2].setText("Target : "+marginTarget);f[1][3].setText("Aktual : "+marginActual);
    f[2][1].setText("Pencapaian");f[2][2].setText("Batas : "+nsbTarget);f[2][3].setText("Aktual : "+nsbActual);
    f[3][1].setText("Status toko");f[3][2].setText("Target : MENANG");f[3][3].setText("Aktual : "+status);
    double nsbValue=0; try{nsbValue=Double.parseDouble(nsb.replace("%","").replace(',','.'));}catch(Exception ignored){}
    String nsbStatus=nsb.equals("--")?"Menunggu data":(nsbValue<=0.15?"NSB TERKENDALI":(nsbValue<=0.30?"WASPADA KONTROL NSB":"NSB OVERLOAD"));
    String salesNote=sales.equals("--")?"Menunggu data":"Dalam Progres";
    String marginNote=margin.equals("--")?"Menunggu data":"Dalam Progres";
    String[] notes={"Keterangan : "+salesNote,"Keterangan : "+marginNote,"Keterangan : "+nsbStatus,"Keterangan : "+(status.equals("MENANG")?"✓ Tercapai":"Dalam Progres")};
    for(int i=0;i<4;i++)f[i][4].setText(notes[i]);
    if(!nsb.equals("--")){
      int nsbColor=nsbValue>0.15?0xffc62828:0xff18864b;
      f[2][0].setTextColor(nsbColor);
      f[2][4].setTextColor(nsbColor);
    }
  }
  private void renderDashboardIKT(TextView[][] fields,double[] sums,int count,double targetSales,double targetMargin,double targetApc,double targetStd){
    if(count==0){setDashboardValues(fields,"--","--","--","BELUM ADA DATA","--","Rp 0","--","--","--","--");return;}
    double avgMargin=sums[1]/count,avgApc=sums[3]/count,avgStd=sums[4]/count;
    double nsbAllowance=sums[0]*0.0015; double nsbRemaining=nsbAllowance-sums[2];
    // Dashboard classification uses absolute NSB actual; sign is preserved in the displayed Rupiah value.
    double nsbPercent=sums[0]<=0?0:(Math.abs(sums[2])/sums[0])*100.0;
    double salesAchievement=targetSales<=0?0:(sums[0]/targetSales)*100.0; double marginAchievement=targetMargin<=0?0:(avgMargin/targetMargin)*100.0;
    boolean salesOk=targetSales>0&&sums[0]>=targetSales, marginOk=targetMargin>0&&avgMargin>=targetMargin, nsbOk=nsbPercent<=0.15, apcOk=targetApc>0&&avgApc>=targetApc, stdOk=targetStd>0&&avgStd>=targetStd;
    String status=(salesOk&&marginOk&&nsbOk&&apcOk&&stdOk)?"MENANG":"DALAM PROGRES";
    setDashboardValues(fields,pct(salesAchievement,2),pct(marginAchievement,2),pct(nsbPercent,3),status,formatRupiah(targetSales),formatRupiah(sums[0]),pct(targetMargin,2),pct(avgMargin,2),formatRupiah(nsbAllowance),formatRupiah(sums[2]));
  }

  private TextView addDropdownDatePicker(LinearLayout body,DatePicker picker,boolean monthOnly,Runnable onChanged){
    picker.setVisibility(View.GONE);
    body.addView(picker,new LinearLayout.LayoutParams(1,1));
    TextView selector=txt("Pilih "+(monthOnly?"Bulan":"Tanggal")+"  ▾",14,DARK,true);
    selector.setGravity(Gravity.CENTER_VERTICAL);
    selector.setPadding(dp(14),dp(13),dp(14),dp(13));
    selector.setBackground(shape(Color.WHITE,0xffdfe3e9,dp(12)));
    body.addView(selector,field());
    setDropdownDatePickerListener(selector,picker,monthOnly,onChanged);
    return selector;
  }
  private void setDropdownDatePickerListener(TextView selector,DatePicker picker,boolean monthOnly,Runnable onChanged){
    Runnable updateLabel=()->{
      Calendar selected=Calendar.getInstance();selected.set(picker.getYear(),picker.getMonth(),picker.getDayOfMonth());
      String label=monthOnly?new SimpleDateFormat("MMMM yyyy",new Locale("id","ID")).format(selected.getTime()):new SimpleDateFormat("d MMMM yyyy",new Locale("id","ID")).format(selected.getTime());
      selector.setText(label+"  ▾");
    };
    updateLabel.run();
    selector.setOnClickListener(v->{
      DatePickerDialog dialog=new DatePickerDialog(this,(view,y,m,d)->{
        picker.updateDate(y,m,d);updateLabel.run();if(onChanged!=null)onChanged.run();
      },picker.getYear(),picker.getMonth(),picker.getDayOfMonth());
      dialog.show();
    });
  }

  private String selectedDate(DatePicker date){Calendar c=Calendar.getInstance();c.set(date.getYear(),date.getMonth(),date.getDayOfMonth(),0,0,0);c.set(Calendar.MILLISECOND,0);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
  private String selectedDateKey(DatePicker date){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(date.getYear()-1900,date.getMonth(),date.getDayOfMonth()));}
  private boolean canEditToday(DatePicker date){Calendar now=Calendar.getInstance();return date.getYear()==now.get(Calendar.YEAR)&&date.getMonth()==now.get(Calendar.MONTH)&&date.getDayOfMonth()==now.get(Calendar.DAY_OF_MONTH)&&now.get(Calendar.HOUR_OF_DAY)<24;}
  private void loadDailyInput(String page,DatePicker date,Map<String,EditText> inputs,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null)return;
    boolean store=page.equals("Input Toko");for(EditText input:inputs.values())input.setText("0");String day=selectedDateKey(date);String targetNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();if(!store&&!targetNik.matches("\\d{8}"))return;String id=store?storeCode+"_"+day:targetNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    db.collection(collection).document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca data: "+e.getLocalizedMessage()));
  }
  private void saveDailyInput(String page,DatePicker date,Map<String,EditText> inputs,Button save,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    boolean store=page.equals("Input Toko");
    boolean elevated="cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole);
    if(store&&!elevated){toast("Hanya COS/ACOS yang dapat menginput data toko.");return;}
    if(!store&&!("crew".equals(currentRole)||elevated)){toast("Jabatan ini tidak memiliki akses input PL.");return;}
    String selectedNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();
    if(!store&&!selectedNik.matches("\\d{8}")){toast("NIK Crew harus 8 angka.");return;}
    if(!store&&!elevated&&!selectedNik.equals(currentNik)){toast("Crew hanya dapat menginput data miliknya sendiri.");return;}
    String dateText=selectedDate(date),day=selectedDateKey(date);String id=store?storeCode+"_"+day:selectedNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    Map<String,Object> data=new HashMap<>();data.put("date",dateText);data.put("dateKey",day);data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("ownerNik",currentNik);data.put("ownerName",currentName);data.put("ownerRole",currentRole);
    if(!store){data.put("targetNik",selectedNik);data.put("targetName",selectedNik.equals(currentNik)?currentName:"Crew "+selectedNik);}
    try{
      for(String key:inputs.keySet()){
        String raw=inputs.get(key).getText().toString().trim().replace("%","");
        if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');
        if(raw.isEmpty()){toast("Indikator "+key+" wajib diisi.");return;}
        double value=Double.parseDouble(raw);
        if((!key.equalsIgnoreCase("NSB")&&value<0)||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Nilai "+key+" tidak valid.");return;}
        if(!key.equalsIgnoreCase("NSB")&&value<=0){toast(key+" harus lebih dari 0.");return;}
        data.put(key,isDecimalMetric(key)?value:(long)value);
      }
    }catch(NumberFormatException ex){toast("Pastikan semua indikator diisi dengan angka yang valid.");return;}
    StringBuilder summary=new StringBuilder("Tanggal: ").append(dateText).append("\nToko: ").append(storeCode).append(" - ").append(storeName).append("\n\n");
    for(String key:inputs.keySet())summary.append(key).append(": ").append(inputs.get(key).getText().toString()).append("\n");
    new AlertDialog.Builder(this).setTitle("Konfirmasi Data Harian").setMessage(summary.toString()).setNegativeButton("Periksa Kembali",(d,w)->{}).setPositiveButton("Konfirmasi & Simpan",(d,w)->{
      save.setEnabled(false);save.setText("Menyimpan...");
      db.collection(collection).document(id).get().addOnSuccessListener(oldDoc->{
        boolean existed=oldDoc.exists();Map<String,Object> oldValues=existed?new HashMap<>(oldDoc.getData()):new HashMap<>();
        data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
        data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedByRole",currentRole);
        if(!existed){data.put("firstSavedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());Calendar now=Calendar.getInstance();data.put("isLate",now.get(Calendar.HOUR_OF_DAY)>=23);}
        else {Object first=oldDoc.get("firstSavedAt");if(first!=null)data.put("firstSavedAt",first);Object late=oldDoc.get("isLate");data.put("isLate",late instanceof Boolean?(Boolean)late:false);}
        com.google.firebase.firestore.WriteBatch batch=db.batch();com.google.firebase.firestore.DocumentReference reportRef=db.collection(collection).document(id);batch.set(reportRef,data,SetOptions.merge());
        if(existed){Map<String,Object> audit=new HashMap<>();audit.put("date",dateText);audit.put("storeCode",storeCode);audit.put("editedByNik",currentNik);audit.put("editedByName",currentName);audit.put("editedByRole",currentRole);audit.put("editedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());audit.put("oldValues",oldValues);audit.put("newValues",new HashMap<>(data));batch.set(reportRef.collection("EditHistory").document(),audit);}
        batch.commit().addOnSuccessListener(unused->{
          save.setEnabled(true);save.setText("Simpan");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));
          toast(existed?"Data berhasil diperbarui. Riwayat koreksi dicatat.":"Data harian berhasil disimpan.");
          if(store) showDashboard("Beranda");
        }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal menyimpan. Periksa Firestore Rules: "+e.getLocalizedMessage());});
      }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal memeriksa data sebelumnya: "+e.getLocalizedMessage());});
    }).show();
  }


  private void showStoreTypeSettings(LinearLayout body){
    cardTitle(body,"PENGATURAN JENIS TOKO");
    body.addView(txt("Atur jenis toko satu kali. Aplikasi akan membacanya otomatis saat personil login.",12,MUTED,false),field());
    EditText code=registerField(body,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText name=registerField(body,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    Spinner type=new Spinner(this);String[] types={"Pilih Jenis Toko","24 Jam","Normal"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));body.addView(type,field());
    Button load=smallButton("Cek Data Toko");body.addView(load,field());
    load.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US);if(c.isEmpty()){toast("Masukkan kode toko.");return;}db.collection("Stores").document(c).get().addOnSuccessListener(d->{if(d.exists()){name.setText(d.getString("storeName")==null?"":d.getString("storeName"));String t=firstNonEmpty(d.getString("storeType"),d.getString("type"));type.setSelection("24_JAM".equals(t)?1:"NORMAL".equals(t)?2:0);toast("Data toko ditemukan.");}else toast("Dokumen master toko belum ada. Simpan untuk membuatnya.");}).addOnFailureListener(e->toast("Gagal membaca toko: "+e.getLocalizedMessage()));});
    Button save=primary("Simpan Jenis Toko");body.addView(save,field());
    save.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US),n=name.getText().toString().trim();int selected=type.getSelectedItemPosition();if(c.isEmpty()||n.isEmpty()||selected==0){toast("Lengkapi kode, nama, dan jenis toko.");return;}String t=selected==1?"24_JAM":"NORMAL";Map<String,Object> data=new HashMap<>();data.put("storeCode",c);data.put("storeName",n);data.put("storeType",t);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());data.put("updatedBy","AdminUtama");save.setEnabled(false);db.collection("Stores").document(c).set(data,SetOptions.merge()).addOnSuccessListener(x->{save.setEnabled(true);toast("Jenis toko "+t.replace('_',' ')+" berhasil disimpan untuk "+c+".");}).addOnFailureListener(e->{save.setEnabled(true);toast("Gagal menyimpan. Pastikan Firestore Rules mengizinkan Admin Utama mengubah master Stores: "+e.getLocalizedMessage());});});
  }

  private String[] menuEntries(){
    if("admin_utama".equals(currentRole))return new String[]{"Beranda","Pengaturan Jenis Toko","Verifikasi Pendaftaran","Permohonan Karir","Mutasi Personil"};
    if("cos".equals(currentRole)||"acos".equals(currentRole))return new String[]{"Beranda","Input Target IKT","Input Target Penawaran Langsung","Input Toko","Input PL Crew","Ranking Crew","Reward","Laporan Penjualan","Profil","Keluar"};
    return new String[]{"Beranda","Input PL","Ranking Crew","Laporan Penjualan","Profil","Keluar"};
  }
  private String monthKey(DatePicker date){return String.format(Locale.US,"%04d%02d",date.getYear(),date.getMonth()+1);}
  // Tampilan angka tidak mengubah nilai numerik yang disimpan di Firestore.
  private String cleanNumber(Object value, boolean decimalAllowed){
    if(value==null)return "0";
    try{
      double n=Double.parseDouble(String.valueOf(value).replace(",","."));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0";
      if(!decimalAllowed || n==Math.rint(n))return String.format(Locale.US,"%.0f",n);
      return String.format(Locale.US,"%s",new java.math.BigDecimal(String.valueOf(n)).stripTrailingZeros().toPlainString());
    }catch(Exception e){return String.valueOf(value);}
  }
  // Margin disimpan sebagai angka (mis. 12.52), tetapi selalu ditampilkan 2 desimal dengan koma dan %.
  private String formatMargin(Object value){
    try{
      double n=Double.parseDouble(String.valueOf(value).trim().replace("%","").replace(',','.'));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0,00%";
      return String.format(new Locale("id","ID"),"%.2f%%",n);
    }catch(Exception e){return "0,00%";}
  }
  private String formatGroupedInteger(Object value){
    try{java.math.BigDecimal n=new java.math.BigDecimal(String.valueOf(value).replace(",","."));return String.format(new Locale("id","ID"),"%,.0f",n.doubleValue());}catch(Exception e){return "0";}
  }
  private String profileDocumentId(){return currentRole!=null&&currentRole.equals("admin_utama")?"AdminUtama":currentNik;}
  private void chooseProfilePhoto(){Intent intent=new Intent(Intent.ACTION_GET_CONTENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(intent,"Pilih foto profil"),PICK_PROFILE_PHOTO);}
  private void loadProfilePhoto(){if(db==null)return;String docId=profileDocumentId();if(docId==null||docId.isEmpty())return;db.collection("Users").document(docId).get().addOnSuccessListener(doc->{String url=doc.getString("profilePhotoUrl");if(url!=null&&!url.isEmpty()&&storage!=null){storage.getReferenceFromUrl(url).getBytes(4*1024*1024).addOnSuccessListener(bytes->{if(profileAvatar!=null)profileAvatar.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length));}).addOnFailureListener(e->toast("Foto profil gagal dimuat."));}});}
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_PROFILE_PHOTO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri source=data.getData();Uri destination=Uri.fromFile(new File(getCacheDir(),"profile_crop_"+System.currentTimeMillis()+".jpg"));UCrop.of(source,destination).withAspectRatio(1,1).withMaxResultSize(900,900).start(this);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==RESULT_OK&&data!=null){Uri cropped=UCrop.getOutput(data);if(cropped!=null)uploadProfilePhoto(cropped);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==UCrop.RESULT_ERROR&&data!=null){Throwable error=UCrop.getError(data);toast("Gagal memotong foto: "+(error==null?"coba foto lain":error.getLocalizedMessage()));}}
  private void uploadProfilePhoto(Uri uri){if(profileAvatar!=null)profileAvatar.setImageURI(uri);if(storage==null||auth==null||auth.getCurrentUser()==null||db==null){toast("Firebase Storage belum siap.");return;}String docId=profileDocumentId();String uid=auth.getCurrentUser().getUid();StorageReference ref=storage.getReference().child("profile_photos").child(uid+".jpg");toast("Mengunggah foto profil...");ref.putFile(uri).continueWithTask(task->{if(!task.isSuccessful())throw task.getException();return ref.getDownloadUrl();}).addOnSuccessListener(download->{Map<String,Object> update=new HashMap<>();update.put("profilePhotoUrl",download.toString());db.collection("Users").document(docId).update(update).addOnSuccessListener(v->toast("Foto profil berhasil disimpan.")).addOnFailureListener(e->toast("Foto terunggah, tetapi profil Firestore menolak penyimpanan URL. Periksa Rules."));}).addOnFailureListener(e->toast("Gagal mengunggah foto: "+e.getLocalizedMessage()));}
  private void configureMetricInput(EditText input,String key){
    if(isDecimalMetric(key)){
      input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
      input.setKeyListener(DigitsKeyListener.getInstance("0123456789,.%"));
      input.setHint("0,0 %");
    }else{
      input.setInputType(InputType.TYPE_CLASS_NUMBER);
      input.setKeyListener(DigitsKeyListener.getInstance(key.equalsIgnoreCase("NSB")?"-0123456789.":(isRupiahMetric(key)?"0123456789.":"0123456789")));
    }
  }
  private void applyZeroFocusStyle(EditText input){
    input.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
    input.setOnFocusChangeListener((v,focused)->{
      String raw=input.getText().toString().trim().replace(",",".");
      boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
      input.setTypeface(Typeface.create("sans-serif",focused&&zero?Typeface.BOLD:Typeface.NORMAL));
    });
    input.addTextChangedListener(new TextWatcher(){
      boolean fixing=false;
      public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){
        if(input.hasFocus()){
          String raw=s.toString().trim().replace(",",".").replace("%","");
          boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
          input.setTypeface(Typeface.create("sans-serif",zero?Typeface.BOLD:Typeface.NORMAL));
        }
      }
      public void afterTextChanged(Editable e){
        if(fixing||!input.hasFocus()||e.length()<=1)return;
        if(e.charAt(0)=='0' && Character.isDigit(e.charAt(1))){fixing=true;e.delete(0,1);fixing=false;}
      }
    });
  }
  private boolean isDecimalMetric(String key){return key!=null&&key.toLowerCase(Locale.ROOT).contains("margin");}
  private boolean isRupiahMetric(String key){return key!=null&&(key.equalsIgnoreCase("Net Sales")||key.equalsIgnoreCase("NSB")||key.equalsIgnoreCase("APC")||key.equalsIgnoreCase("netSales")||key.equalsIgnoreCase("nsb")||key.equalsIgnoreCase("apc"));}
  private String formatRupiah(Object value){return "Rp "+String.format(Locale.US,"%,.0f",Double.parseDouble(cleanNumber(value,false))).replace(',','.');}
  private void loadMonthlyTarget(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return;String id=storeCode+"_"+monthKey(date);db.collection("MonthlyIKTTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca target: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyTarget(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target IKT.");return;}if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","");if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyIKTTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));toast("Target IKT bulanan berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target");toast("Gagal menyimpan target. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }
  private void addTargetPeriod(LinearLayout body,Map<String,EditText> inputs,String category,String period,String key){
    LinearLayout card=col(); card.setBackground(shape(Color.WHITE,0xffe5e9ef,dp(13))); card.setPadding(dp(12),dp(10),dp(12),dp(10));
    card.setTag("PLPERIOD:"+key); card.addView(txt(category+"  •  "+period,13,DARK,true)); EditText value=new EditText(this); value.setSingleLine(true); value.setText(""); value.setHint("Masukkan target"); value.setInputType(InputType.TYPE_CLASS_NUMBER); applyZeroFocusStyle(value); card.addView(value,lp(-2));
    LinearLayout.LayoutParams q=lp(-2); q.bottomMargin=dp(7); body.addView(card,q); inputs.put(key,value);
  }
  private LinearLayout rankingMenuCard(int iconRes,String title,String subtitle,boolean active,Runnable action){
    LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(12),dp(8),dp(12));
    card.setBackground(shape(active?RED:Color.WHITE,active?0xffe0a000:0xffe2e5eb,dp(14)));card.setElevation(dp(active?4:3));card.setClickable(true);card.setFocusable(true);
    ImageView symbol=new ImageView(this);symbol.setImageResource(iconRes);symbol.setScaleType(ImageView.ScaleType.FIT_CENTER);symbol.setColorFilter(active?Color.WHITE:RED);LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(42),dp(42));iconLp.rightMargin=dp(7);card.addView(symbol,iconLp);
    LinearLayout texts=col();texts.setGravity(Gravity.CENTER_VERTICAL);texts.addView(txt(title,14,active?Color.WHITE:DARK,true));TextView desc=txt(subtitle,10,active?0xffffeeee:MUTED,false);desc.setMaxLines(2);texts.addView(desc,lp(-2));card.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
    card.addView(txt("›",25,active?Color.WHITE:RED,true),new LinearLayout.LayoutParams(-2,-2));card.setOnClickListener(v->{if(action!=null)action.run();});
    return card;
  }

  private void setRankingMenuCardActive(LinearLayout card,boolean active){
    card.setBackground(shape(active?RED:Color.WHITE,active?0xffe0a000:0xffe2e5eb,dp(14)));card.setElevation(dp(active?4:3));
    if(card.getChildCount()>0&&card.getChildAt(0) instanceof ImageView)((ImageView)card.getChildAt(0)).setColorFilter(active?Color.WHITE:RED);
    if(card.getChildCount()>1&&card.getChildAt(1) instanceof LinearLayout){LinearLayout texts=(LinearLayout)card.getChildAt(1);if(texts.getChildCount()>0&&texts.getChildAt(0) instanceof TextView)((TextView)texts.getChildAt(0)).setTextColor(active?Color.WHITE:DARK);if(texts.getChildCount()>1&&texts.getChildAt(1) instanceof TextView)((TextView)texts.getChildAt(1)).setTextColor(active?0xffffeeee:MUTED);}
    if(card.getChildCount()>2&&card.getChildAt(2) instanceof TextView)((TextView)card.getChildAt(2)).setTextColor(active?Color.WHITE:RED);
  }

  private void loadCrewRanking(LinearLayout results,DatePicker picker,boolean monthly){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){results.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",13,RED,true),field());return;}
    if(!("acos".equals(currentRole)||"cos".equals(currentRole)||"crew".equals(currentRole))){results.addView(txt("Ranking perlu dibuka dari akun toko.",13,MUTED,false),field());return;}
    final int y=picker.getYear(),m=picker.getMonth()+1,d=picker.getDayOfMonth();
    final String month=String.format(Locale.US,"%04d%02d",y,m);
    final String from=monthly?String.format(Locale.US,"%04d%02d01",y,m):String.format(Locale.US,"%04d%02d%02d",y,m,d);
    final String to=monthly?String.format(Locale.US,"%04d%02d31",y,m):from;
    results.addView(txt("Menghitung ranking...",12,MUTED,false),field());
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()){results.removeAllViews();results.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",13,RED,false),field());return;}
      Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode).whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
      q.get().addOnSuccessListener(snapshot->{
        class RankRow {String nik,name;double score;double[] actual=new double[4];RankRow(String n,String nm){nik=n;name=nm;}}
        Map<String,RankRow> rows=new HashMap<>();
        for(DocumentSnapshot doc:snapshot.getDocuments()){
          String nik=doc.getString("targetNik");if(nik==null||nik.isEmpty())continue;
          String name=firstNonEmpty(doc.getString("targetName"),nik);RankRow rr=rows.get(nik);if(rr==null){rr=new RankRow(nik,name);rows.put(nik,rr);}
          rr.actual[0]+=num(doc.get("PSM"));rr.actual[1]+=num(doc.get("PWP"));rr.actual[2]+=num(doc.get("Serba Gratis"));rr.actual[3]+=num(doc.get("SUEGER"));
        }
        String[] categories={"PSM","PWP","Serba Gratis","SUEGER"};String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};double[] weights={.25,.25,.30,.20};double shifts="24_JAM".equals(storeType)?3.0:2.0;
        double[] denominators=new double[4];
        if(monthly){
          // Target bulanan Crew = total target toko per kategori dibagi jumlah shift.
          // Hari kerja dipakai untuk target harian, bukan untuk mengecilkan target bulanan.
          for(int c=0;c<4;c++)for(String key:periods[c]){double target=num(targetDoc.get(key));double days=num(targetDoc.get(key+"_DAYS"));if(target>=0&&days>0)denominators[c]+=target/shifts;}
        }
        else {int dayIndex=d;for(int c=0;c<4;c++){String key;if(c==0)key="PSM_W"+(dayIndex<=7?1:dayIndex<=15?2:dayIndex<=23?3:4);else key=categories[c].equals("PWP")?"PWP_P"+(dayIndex<=15?1:2):categories[c].equals("Serba Gratis")?"SG_P"+(dayIndex<=15?1:2):"SUEGER_P"+(dayIndex<=15?1:2);double target=num(targetDoc.get(key)),days=num(targetDoc.get(key+"_DAYS"));if(target>0&&days>0)denominators[c]=target/days/shifts;}}
        ArrayList<RankRow> sorted=new ArrayList<>(rows.values());for(RankRow rr:sorted){double score=0;for(int c=0;c<4;c++){if(denominators[c]>0)score+=(rr.actual[c]/denominators[c])*weights[c]*100.0;}rr.score=score;}
        Collections.sort(sorted,(a,b)->Double.compare(b.score,a.score));results.removeAllViews();cardTitle(results,monthly?"Ranking Bulanan • "+month:"Ranking Harian • "+from);
        if(sorted.isEmpty()){results.addView(txt("Belum ada laporan Crew pada periode ini.",13,MUTED,false),field());return;}
        int rank=1;for(RankRow rr:sorted){
          int accent=rank==1?0xffd4a900:rank==2?0xff9aa0a8:rank==3?0xffb87333:0xffe5e9ef;
          int badgeColor=rank==1?0xffc99b00:rank==2?0xff858b94:rank==3?0xffad6b32:MUTED;
          LinearLayout card=col();card.setBackground(shape(Color.WHITE,rank<=3?accent:0xffe5e9ef,dp(14)));card.setPadding(dp(12),dp(10),dp(12),dp(10));
          if(rank<=3){View topBand=new View(this);topBand.setBackground(shape(accent,0,dp(5)));LinearLayout.LayoutParams bandLp=new LinearLayout.LayoutParams(-1,dp(6));bandLp.bottomMargin=dp(8);card.addView(topBand,bandLp);}
          LinearLayout content=row();content.setGravity(Gravity.CENTER_VERTICAL);
          LinearLayout emblem=col();emblem.setGravity(Gravity.CENTER);emblem.setMinimumWidth(dp(54));
          if(rank<=3){
            int medalBg=rank==1?0xfffff0bd:rank==2?0xffeef1f5:0xffffe7d9;
            int medalStroke=rank==1?0xffd4a900:rank==2?0xff9aa0a8:0xffb87333;
            LinearLayout medal=col();medal.setGravity(Gravity.CENTER);medal.setPadding(dp(5),dp(5),dp(5),dp(5));
            medal.setBackground(shape(medalBg,medalStroke,dp(12)));
            ImageView trophyIcon=new ImageView(this);trophyIcon.setImageResource(rank==1?R.drawable.rank_trophy_gold:rank==2?R.drawable.rank_trophy_silver:R.drawable.rank_trophy_bronze);trophyIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams trophyLp=new LinearLayout.LayoutParams(dp(48),dp(48));medal.addView(trophyIcon,trophyLp);
            TextView medalNo=center("#"+rank,15,Color.WHITE,true);medalNo.setBackground(shape(medalStroke,0,dp(18)));medalNo.setPadding(dp(10),dp(3),dp(10),dp(3));LinearLayout.LayoutParams noLp=lp(-2);noLp.topMargin=dp(2);medal.addView(medalNo,noLp);
            TextView medalLabel=center(rank==1?"JUARA EMAS":rank==2?"JUARA PERAK":"JUARA PERUNGGU",8,badgeColor,true);LinearLayout.LayoutParams labelLp=lp(-2);labelLp.topMargin=dp(2);medal.addView(medalLabel,labelLp);
            emblem.addView(medal,new LinearLayout.LayoutParams(dp(50),-2));
          }else{
            TextView plainRank=center(String.valueOf(rank),23,MUTED,true);plainRank.setBackground(shape(0xfff3f4f6,0xffe5e9ef,dp(10)));plainRank.setPadding(dp(10),dp(7),dp(10),dp(7));emblem.addView(plainRank,lp(-2));
          }
          content.addView(emblem,new LinearLayout.LayoutParams(dp(58),-2));
          LinearLayout details=col();details.addView(txt(rr.name,14,DARK,true));details.addView(txt("NIK "+rr.nik+"  •  Nilai "+String.format(Locale.US,"%.2f",rr.score)+"%",12,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true));
          for(int c=0;c<4;c++)details.addView(txt(categories[c]+": "+formatGroupedInteger(rr.actual[c])+" / target "+(denominators[c]>0?formatGroupedInteger(denominators[c]):"belum diatur"),11,MUTED,false));
          content.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView scorePill=center(String.format(Locale.US,"%.2f",rr.score)+"%",14,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true);scorePill.setPadding(dp(10),dp(10),dp(10),dp(10));scorePill.setBackground(shape(rank==1?0xffffedb0:rank==2?0xffedf0f3:rank==3?0xffffe1d2:0xffedf0f4,0,dp(24)));content.addView(scorePill,new LinearLayout.LayoutParams(-2,-2));card.addView(content,lp(-2));results.addView(card,field());rank++;}
      }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca laporan ranking: "+e.getLocalizedMessage(),13,RED,false),field());});
    }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca target ranking: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private static class AdvancedRankRow { String nik,name; double score; double[] actual=new double[4]; AdvancedRankRow(String n,String nm){nik=n;name=nm;} }

  private void loadCrewRankingAdvanced(LinearLayout results,DatePicker picker,boolean annual){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){results.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",13,RED,true),field());return;}
    if(!("acos".equals(currentRole)||"cos".equals(currentRole)||"crew".equals(currentRole))){results.addView(txt("Ranking perlu dibuka dari akun toko.",13,MUTED,false),field());return;}
    final int year=picker.getYear(),month=picker.getMonth()+1,day=picker.getDayOfMonth();
    final String from=annual?String.format(Locale.US,"%04d0101",year):String.format(Locale.US,"%04d%02d01",year,month);
    final String to=annual?String.format(Locale.US,"%04d1231",year):String.format(Locale.US,"%04d%02d%02d",year,month,monthDays(year,month));
    results.addView(txt(annual?"Menyusun raport Crew Januari–Desember...":"Menghitung ranking sesuai periode target...",12,MUTED,false),field());
    Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode).whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
    if("crew".equals(currentRole))q=q.whereEqualTo("targetNik",currentNik);
    q.get().addOnSuccessListener(snapshot->{
      Map<String,AdvancedRankRow> rows=new HashMap<>();
      for(DocumentSnapshot doc:snapshot.getDocuments()){
        String nik=doc.getString("targetNik");if(nik==null||nik.isEmpty())continue;
        String dateKey=doc.getString("dateKey");if(dateKey==null)continue;
        AdvancedRankRow rr=rows.get(nik);if(rr==null){rr=new AdvancedRankRow(nik,firstNonEmpty(doc.getString("targetName"),nik));rows.put(nik,rr);}
        int docMonth=Integer.parseInt(dateKey.substring(4,6));int docDay=Integer.parseInt(dateKey.substring(6,8));
        for(int c=0;c<4;c++){
          boolean include=annual || (c==0 ? (docDay<=7?1:docDay<=15?2:docDay<=23?3:4)==(day<=7?1:day<=15?2:day<=23?3:4) : (docDay<=15)==(day<=15));
          if(include)rr.actual[c]+=num(doc.get(new String[]{"PSM","PWP","Serba Gratis","SUEGER"}[c]));
        }
      }
      if(annual)loadAnnualTargets(results,year,0,new double[4],rows);
      else db.collection("MonthlyPLTargets").document(storeCode+"_"+String.format(Locale.US,"%04d%02d",year,month)).get().addOnSuccessListener(target->{
        if(!target.exists()){results.removeAllViews();results.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",13,RED,false),field());return;}
        double[] denominators=new double[4];String[][] keys={{"PSM_W"+(day<=7?1:day<=15?2:day<=23?3:4)},{"PWP_P"+(day<=15?1:2)},{"SG_P"+(day<=15?1:2)},{"SUEGER_P"+(day<=15?1:2)}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        for(int c=0;c<4;c++)denominators[c]=num(target.get(keys[c][0]))/shifts;
        renderAdvancedRanking(results,rows,denominators,"Ranking Periode • "+String.format(Locale.US,"%04d%02d",year,month),new String[]{"PSM","PWP","Serba Gratis","SUEGER"});
      }).addOnFailureListener(e->showRankingError(results,e));
    }).addOnFailureListener(e->showRankingError(results,e));
  }

  private int monthDays(int year,int month){Calendar c=new GregorianCalendar(year,month-1,1);return c.getActualMaximum(Calendar.DAY_OF_MONTH);}
  private interface AnnualTargetDone { void done(double[] denominators); }
  private void loadAnnualTargets(LinearLayout results,int year,int index,double[] denominators,Map<String,AdvancedRankRow> rows){
    if(index>=12){renderAdvancedRanking(results,rows,denominators,"Raport Crew • Tahun "+year,new String[]{"PSM","PWP","Serba Gratis","SUEGER"});return;}
    String month=String.format(Locale.US,"%04d%02d",year,index+1);
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(doc->{
      if(doc.exists()){
        String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        for(int c=0;c<4;c++)for(String key:periods[c])denominators[c]+=num(doc.get(key))/shifts;
      }
      loadAnnualTargets(results,year,index+1,denominators,rows);
    }).addOnFailureListener(e->showRankingError(results,e));
  }
  private void renderAdvancedRanking(LinearLayout results,Map<String,AdvancedRankRow> rows,double[] denominators,String title,String[] categories){
    results.removeAllViews();cardTitle(results,title);
    ArrayList<AdvancedRankRow> sorted=new ArrayList<>(rows.values());
    for(AdvancedRankRow rr:sorted){double score=0;for(int c=0;c<4;c++)if(denominators[c]>0)score+=(rr.actual[c]/denominators[c])*new double[]{.25,.25,.30,.20}[c]*100.0;rr.score=score;}
    Collections.sort(sorted,(a,b)->Double.compare(b.score,a.score));
    if(sorted.isEmpty()){results.addView(txt("Belum ada laporan Crew pada periode ini.",13,MUTED,false),field());return;}
    int rank=1;for(AdvancedRankRow rr:sorted){int accent=rank==1?0xffd4a900:rank==2?0xff9aa0a8:rank==3?0xffb87333:0xffe5e9ef;int badgeColor=rank==1?0xffc99b00:rank==2?0xff858b94:rank==3?0xffad6b32:MUTED;LinearLayout card=col();card.setBackground(shape(Color.WHITE,rank<=3?accent:0xffe5e9ef,dp(14)));card.setPadding(dp(12),dp(10),dp(12),dp(10));if(rank<=3){View band=new View(this);band.setBackground(shape(accent,0,dp(5)));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(6));bp.bottomMargin=dp(8);card.addView(band,bp);}LinearLayout content=row();content.setGravity(Gravity.CENTER_VERTICAL);LinearLayout emblem=col();emblem.setGravity(Gravity.CENTER);emblem.setMinimumWidth(dp(54));if(rank<=3){int medalBg=rank==1?0xfffff0bd:rank==2?0xffeef1f5:0xffffe7d9;int medalStroke=rank==1?0xffd4a900:rank==2?0xff9aa0a8:0xffb87333;LinearLayout medal=col();medal.setGravity(Gravity.CENTER);medal.setPadding(dp(5),dp(5),dp(5),dp(5));medal.setBackground(shape(medalBg,medalStroke,dp(12)));ImageView trophyIcon=new ImageView(this);trophyIcon.setImageResource(rank==1?R.drawable.rank_trophy_gold:rank==2?R.drawable.rank_trophy_silver:R.drawable.rank_trophy_bronze);trophyIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);LinearLayout.LayoutParams trophyLp=new LinearLayout.LayoutParams(dp(48),dp(48));medal.addView(trophyIcon,trophyLp);TextView medalNo=center("#"+rank,15,Color.WHITE,true);medalNo.setBackground(shape(medalStroke,0,dp(18)));medalNo.setPadding(dp(10),dp(3),dp(10),dp(3));LinearLayout.LayoutParams noLp=lp(-2);noLp.topMargin=dp(2);medal.addView(medalNo,noLp);TextView medalLabel=center(rank==1?"JUARA EMAS":rank==2?"JUARA PERAK":"JUARA PERUNGGU",8,badgeColor,true);LinearLayout.LayoutParams labelLp=lp(-2);labelLp.topMargin=dp(2);medal.addView(medalLabel,labelLp);emblem.addView(medal,new LinearLayout.LayoutParams(dp(50),-2));}else{TextView plainRank=center(String.valueOf(rank),23,MUTED,true);plainRank.setBackground(shape(0xfff3f4f6,0xffe5e9ef,dp(10)));plainRank.setPadding(dp(10),dp(7),dp(10),dp(7));emblem.addView(plainRank,lp(-2));}content.addView(emblem,new LinearLayout.LayoutParams(dp(58),-2));LinearLayout details=col();details.setPadding(dp(10),0,dp(6),0);details.addView(txt(rr.name,14,DARK,true));details.addView(txt("NIK "+rr.nik+"  •  Nilai "+String.format(Locale.US,"%.2f",rr.score)+"%",12,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true));for(int c=0;c<4;c++)details.addView(txt(categories[c]+": "+formatGroupedInteger(rr.actual[c])+" / target "+(denominators[c]>0?formatGroupedInteger(denominators[c]):"belum diatur"),11,MUTED,false));content.addView(details,new LinearLayout.LayoutParams(0,-2,1));TextView pill=center(String.format(Locale.US,"%.2f",rr.score)+"%",14,achievementColor(String.format(Locale.US,"%.2f",rr.score)+"%"),true);pill.setPadding(dp(10),dp(10),dp(10),dp(10));pill.setBackground(shape(rank==1?0xffffedb0:rank==2?0xffedf0f3:rank==3?0xffffe1d2:0xffedf0f4,0,dp(24)));content.addView(pill,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));card.addView(content,lp(-2));results.addView(card,field());rank++;}
  }
  private void showRankingError(LinearLayout results,Exception e){results.removeAllViews();results.addView(txt("Gagal membaca ranking: "+e.getLocalizedMessage(),13,RED,false),field());}

  private void addWorkdays(LinearLayout body,Map<String,EditText> inputs,String key){
    LinearLayout row=row();row.setTag("PLDAYS:"+key);row.setPadding(dp(8),dp(2),dp(8),dp(2));row.addView(txt("Hari kerja periode",11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));
    EditText days=new EditText(this);days.setSingleLine(true);days.setText("");days.setHint("Jumlah hari kerja");days.setInputType(InputType.TYPE_CLASS_NUMBER);days.setEms(5);applyZeroFocusStyle(days);row.addView(days);body.addView(row,field());inputs.put(key+"_DAYS",days);
  }
  private String activePLPeriodKey(DatePicker date){
    Calendar now=Calendar.getInstance();int y=date.getYear(),m=date.getMonth(),day=now.get(Calendar.DAY_OF_MONTH);
    if(y!=now.get(Calendar.YEAR)||m!=now.get(Calendar.MONTH))return "";
    if(day<=7)return "PSM_W1";if(day<=15)return "PSM_W2";if(day<=23)return "PSM_W3";return "PSM_W4";
  }
  private String activePLPeriodForCategory(String category,DatePicker date){
    Calendar now=Calendar.getInstance();if(date.getYear()!=now.get(Calendar.YEAR)||date.getMonth()!=now.get(Calendar.MONTH))return "";
    int day=now.get(Calendar.DAY_OF_MONTH);
    if("PSM".equals(category))return "PSM_W"+(day<=7?1:day<=15?2:day<=23?3:4);
    String suffix=day<=15?"P1":"P2";
    if("PWP".equals(category))return "PWP_"+suffix;
    if("Serba Gratis".equals(category))return "SG_"+suffix;
    return "SUEGER_"+suffix;
  }
  private void loadMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,String targetCode){
    if(db==null||targetCode==null||targetCode.isEmpty())return;String id=targetCode+"_"+monthKey(date);
    db.collection("MonthlyPLTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object v=doc.get(key);if(v!=null)inputs.get(key).setText(cleanNumber(v,false));}}).addOnFailureListener(e->toast("Gagal membaca target PL: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,Button save,String targetCode,String targetName){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS/Admin Utama yang dapat mengatur target.");return;}
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    if(!"admin_utama".equals(currentRole)&&!storeCode.equals(targetCode)){toast("COS/ACOS hanya dapat mengatur toko sendiri.");return;}
    Calendar now=Calendar.getInstance();if(date.getYear()!=now.get(Calendar.YEAR)||date.getMonth()!=now.get(Calendar.MONTH)){toast("Target hanya dapat disiapkan untuk bulan berjalan.");return;}
    int today=now.get(Calendar.DAY_OF_MONTH);int lastDay=now.getActualMaximum(Calendar.DAY_OF_MONTH);
    String[] keys={"PSM_W1","PSM_W2","PSM_W3","PSM_W4","PWP_P1","PWP_P2","SG_P1","SG_P2","SUEGER_P1","SUEGER_P2"};
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",targetCode);data.put("storeName",targetName==null||targetName.trim().isEmpty()?targetCode:targetName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedByRole",currentRole);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    int count=0;
    try{
      for(String key:keys){
        int periodEnd;
        if(key.equals("PSM_W1"))periodEnd=7;else if(key.equals("PSM_W2"))periodEnd=15;else if(key.equals("PSM_W3"))periodEnd=23;else if(key.equals("PSM_W4")||key.endsWith("_P2"))periodEnd=lastDay;else periodEnd=15;
        if(periodEnd<today)continue;
        EditText targetInput=inputs.get(key),daysInput=inputs.get(key+"_DAYS");
        String targetRaw=targetInput==null?"":targetInput.getText().toString().trim();
        String daysRaw=daysInput==null?"":daysInput.getText().toString().trim();
        if(targetRaw.isEmpty()&&daysRaw.isEmpty())continue;
        if(targetRaw.isEmpty()||daysRaw.isEmpty()){toast("Lengkapi target dan hari kerja untuk "+key+".");return;}
        double target=Double.parseDouble(targetRaw),days=Double.parseDouble(daysRaw);
        if(target<0||days<0||target!=Math.rint(target)||days!=Math.rint(days)||Double.isInfinite(target)||Double.isInfinite(days)||Double.isNaN(target)||Double.isNaN(days)){toast("Target dan hari kerja harus bilangan bulat tidak negatif.");return;}
        // Nilai awal 0/0 berarti periode belum disiapkan; lewati tanpa menggagalkan periode lain.
        if(target==0&&days==0)continue;
        if(days<=0){toast("Hari kerja harus lebih dari 0 untuk target "+key+".");return;}
        data.put(key,(long)target);data.put(key+"_DAYS",(long)days);count++;
      }
    }catch(NumberFormatException e){toast("Target dan hari kerja harus berupa angka bulat.");return;}
    if(count==0){toast("Isi minimal satu pasangan target dan hari kerja pada periode aktif atau mendatang.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");
    db.collection("MonthlyPLTargets").document(targetCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target Periode");toast("Target periode berhasil disimpan. Periode yang sudah selesai tetap terkunci.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target Periode");toast("Gagal menyimpan target PL: "+e.getLocalizedMessage());});
  }

  private String roleLabel(){if("cos".equals(currentRole))return "COS";if("acos".equals(currentRole))return "ACOS";if("crew".equals(currentRole))return "Crew";return "Admin Utama";}
  private void cardTitle(LinearLayout p,String s){TextView t=txt(s,16,DARK,true);t.setPadding(0,dp(16),0,dp(9));p.addView(t,lp(-2));}
  private View metricBox(String title,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe4e4e4,dp(10)));c.setPadding(dp(6),dp(12),dp(6),dp(12));c.addView(center(title,10,MUTED,false));c.addView(center(value,16,GREEN,true));return c;}
  private View metric(LinearLayout p,String title,String sub,String val,boolean unused){LinearLayout c=col();c.setBackground(shape(0xfffff5dc,0xffeadcae,dp(12)));c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(txt(title,14,DARK,true));c.addView(txt(sub+"  "+val,14,GREEN,true));p.addView(c,lp(-2));return c;}

  // Khusus Pencapaian per Indikator di Beranda Crew. Membaca hanya laporan NIK yang sedang login.
  // Target per Crew mengikuti denominator bulanan yang sama dengan halaman Ranking Crew.
  private void loadCrewIndicatorProgress(LinearLayout body){
    if(db==null||auth==null||auth.getCurrentUser()==null||currentNik==null||currentNik.trim().isEmpty()){
      body.addView(txt("Sesi Crew belum siap untuk membaca pencapaian.",12,RED,false),field());return;
    }
    if(!"24_JAM".equals(storeType)&&!"NORMAL".equals(storeType)){
      body.addView(txt("Jenis toko belum terbaca. Logout-login setelah Admin Utama mengaturnya.",12,RED,false),field());return;
    }
    Calendar now=Calendar.getInstance();
    int y=now.get(Calendar.YEAR),m=now.get(Calendar.MONTH)+1;
    String month=String.format(Locale.US,"%04d%02d",y,m);
    String from=String.format(Locale.US,"%04d%02d01",y,m);
    String to=String.format(Locale.US,"%04d%02d31",y,m);
    TextView loading=txt("Memuat pencapaian indikator bulan berjalan...",12,MUTED,false);body.addView(loading,field());
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()) {
        body.removeView(loading);
        for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);
        body.addView(txt("Target Penawaran Langsung bulan ini belum diatur oleh COS/ACOS.",12,RED,false),field());return;
      }
      Query q=db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode)
        .whereEqualTo("targetNik",currentNik)
        .whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to);
      q.get().addOnSuccessListener(snapshot->{
        body.removeView(loading);
        double[] actuals=new double[4];
        for(DocumentSnapshot doc:snapshot.getDocuments()){
          actuals[0]+=num(doc.get("PSM"));actuals[1]+=num(doc.get("PWP"));
          actuals[2]+=num(doc.get("Serba Gratis"));actuals[3]+=num(doc.get("SUEGER"));
        }
        String[][] periods={{"PSM_W1","PSM_W2","PSM_W3","PSM_W4"},{"PWP_P1","PWP_P2"},{"SG_P1","SG_P2"},{"SUEGER_P1","SUEGER_P2"}};
        double shifts="24_JAM".equals(storeType)?3.0:2.0;
        String[] labels={"PSM","PWP","Serba Gratis","SUEGER"};
        for(int c=0;c<4;c++){
          double crewTarget=0;
          for(String key:periods[c]){
            double target=num(targetDoc.get(key));double days=num(targetDoc.get(key+"_DAYS"));
            if(target>0&&days>0)crewTarget+=target/shifts;
          }
          addPLProgressCard(body,labels[c],crewTarget,actuals[c]);
        }
      }).addOnFailureListener(e->{
        body.removeView(loading);
        body.addView(txt("Gagal membaca pencapaian Crew: "+e.getLocalizedMessage(),12,RED,false),field());
      });
    }).addOnFailureListener(e->{
      body.removeView(loading);
      body.addView(txt("Gagal membaca target PL: "+e.getLocalizedMessage(),12,RED,false),field());
    });
  }

  // Khusus kartu Progress Indikator PL Toko pada Dashboard; tidak mengubah bagian dashboard lain.
  private void loadPLStoreProgress(LinearLayout body){
    if(db==null||storeCode==null||storeCode.isEmpty()){
      for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);
      return;
    }
    Calendar now=Calendar.getInstance();
    int y=now.get(Calendar.YEAR),m=now.get(Calendar.MONTH)+1,last=now.getActualMaximum(Calendar.DAY_OF_MONTH);
    String month=String.format(Locale.US,"%04d%02d",y,m);
    String from=String.format(Locale.US,"%04d%02d01",y,m);
    String to=String.format(Locale.US,"%04d%02d%02d",y,m,last);
    db.collection("MonthlyPLTargets").document(storeCode+"_"+month).get().addOnSuccessListener(targetDoc->{
      final double[] targets=new double[4];
      if(targetDoc.exists()){
        targets[0]=num(targetDoc.get("PSM_W1"))+num(targetDoc.get("PSM_W2"))+num(targetDoc.get("PSM_W3"))+num(targetDoc.get("PSM_W4"));
        targets[1]=num(targetDoc.get("PWP_P1"))+num(targetDoc.get("PWP_P2"));
        targets[2]=num(targetDoc.get("SG_P1"))+num(targetDoc.get("SG_P2"));
        targets[3]=num(targetDoc.get("SUEGER_P1"))+num(targetDoc.get("SUEGER_P2"));
      }
      db.collection("DailyPLReports").whereEqualTo("storeCode",storeCode)
        .whereGreaterThanOrEqualTo("dateKey",from).whereLessThanOrEqualTo("dateKey",to)
        .get().addOnSuccessListener(snapshot->{
          double[] actuals=new double[4];
          for(DocumentSnapshot doc:snapshot.getDocuments()){
            actuals[0]+=num(doc.get("PSM"));actuals[1]+=num(doc.get("PWP"));
            actuals[2]+=num(doc.get("Serba Gratis"));actuals[3]+=num(doc.get("SUEGER"));
          }
          String[] labels={"PSM","PWP","Serba Gratis","SUEGER"};
          for(int i=0;i<4;i++)addPLProgressCard(body,labels[i],targets[i],actuals[i]);
          double[] weights={.25,.25,.30,.20};double weighted=0;boolean any=false;
          for(int i=0;i<4;i++){if(targets[i]>0){weighted+=Math.min(100,actuals[i]/targets[i]*100)*weights[i];any=true;}}
          LinearLayout total=row();total.setGravity(Gravity.CENTER_VERTICAL);total.setPadding(dp(13),dp(12),dp(13),dp(12));
          total.setBackground(shape(0xfffff1f1,0xffffb8bd,dp(16)));
          total.addView(txt("◎  Total Pencapaian PL Toko",14,0xffbd171f,true),new LinearLayout.LayoutParams(0,-2,1));
          total.addView(txt(any?String.format(Locale.US,"%.2f%%",weighted):"--",18,any?plAchievementColor(weighted):MUTED,true));
          LinearLayout.LayoutParams totalLp=lp(-2);totalLp.bottomMargin=dp(8);body.addView(total,totalLp);
        }).addOnFailureListener(e->{for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);});
    }).addOnFailureListener(e->{for(String n:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})addPLProgressCard(body,n,0,0);});
  }
  private int plAchievementColor(double percent){
    if(percent<=50.0)return 0xffc62828;
    if(percent<80.0)return 0xffffb300;
    return 0xff18864b;
  }
  private void addPLProgressCard(LinearLayout parent,String name,double target,double actual){
    boolean ready=target>0;double percent=ready?actual/target*100.0:0;
    int color=ready?plAchievementColor(percent):MUTED;
    LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(17)));card.setElevation(dp(2));
    card.setPadding(dp(14),dp(13),dp(14),dp(13));
    LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
    TextView title=txt(name,17,DARK,true);top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
    TextView value=txt(ready?String.format(Locale.US,"%.2f%%",percent):"--",19,color,true);top.addView(value);
    card.addView(top);
    TextView targetLine=txt("Target : "+(ready?formatGroupedInteger(target):"Belum diatur"),12,DARK,false);
    targetLine.setPadding(0,dp(4),0,0);card.addView(targetLine);
    TextView actualLine=txt("Aktual : "+formatGroupedInteger(actual),12,DARK,false);card.addView(actualLine);
    TextView status=txt(ready?(percent>=100?"✓ Tercapai":"Dalam Progres"):"Belum ada data target",12,color,true);
    status.setPadding(0,dp(5),0,dp(8));card.addView(status);
    ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);
    bar.setProgress(ready?(int)Math.max(0,Math.min(100,Math.round(percent))):0);
    bar.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
    bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffe5e5e5));
    card.addView(bar,lp(8));
    LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(9);parent.addView(card,q);
  }

  private void progressRow(LinearLayout p,String name,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(15)));c.setElevation(dp(1));c.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout top=row();top.addView(txt(name,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(txt("—",13,MUTED,true));c.addView(top);TextView sub=txt(value,11,MUTED,false);sub.setPadding(0,dp(4),0,dp(8));c.addView(sub);ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffedf0f4));c.addView(bar,lp(7));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(8);p.addView(c,q);}
  private void detail(LinearLayout p,String k,String v){LinearLayout r=row();r.setPadding(dp(10),dp(13),dp(10),dp(13));r.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(14)));r.addView(txt(k,13,DARK,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,DARK,true));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(5);p.addView(r,q);}
  private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setTextColor(RED);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));return b;}
  private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));b.setMinHeight(dp(48));return b;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(auth!=null&&auth.getCurrentUser()!=null){showDashboard("Beranda");}else showLogin();}
}
