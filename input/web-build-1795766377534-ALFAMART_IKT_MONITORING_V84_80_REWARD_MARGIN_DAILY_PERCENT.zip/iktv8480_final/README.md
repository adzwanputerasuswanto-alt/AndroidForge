# ALFAMART IKT MONITORING - starter source

## Login implementation in this revision
- Admin Utama: Firebase Authentication Email/Password, then profile validation in `Users/AdminUtama` (`isActive=true`, `role=admin_utama`).
- Personnel: NIK (8 digits) + PIN (6 digits). The app maps NIK to the Firebase Auth email alias `<NIK>@ikt-monitoring.app`, signs in with Firebase Authentication, then reads `Users/<NIK>` and checks `isActive=true` and a non-admin role.
- PIN/password is authenticated by Firebase Authentication; this code does not write PIN values to Firestore.

## Required setup before personnel login can work
1. In Firebase Authentication, create one Email/Password account for each personnel member. Use the email alias `<NIK>@ikt-monitoring.app` and set the initial password to that person's 6-digit PIN.
2. The Firestore `Users` collection must contain a document whose document ID is that person's 8-digit NIK. It must contain `isActive: true` and a valid non-`admin_utama` `role`. The `name` field is optional.
3. Update Firestore Security Rules to permit each authenticated personnel account to read only its own `Users/<NIK>` profile. The current project rules were admin-only and will block personnel profile reads until deliberately updated. Do not open the database to public access.
4. For Admin Utama, keep the existing separate Firebase Auth email/password account and the `Users/AdminUtama` profile. Its `email`, `role: admin_utama`, and `isActive: true` must match.

## Important security note
A six-digit PIN has low entropy. Firebase Authentication password protection and sign-in throttling help, but this is a Spark-plan compromise rather than the stronger server-side NIK/PIN verification with rate limiting that could be implemented using a trusted backend. Never store PINs in Firestore or expose an unrestricted database rule.

## Build
Open this project in Android Studio / AndroidForge with the matching `google-services.json`, then build the APK. This environment did not have Gradle installed, so this source revision has not been compiled into an APK here.


## V2 — penyesuaian referensi visual
- Memakai aset logo Alfamart asli yang diberikan pengguna (bukan teks/logo tiruan).
- Mempertahankan login Personil Toko dan Admin Utama terpisah.
- Kerangka dashboard COS/ACOS/Crew dan halaman input, ranking, reward, profil, laporan mengikuti susunan referensi.
- Pendaftaran mandiri masih berupa rancangan UI; validasi kode aktivasi dan penyimpanan data belum aktif.
- Angka pada dashboard tetap placeholder sampai skema data operasional dan sinkronisasi Firestore diimplementasikan.

## V6 COS/ACOS Input Menus
V6 adds explicit COS/ACOS shortcuts and navigation for monthly IKT target input, store input, and direct-offer Crew input. See `CHANGELOG_V6_COS_ACOS_MENU.txt` and `FIRESTORE_SCHEMA_V6.txt` for behavior and security requirements.


## V12 - format Rupiah dan foto profil
- Net Sales, NSB, dan APC diformat sebagai nominal Rupiah dengan pemisah ribuan titik tanpa desimal. STD tetap bilangan bulat dan Margin tetap dua desimal dengan koma dan tanda persen.
- Foto profil dapat dipilih dari galeri, dipotong persegi 1:1, lalu diunggah ke Firebase Storage, dan URL-nya disimpan di field `profilePhotoUrl` pada dokumen `Users`.
- Sebelum menguji foto, aktifkan Firebase Storage, terapkan `FIREBASE_STORAGE_RULES_V12.txt`, dan gabungkan patch terbatas pada `profilePhotoUrl` dari `FIRESTORE_RULES_PATCH_V12.txt` ke aturan `Users` yang sudah ada. Jangan membuka database secara publik.
- Firebase Storage mungkin memerlukan penyesuaian paket/billing sesuai status bucket/project.
- Source belum dikompilasi menjadi APK di lingkungan ini; lakukan Build dan uji di AndroidForge.


## V15 - Input Penjualan Harian dan Indikator IKT
Lihat `CHANGELOG_V15_INPUT_PENJUALAN_HARIAN.txt`. Form Input Toko mencakup lima indikator IKT, validasi nilai, konfirmasi sebelum simpan, pemuatan berdasarkan tanggal, dan jejak koreksi pada `DailyStoreReports/{storeCode_date}/EditHistory`. Build dan uji Firestore Rules tetap wajib dilakukan sebelum dipakai.


## V16 - Dashboard IKT Otomatis
Lihat `CHANGELOG_V16_DASHBOARD_IKT_OTOMATIS.txt`. Dashboard membaca target bulanan dan dokumen input harian per tanggal, menampilkan akumulasi Net Sales, rata-rata Margin, rasio NSB, serta status IKT. Build dan uji AndroidForge/Firestore Rules wajib dilakukan sebelum digunakan.


## V21 - Target Penawaran Langsung Bertahap
Lihat `CHANGELOG_V21_TARGET_BERTAHAP.txt`. Form target hanya membuka periode aktif; Admin Utama dapat memilih toko, sedangkan COS/ACOS tetap dibatasi ke toko aktifnya. Tidak ada perubahan Firestore Security Rules. Source belum dikompilasi menjadi APK.


## V22 - Semua Periode Target PL dan Kode Toko Manual
- Semua periode PSM (W1-W4), PWP, Serba Gratis, dan SUEGER (P1-P2) selalu ditampilkan pada form.
- Admin Utama cukup memasukkan kode toko; tidak perlu membaca dokumen master Stores untuk memuat atau menyimpan target. Nama toko pada dokumen target menggunakan kode toko bila nama tidak tersedia.
- Target dan hari kerja dapat disiapkan untuk periode aktif maupun periode mendatang pada bulan berjalan.
- Input periode yang sudah selesai dinonaktifkan dan penyimpanan melewati periode yang sudah selesai agar riwayat tidak tertimpa.
- Tidak ada perubahan pada Firebase Authentication maupun Firestore Security Rules.
- Belum dikompilasi menjadi APK di lingkungan ini; build dan uji tetap perlu dilakukan di Android Studio/AndroidForge.


## V23 - Validasi target dan ranking bulanan
Lihat `CHANGELOG_V23_FIX_TARGET_RANKING.txt`. Error izin baca `MonthlyPLTargets` tetap memerlukan penyesuaian Firestore Rules aktif secara terbatas untuk personil di toko sendiri dan Admin Utama.


## V84.79 — Reward IKT Margin Rupiah and State Fix
Lihat `CHANGELOG_V84_79_REWARD_MARGIN_RUPIAH_AND_STATE_FIX.txt`. Perhitungan Margin Rupiah mengikuti rumus Target Net Sales x Target Margin (%) dan Aktual Net Sales x Aktual Margin (%), lalu kebutuhan Margin per hari dibagi sisa hari. Kategori hanya ditampilkan jika Net Sales dan Margin sama-sama minimal 100%; final gagal memakai judul GAGAL MENANG IKT. APK belum dikompilasi di lingkungan ini.
