package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
  private static final int RED=Color.rgb(196,0,35), BLUE=Color.rgb(20,75,130), DARK=Color.rgb(29,37,51), MUTED=Color.rgb(111,121,136), BG=Color.rgb(246,247,250), GREEN=Color.rgb(24,132,83), SOFT_RED=Color.rgb(255,241,244);
  private static final String AUTH_DOMAIN="@ikt-monitoring.app";
  private FirebaseAuth auth; private FirebaseFirestore db;
  private boolean adminMode=false, loading=false;
  private EditText identityInput,passwordInput; private Button loginButton;
  private String currentName="", currentRole="", currentNik="", storeCode="K876", storeName="RC Veteran 2";
  private LinearLayout root;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(RED);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();}catch(Exception e){toast("Firebase belum siap: "+e.getMessage());} showLogin();}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(Math.max(radius,dp(14)));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private LinearLayout.LayoutParams lp(int h){return new LinearLayout.LayoutParams(-1,h<0?h:dp(h));}
  private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1);}
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  private TextView center(String s,int size,int color,boolean bold){TextView t=txt(s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
  private void showLogin(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);root=col();root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(BG);sc.addView(root);root.setPadding(dp(20),dp(26),dp(20),dp(22));
    LinearLayout hero=col();hero.setGravity(Gravity.CENTER);hero.setBackground(shape(RED,0,dp(22)));hero.setPadding(dp(18),dp(30),dp(18),dp(28));hero.setElevation(dp(5));
    ImageView logo=new ImageView(this); logo.setImageResource(com.adzwan.iktalfamartmonitoring.R.drawable.alfamart_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(150),dp(58)); hero.addView(logo,logoParams);TextView title=center("IKT Alfamart Monitoring",21,Color.WHITE,true);title.setPadding(0,dp(12),0,0);hero.addView(title,lp(-2));root.addView(hero,lp(-2));
    LinearLayout modes=row();modes.setPadding(0,dp(20),0,dp(8));Button p=modeButton("Personil Toko",!adminMode),a=modeButton("Admin Utama",adminMode);modes.addView(p,weight());modes.addView(a,weight());root.addView(modes,lp(-2));
    TextView info=center(adminMode?"LOGIN ADMIN UTAMA":"LOGIN PERSONIL TOKO",17,DARK,true);info.setPadding(0,dp(7),0,dp(8));root.addView(info,lp(-2));
    identityInput=new EditText(this);identityInput.setSingleLine(true);identityInput.setTextSize(15);identityInput.setMaxWidth(dp(420));identityInput.setPadding(dp(15),dp(12),dp(15),dp(12));identityInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));identityInput.setHint(adminMode?"Email Admin Utama":"NIK (8 angka)");identityInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:InputType.TYPE_CLASS_NUMBER);root.addView(identityInput,field());
    passwordInput=new EditText(this);passwordInput.setSingleLine(true);passwordInput.setTextSize(15);passwordInput.setMaxWidth(dp(420));passwordInput.setPadding(dp(15),dp(12),dp(15),dp(12));passwordInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));passwordInput.setHint(adminMode?"Password":"PIN (6 digit)");passwordInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(passwordInput,field());
    loginButton=new Button(this);loginButton.setText("Login");loginButton.setTextColor(Color.WHITE);loginButton.setAllCaps(false);loginButton.setTextSize(16);loginButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));root.addView(loginButton,field());
    TextView note=center(adminMode?"Admin Utama\nLogin menggunakan email dan password.":"Personil Toko: COS, ACOS, dan Crew\nLogin menggunakan NIK dan PIN.",12,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(12)));note.setPadding(dp(12),dp(14),dp(12),dp(14));root.addView(note,field());
    if(!adminMode){ TextView signup=center("Belum punya akun?  Daftar Akun Baru",14,BLUE,true); signup.setPadding(0,dp(12),0,dp(12)); signup.setClickable(true); signup.setOnClickListener(v->showRegister()); root.addView(signup,lp(-2)); }
    TextView credit=center("Design by Adzwan Putera Suswanto",11,MUTED,false); credit.setPadding(0,dp(10),0,dp(6)); root.addView(credit,lp(-2));
    p.setOnClickListener(v->{adminMode=false;showLogin();});a.setOnClickListener(v->{adminMode=true;showLogin();});loginButton.setOnClickListener(v->doLogin());setContentView(sc);
  }
  private void showRegister(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout page=col();page.setGravity(Gravity.CENTER_HORIZONTAL);page.setPadding(dp(22),dp(22),dp(22),dp(22));page.setBackgroundColor(BG);sc.addView(page);
    TextView title=center("DAFTAR AKUN PERSONIL",22,DARK,true);title.setPadding(0,dp(16),0,dp(8));page.addView(title,lp(-2));
    TextView desc=center("Pendaftaran mandiri menggunakan NIK dan kode aktivasi sekali pakai.",13,MUTED,false);page.addView(desc,lp(-2));
    EditText nik=registerField(page,"NIK (8 angka)",InputType.TYPE_CLASS_NUMBER);
    EditText activation=registerField(page,"Kode aktivasi",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
    EditText pin=registerField(page,"Buat PIN (6 digit)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    EditText confirm=registerField(page,"Ulangi PIN",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    Button submit=primary("Verifikasi & Daftar");page.addView(submit,field());
    TextView info=txt("Pendaftaran belum diaktifkan. Validasi kode aktivasi harus disiapkan melalui mekanisme server tepercaya agar kode tidak dapat dipalsukan.",12,BLUE,false);info.setBackground(shape(0xffe8f0fc,0,dp(12)));info.setPadding(dp(12),dp(12),dp(12),dp(12));page.addView(info,field());
    TextView back=center("Kembali ke Login",14,BLUE,true);back.setPadding(0,dp(12),0,dp(12));page.addView(back,lp(-2));back.setOnClickListener(v->showLogin());
    submit.setOnClickListener(v->{String n=nik.getText().toString().trim(),a=activation.getText().toString().trim(),p=pin.getText().toString(),c=confirm.getText().toString();if(!n.matches("\\d{8}")||a.isEmpty()||!p.matches("\\d{6}")||!p.equals(c)){toast("Periksa NIK, kode aktivasi, dan PIN.");return;}toast("Form sudah lengkap. Aktivasi server belum dikonfigurasi; akun belum dibuat.");});setContentView(sc);
  }
  private EditText registerField(LinearLayout parent,String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setInputType(type);e.setPadding(dp(17),dp(14),dp(17),dp(14));e.setBackground(shape(Color.WHITE,0xffe4e8ef,dp(16)));parent.addView(e,field());return e;}
  private Button modeButton(String s,boolean selected){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(selected?Color.WHITE:DARK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(selected?RED:Color.WHITE));return b;}
  private LinearLayout.LayoutParams field(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(10);return p;}
  private void doLogin(){if(auth==null||db==null){toast("Firebase belum siap.");return;}String id=identityInput.getText().toString().trim(),pw=passwordInput.getText().toString().trim();if(adminMode){if(id.isEmpty()||pw.isEmpty()){toast("Masukkan email dan password.");return;}signIn(id,pw,true,null);}else{if(!id.matches("\\d{8}")||!pw.matches("\\d{6}")){toast("NIK harus 8 angka dan PIN harus 6 digit.");return;}signIn(id+AUTH_DOMAIN,pw,false,id);}}
  private void signIn(String email,String password,boolean admin,String nik){loginButton.setEnabled(false);loginButton.setText("Memeriksa...");auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,task->{if(!task.isSuccessful()){restoreLogin();toast("Login gagal. Periksa NIK/email dan PIN/password.");return;}String doc=admin?"AdminUtama":nik;db.collection("Users").document(doc).get().addOnCompleteListener(this,r->{restoreLogin();if(!r.isSuccessful()||!r.getResult().exists()){auth.signOut();toast("Profil pengguna tidak ditemukan.");return;}DocumentSnapshot d=r.getResult();String role=d.getString("role"),registered=d.getString("email");boolean valid=Boolean.TRUE.equals(d.getBoolean("isActive"))&&(admin?"admin_utama".equals(role):(role!=null&&!"admin_utama".equals(role)&&nik.equals(d.getString("nik"))));if(admin&&registered!=null&&!registered.equalsIgnoreCase(email))valid=false;if(!valid){auth.signOut();toast("Akun tidak aktif atau hak akses tidak sesuai.");return;}currentName=d.getString("name")==null?"Personil":d.getString("name");currentRole=role;currentNik=admin?"":nik;storeCode=d.getString("storeCode")==null?"K876":d.getString("storeCode");storeName=d.getString("storeName")==null?"RC Veteran 2":d.getString("storeName");showDashboard("Beranda");});});}
  private void restoreLogin(){if(loginButton!=null){loginButton.setEnabled(true);loginButton.setText("Login");}}
  private void showDashboard(String page){
    LinearLayout shell=col(); shell.setBackgroundColor(BG);
    LinearLayout header=row(); header.setBackgroundColor(RED); header.setPadding(dp(16),dp(12),dp(16),dp(12));
    TextView menu=txt("☰",24,Color.WHITE,true); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(8),dp(4),dp(8),dp(4)); menu.setContentDescription("Buka menu"); menu.setClickable(true); menu.setFocusable(true); header.addView(menu);
    menu.setOnClickListener(v->{ PopupMenu popup=new PopupMenu(MainActivity.this,menu); String[] entries=menuEntries(); for(String entry:entries) popup.getMenu().add(entry); popup.setOnMenuItemClickListener(item->{String choice=item.getTitle().toString(); if("Keluar".equals(choice)){if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();}else if("Input PL Crew".equals(choice)){showDashboard("Input PL Crew");}else{showDashboard(choice);} return true;}); popup.show();});
    TextView brand=txt("IKT Alfamart",18,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(14);header.addView(brand,bp);
    TextView bell=txt("♧",22,Color.WHITE,true);header.addView(bell);shell.addView(header,lp(-2));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(14));sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout welcome=row();TextView avatar=center("●",25,RED,true);avatar.setBackground(shape(Color.WHITE,0xffdddddd,dp(28)));avatar.setWidth(dp(50));avatar.setHeight(dp(50));welcome.addView(avatar);
    LinearLayout who=col();who.setPadding(dp(10),0,0,0);who.addView(txt("Halo, "+currentName,15,DARK,true));who.addView(txt(roleLabel()+" • Toko "+storeCode,12,MUTED,false));welcome.addView(who,new LinearLayout.LayoutParams(0,-2,1));
    TextView month=txt("Nov 2026  ▣",11,DARK,true);month.setBackground(shape(Color.WHITE,0xffdddddd,dp(8)));month.setPadding(dp(9),dp(8),dp(9),dp(8));welcome.addView(month);body.addView(welcome,lp(-2));

    if(page.equals("Beranda")){
      if("crew".equals(currentRole)){
        cardTitle(body,"Pencapaian Saya (s.d. 20 Nov)");
        LinearLayout trophy=col();trophy.setBackground(shape(0xfffff6df,0xffeadcae,dp(11)));trophy.setPadding(dp(13),dp(12),dp(13),dp(12));
        trophy.addView(txt("🏆  Ranking Gabungan",14,DARK,true));trophy.addView(txt("Menunggu data pencapaian",18,GREEN,true));body.addView(trophy,lp(-2));
        cardTitle(body,"Pencapaian per Indikator");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
        LinearLayout acts=row();Button input=primary("Input PL Hari Ini");Button rank=smallButton("Lihat Ranking");acts.addView(input,weight());acts.addView(rank,weight());body.addView(acts,field());input.setOnClickListener(v->showDashboard("Input PL"));rank.setOnClickListener(v->showDashboard("Ranking Crew"));
      }else{
        cardTitle(body,"Kinerja Toko (s.d. 20 Nov)");
        LinearLayout metrics=col(); String[][] metricData={{"Net Sales","--"},{"Margin","--"},{"NSB","--"},{"Status IKT","--"}}; for(int rowIndex=0;rowIndex<2;rowIndex++){ LinearLayout metricRow=row(); for(int colIndex=0;colIndex<2;colIndex++){String[] m=metricData[rowIndex*2+colIndex]; LinearLayout c=col(); c.setGravity(Gravity.CENTER); c.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(16)));c.setElevation(dp(2)); c.setPadding(dp(10),dp(18),dp(10),dp(18)); c.addView(center(m[0].toUpperCase(),12,MUTED,true)); c.addView(center(m[1],23,GREEN,true)); LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(104),1); q.setMargins(dp(4),dp(4),dp(4),dp(4)); metricRow.addView(c,q);} metrics.addView(metricRow,lp(-2)); } body.addView(metrics,lp(-2));
        LinearLayout actions=row();String[][] acts={{"▣","Input Target IKT"},{"▤","Target Penawaran Langsung"},{"✎","Penawaran Langsung Crew"},{"♛","Ranking Crew"}};
        for(String[] act:acts){String label=act[1];LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setBackground(shape(Color.WHITE,0xffe8eaf0,dp(15)));tile.setElevation(dp(2));tile.setPadding(dp(3),dp(10),dp(3),dp(10));tile.addView(center(act[0],21,RED,true));tile.addView(center(label,10,DARK,true));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(78),1);q.setMargins(dp(3),dp(8),dp(3),dp(8));actions.addView(tile,q);tile.setOnClickListener(v->showDashboard(label.equals("Penawaran Langsung Crew")?"Input PL Crew":label));}body.addView(actions,lp(-2));
        LinearLayout extra=row();String[][] extraActs={{"♜","Reward"},{"▤","Laporan"}};for(String[] act:extraActs){Button b=smallButton(act[1]);extra.addView(b,weight());b.setOnClickListener(v->showDashboard(act[1]));}body.addView(extra,field());
        cardTitle(body,"Progress Indikator PL Toko");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
      }
    }else if(page.equals("Input Target Penawaran Langsung")) {
      cardTitle(body,"Input Target Penawaran Langsung");
      body.addView(txt("Atur target bulanan toko. Setiap indikator memiliki periode pencapaian tersendiri.",12,MUTED,false),field());
      body.addView(txt("Bulan Target",13,DARK,true)); DatePicker targetMonth=new DatePicker(this); targetMonth.setCalendarViewShown(false); targetMonth.setSpinnersShown(true); body.addView(targetMonth,lp(-2));
      Map<String,EditText> plTargets=new HashMap<>();
      addTargetPeriod(body,plTargets,"PSM","Week 1 • Tanggal 1–7","PSM_W1"); addTargetPeriod(body,plTargets,"PSM","Week 2 • Tanggal 8–15","PSM_W2"); addTargetPeriod(body,plTargets,"PSM","Week 3 • Tanggal 16–23","PSM_W3"); addTargetPeriod(body,plTargets,"PSM","Week 4 • Tanggal 24–akhir bulan","PSM_W4");
      addTargetPeriod(body,plTargets,"PWP","Periode 1 • Tanggal 1–15","PWP_P1"); addTargetPeriod(body,plTargets,"PWP","Periode 2 • Tanggal 16–akhir bulan","PWP_P2");
      addTargetPeriod(body,plTargets,"Serba Gratis","Periode 1 • Tanggal 1–15","SG_P1"); addTargetPeriod(body,plTargets,"Serba Gratis","Periode 2 • Tanggal 16–akhir bulan","SG_P2");
      addTargetPeriod(body,plTargets,"SUEGER","Periode 1 • Tanggal 1–15","SUEGER_P1"); addTargetPeriod(body,plTargets,"SUEGER","Periode 2 • Tanggal 16–akhir bulan","SUEGER_P2");
      loadMonthlyPLTargets(targetMonth,plTargets); Button savePLTarget=primary("Simpan Target Penawaran Langsung"); body.addView(savePLTarget,field()); savePLTarget.setOnClickListener(v->saveMonthlyPLTargets(targetMonth,plTargets,savePLTarget));
      TextView plNote=txt("Target tersimpan terpisah dari Target IKT untuk bulan dan toko yang dipilih.",11,BLUE,false); plNote.setBackground(shape(0xffe8f0fc,0,dp(8))); plNote.setPadding(dp(10),dp(10),dp(10),dp(10)); body.addView(plNote,lp(-2));
    }else if(page.equals("Input Target IKT")||page.equals("Input PL")||page.equals("Input PL Crew")||page.equals("Input Toko")){
      boolean target=page.equals("Input Target IKT");boolean pl=page.equals("Input PL")||page.equals("Input PL Crew");
      cardTitle(body,target?"Input Target IKT Bulanan":pl?("crew".equals(currentRole)?"Penawaran Langsung Hari Ini":"Penawaran Langsung Crew") :"Input Data Toko");
      if(target)body.addView(txt("Atur target IKT bulanan toko: Net Sales, Margin %, NSB, APC, dan STD.",12,MUTED,false),field());
      if(pl && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))body.addView(txt("Masukkan NIK Crew yang akan diinput atau diperbarui. Data tersimpan atas nama Crew yang dipilih.",12,MUTED,false),field());
      body.addView(txt(target?"Pilih bulan target":"Tanggal",13,DARK,true));DatePicker date=new DatePicker(this);date.setCalendarViewShown(false);date.setSpinnersShown(true);body.addView(date,lp(-2));
      EditText targetNik=null;
      if(pl&&("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){body.addView(txt("NIK Crew yang diinput (8 angka)",13,DARK,true));targetNik=registerField(body,"Masukkan NIK Crew",InputType.TYPE_CLASS_NUMBER);targetNik.setText(currentNik);}
      String[] labels=target?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:page.equals("Input Toko")?new String[]{"Net Sales","Margin","NSB"}:new String[]{"PSM","PWP","Serba Gratis","SUEGER"};
      Map<String,EditText> inputs=new HashMap<>();
      for(String key:labels){LinearLayout r=row();r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));r.addView(txt(key,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));if(isRupiahMetric(key))r.addView(txt("Rp",12,MUTED,true));else if(isDecimalMetric(key))r.addView(txt("%",12,MUTED,true));EditText val=new EditText(this);configureMetricInput(val,key);val.setText("0");val.setEms(5);applyZeroFocusStyle(val);r.addView(val);inputs.put(key,val);LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);body.addView(r,q);}
      final EditText selectedCrewNik=targetNik;
      if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);
      Button save=primary(target?"Simpan Target": "Simpan");body.addView(save,field());save.setOnClickListener(v->{if(target)saveMonthlyTarget(date,inputs,save);else saveDailyInput(page,date,inputs,save,selectedCrewNik);});
      TextView note=txt(target?"Target berlaku untuk toko dan bulan yang dipilih.":"Data Penawaran Langsung dapat diperbarui pada hari yang sama maksimal pukul 23.59.",11,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(8)));note.setPadding(dp(10),dp(10),dp(10),dp(10));body.addView(note,lp(-2));
    }else if(page.equals("Ranking Crew")){
      cardTitle(body,"Ranking Crew");LinearLayout tabs=row();tabs.addView(smallButton("Harian"),weight());tabs.addView(primary("Bulanan"),weight());body.addView(tabs,field());
      for(int i=1;i<=5;i++)progressRow(body,i+". Personil Crew","Menunggu data pencapaian");
    }else if(page.equals("Reward")){
      cardTitle(body,"Reward IKT");LinearLayout trophy=col();trophy.setBackground(shape(0xfff0f8e9,0xffd4e8c8,dp(10)));trophy.setPadding(dp(14),dp(14),dp(14),dp(14));trophy.addView(center("🏆",28,GREEN,true));trophy.addView(center("Status IKT Toko",14,DARK,true));trophy.addView(center("Menunggu data kinerja",18,GREEN,true));body.addView(trophy,lp(-2));
      cardTitle(body,"Kategori Reward");progressRow(body,"Kategori A","Menunggu pencapaian Net Sales");progressRow(body,"Penerima","Data reward belum tersedia");
    }else if(page.equals("Profil")){
      cardTitle(body,"Profil Personil");TextView profileAvatar=center("＋",30,RED,true);profileAvatar.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(60)));LinearLayout.LayoutParams avatarLp=new LinearLayout.LayoutParams(dp(112),dp(112));avatarLp.gravity=Gravity.CENTER_HORIZONTAL;body.addView(profileAvatar,avatarLp);profileAvatar.setOnClickListener(v->toast("Pemilihan foto profil akan diaktifkan pada integrasi penyimpanan foto."));TextView name=center(currentName,18,DARK,true);body.addView(name,lp(-2));for(String[] x:new String[][]{{"NIK",currentNik.isEmpty()?"Admin Utama":currentNik},{"Username",currentNik},{"Jabatan",roleLabel()},{"Kode Toko",storeCode},{"Nama Toko",storeName}})detail(body,x[0],x[1]);
      Button out=smallButton("Keluar");body.addView(out,field());out.setOnClickListener(v->{if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();});
    }else if(page.equals("Laporan")){
      cardTitle(body,"Laporan");progressRow(body,"Rekap Kinerja Toko","Net Sales, Margin, NSB, Status IKT");progressRow(body,"Rekap Penawaran Langsung","PSM, PWP, Serba Gratis, SUEGER");progressRow(body,"Ranking Crew","Peringkat dan pencapaian");cardTitle(body,"Ekspor Laporan");LinearLayout ex=row();ex.addView(smallButton("Excel (.xlsx)"),weight());ex.addView(smallButton("PDF (.pdf)"),weight());body.addView(ex,lp(-2));
    }else{
      cardTitle(body,page);body.addView(txt("Halaman ini disiapkan mengikuti desain referensi. Data dan fungsi operasional akan dihubungkan bertahap.",14,MUTED,false));
    }
    LinearLayout nav=row(); nav.setBackground(shape(Color.WHITE,0xffedf0f5,dp(18))); nav.setElevation(dp(10)); nav.setPadding(dp(2),dp(4),dp(2),dp(8)); String[][] tabs={{"⌂","Beranda"},{"✎","Input PL"},{"♛","Ranking Crew"},{"▤","Laporan"},{"♙","Profil"}}; for(String[] tab:tabs){String t=tab[1]; LinearLayout item=col(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2),dp(5),dp(2),dp(5)); item.setClickable(true); item.setFocusable(true); item.setBackgroundResource(android.R.drawable.list_selector_background); TextView ico=center(tab[0],18,t.equals(page)?RED:MUTED,true); TextView label=center(t,9,t.equals(page)?RED:MUTED,true); item.addView(ico,lp(-2)); item.addView(label,lp(-2)); nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1)); item.setOnClickListener(v->showDashboard(("Input PL".equals(t) && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))?"Input PL Crew":t)); } shell.addView(nav,lp(-2)); setContentView(shell);
  }

  private String selectedDate(DatePicker date){Calendar c=Calendar.getInstance();c.set(date.getYear(),date.getMonth(),date.getDayOfMonth(),0,0,0);c.set(Calendar.MILLISECOND,0);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
  private String selectedDateKey(DatePicker date){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(date.getYear()-1900,date.getMonth(),date.getDayOfMonth()));}
  private boolean canEditToday(DatePicker date){Calendar now=Calendar.getInstance();return date.getYear()==now.get(Calendar.YEAR)&&date.getMonth()==now.get(Calendar.MONTH)&&date.getDayOfMonth()==now.get(Calendar.DAY_OF_MONTH)&&now.get(Calendar.HOUR_OF_DAY)<24;}
  private void loadDailyInput(String page,DatePicker date,Map<String,EditText> inputs,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null)return;
    boolean store=page.equals("Input Toko");String day=selectedDateKey(date);String targetNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();if(!store&&!targetNik.matches("\\d{8}"))return;String id=store?storeCode+"_"+day:targetNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    db.collection(collection).document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):cleanNumber(value,false));}}).addOnFailureListener(e->toast("Gagal membaca data: "+e.getLocalizedMessage()));
  }
  private void saveDailyInput(String page,DatePicker date,Map<String,EditText> inputs,Button save,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    if(!canEditToday(date)){toast("Data hanya dapat diinput atau diperbarui pada tanggal hari ini.");return;}
    boolean store=page.equals("Input Toko");
    boolean elevated="cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole);
    if(store&&!elevated){toast("Hanya COS/ACOS yang dapat menginput data toko.");return;}
    if(!store&&!("crew".equals(currentRole)||elevated)){toast("Jabatan ini tidak memiliki akses input PL.");return;}
    String selectedNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();if(!selectedNik.matches("\\d{8}")){toast("NIK Crew harus 8 angka.");return;}if(!elevated&&!selectedNik.equals(currentNik)){toast("Crew hanya dapat menginput data miliknya sendiri.");return;}
    String dateText=selectedDate(date),day=selectedDateKey(date);String id=store?storeCode+"_"+day:selectedNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    Map<String,Object> data=new HashMap<>();data.put("date",dateText);data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("ownerNik",currentNik);data.put("ownerName",currentName);data.put("ownerRole",currentRole);if(!store){data.put("targetNik",selectedNik);data.put("targetName",selectedNik.equals(currentNik)?currentName:"Crew "+selectedNik);}data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","").replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Nilai "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException ex){toast("Pastikan semua nilai berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection(collection).document(id).set(data,SetOptions.merge()).addOnSuccessListener(unused->{save.setEnabled(true);save.setText("Simpan");for(String key:inputs.keySet())if(isDecimalMetric(key))inputs.get(key).setText(formatMargin(data.get(key)));toast("Data berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal menyimpan. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }

  private String[] menuEntries(){
    if("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))return new String[]{"Beranda","Input Target IKT","Input Target Penawaran Langsung","Input Toko","Input PL Crew","Ranking Crew","Reward","Laporan","Profil","Keluar"};
    return new String[]{"Beranda","Input PL","Ranking Crew","Laporan","Profil","Keluar"};
  }
  private String monthKey(DatePicker date){return String.format(Locale.US,"%04d%02d",date.getYear(),date.getMonth()+1);}
  // Tampilan angka tidak mengubah nilai numerik yang disimpan di Firestore.
  private String cleanNumber(Object value, boolean decimalAllowed){
    if(value==null)return "0";
    try{
      double n=Double.parseDouble(String.valueOf(value).replace(",","."));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0";
      if(!decimalAllowed || n==Math.rint(n))return String.format(Locale.US,"%.0f",n);
      return String.format(Locale.US,"%s",new java.math.BigDecimal(String.valueOf(n)).stripTrailingZeros().toPlainString());
    }catch(Exception e){return String.valueOf(value);}
  }
  // Margin disimpan sebagai angka (mis. 12.52), tetapi selalu ditampilkan 2 desimal dengan koma dan %.
  private String formatMargin(Object value){
    try{
      double n=Double.parseDouble(String.valueOf(value).trim().replace("%","").replace(',','.'));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0,00%";
      return String.format(new Locale("id","ID"),"%.2f%%",n);
    }catch(Exception e){return "0,00%";}
  }
  private void configureMetricInput(EditText input,String key){
    if(isDecimalMetric(key)){
      input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
      input.setKeyListener(DigitsKeyListener.getInstance("0123456789,.%"));
      input.setHint("0,0 %");
    }else{
      input.setInputType(InputType.TYPE_CLASS_NUMBER);
      input.setKeyListener(DigitsKeyListener.getInstance("0123456789"));
    }
  }
  private void applyZeroFocusStyle(EditText input){
    input.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
    input.setOnFocusChangeListener((v,focused)->{
      String raw=input.getText().toString().trim().replace(",",".");
      boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
      input.setTypeface(Typeface.create("sans-serif",focused&&zero?Typeface.BOLD:Typeface.NORMAL));
    });
    input.addTextChangedListener(new TextWatcher(){
      boolean fixing=false;
      public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){
        if(input.hasFocus()){
          String raw=s.toString().trim().replace(",",".").replace("%","");
          boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
          input.setTypeface(Typeface.create("sans-serif",zero?Typeface.BOLD:Typeface.NORMAL));
        }
      }
      public void afterTextChanged(Editable e){
        if(fixing||!input.hasFocus()||e.length()<=1)return;
        if(e.charAt(0)=='0' && Character.isDigit(e.charAt(1))){fixing=true;e.delete(0,1);fixing=false;}
      }
    });
  }
  private boolean isDecimalMetric(String key){return key!=null&&key.toLowerCase(Locale.ROOT).contains("margin");}
  private boolean isRupiahMetric(String key){return key!=null&&(key.equalsIgnoreCase("Net Sales")||key.equalsIgnoreCase("NSB")||key.equalsIgnoreCase("netSales")||key.equalsIgnoreCase("nsb"));}
  private String formatRupiah(Object value){return "Rp "+String.format(Locale.US,"%,.0f",Double.parseDouble(cleanNumber(value,false))).replace(',','.');}
  private void loadMonthlyTarget(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return;String id=storeCode+"_"+monthKey(date);db.collection("MonthlyIKTTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):cleanNumber(value,false));}}).addOnFailureListener(e->toast("Gagal membaca target: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyTarget(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target IKT.");return;}if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","").replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyIKTTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target");for(String key:inputs.keySet())if(isDecimalMetric(key))inputs.get(key).setText(formatMargin(data.get(key)));toast("Target IKT bulanan berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target");toast("Gagal menyimpan target. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }
  private void addTargetPeriod(LinearLayout body,Map<String,EditText> inputs,String category,String period,String key){
    LinearLayout card=col(); card.setBackground(shape(Color.WHITE,0xffe5e9ef,dp(13))); card.setPadding(dp(12),dp(10),dp(12),dp(10));
    card.addView(txt(category+"  •  "+period,13,DARK,true)); EditText value=new EditText(this); value.setSingleLine(true); value.setText("0"); value.setHint("Masukkan target"); value.setInputType(InputType.TYPE_CLASS_NUMBER); applyZeroFocusStyle(value); card.addView(value,lp(-2));
    LinearLayout.LayoutParams q=lp(-2); q.bottomMargin=dp(7); body.addView(card,q); inputs.put(key,value);
  }
  private void loadMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return; String id=storeCode+"_"+monthKey(date); db.collection("MonthlyPLTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object v=doc.get(key);if(v!=null)inputs.get(key).setText(cleanNumber(v,false));}}).addOnFailureListener(e->toast("Gagal membaca target PL: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target toko.");return;} if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>(); data.put("month",monthKey(date)); data.put("storeCode",storeCode); data.put("storeName",storeName); data.put("updatedByNik",currentNik); data.put("updatedByName",currentName); data.put("updatedByRole",currentRole); data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","").replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyPLTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target Penawaran Langsung");toast("Target Penawaran Langsung berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target Penawaran Langsung");toast("Gagal menyimpan target PL. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }

  private String roleLabel(){if("cos".equals(currentRole))return "COS";if("acos".equals(currentRole))return "ACOS";if("crew".equals(currentRole))return "Crew";return "Admin Utama";}
  private void cardTitle(LinearLayout p,String s){TextView t=txt(s,16,DARK,true);t.setPadding(0,dp(16),0,dp(9));p.addView(t,lp(-2));}
  private View metricBox(String title,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe4e4e4,dp(10)));c.setPadding(dp(6),dp(12),dp(6),dp(12));c.addView(center(title,10,MUTED,false));c.addView(center(value,16,GREEN,true));return c;}
  private View metric(LinearLayout p,String title,String sub,String val,boolean unused){LinearLayout c=col();c.setBackground(shape(0xfffff5dc,0xffeadcae,dp(12)));c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(txt(title,14,DARK,true));c.addView(txt(sub+"  "+val,14,GREEN,true));p.addView(c,lp(-2));return c;}
  private void progressRow(LinearLayout p,String name,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(15)));c.setElevation(dp(1));c.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout top=row();top.addView(txt(name,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(txt("—",13,MUTED,true));c.addView(top);TextView sub=txt(value,11,MUTED,false);sub.setPadding(0,dp(4),0,dp(8));c.addView(sub);ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffedf0f4));c.addView(bar,lp(7));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(8);p.addView(c,q);}
  private void detail(LinearLayout p,String k,String v){LinearLayout r=row();r.setPadding(dp(10),dp(13),dp(10),dp(13));r.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(14)));r.addView(txt(k,13,DARK,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,DARK,true));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(5);p.addView(r,q);}
  private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setTextColor(RED);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));return b;}
  private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));b.setMinHeight(dp(48));return b;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(auth!=null&&auth.getCurrentUser()!=null){showDashboard("Beranda");}else showLogin();}
}
