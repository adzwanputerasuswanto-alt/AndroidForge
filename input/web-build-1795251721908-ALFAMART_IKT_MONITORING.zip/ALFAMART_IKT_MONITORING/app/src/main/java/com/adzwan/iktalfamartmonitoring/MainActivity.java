package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.content.Intent;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.Query;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.yalantis.ucrop.UCrop;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
  private static final int RED=Color.rgb(196,0,35), BLUE=Color.rgb(20,75,130), DARK=Color.rgb(29,37,51), MUTED=Color.rgb(111,121,136), BG=Color.rgb(246,247,250), GREEN=Color.rgb(24,132,83), SOFT_RED=Color.rgb(255,241,244);
  private static final String AUTH_DOMAIN="@ikt-monitoring.app";
  private FirebaseAuth auth; private FirebaseFirestore db; private FirebaseStorage storage; private ImageView profileAvatar; private static final int PICK_PROFILE_PHOTO=412;
  private boolean adminMode=false, loading=false;
  private EditText identityInput,passwordInput; private Button loginButton;
  private String currentName="", currentRole="", currentNik="", storeCode="", storeName="", storeType="";
  private LinearLayout root;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(RED);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); try{FirebaseApp.initializeApp(this);auth=FirebaseAuth.getInstance();db=FirebaseFirestore.getInstance();storage=FirebaseStorage.getInstance();}catch(Exception e){toast("Firebase belum siap: "+e.getMessage());} showLogin();}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(Math.max(radius,dp(14)));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
  private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return t;}
  private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
  private LinearLayout.LayoutParams lp(int h){return new LinearLayout.LayoutParams(-1,h<0?h:dp(h));}
  private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-2,1);}
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
  private void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
  private TextView center(String s,int size,int color,boolean bold){TextView t=txt(s,size,color,bold);t.setGravity(Gravity.CENTER);return t;}
  private void showLogin(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);root=col();root.setGravity(Gravity.CENTER_HORIZONTAL);root.setBackgroundColor(BG);sc.addView(root);root.setPadding(dp(20),dp(26),dp(20),dp(22));
    LinearLayout hero=col();hero.setGravity(Gravity.CENTER);hero.setBackground(shape(RED,0,dp(22)));hero.setPadding(dp(18),dp(30),dp(18),dp(28));hero.setElevation(dp(5));
    ImageView logo=new ImageView(this); logo.setImageResource(com.adzwan.iktalfamartmonitoring.R.drawable.alfamart_logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(150),dp(58)); hero.addView(logo,logoParams);TextView title=center("IKT Alfamart Monitoring",21,Color.WHITE,true);title.setPadding(0,dp(12),0,0);hero.addView(title,lp(-2));root.addView(hero,lp(-2));
    LinearLayout modes=row();modes.setPadding(0,dp(20),0,dp(8));Button p=modeButton("Personil Toko",!adminMode),a=modeButton("Admin Utama",adminMode);modes.addView(p,weight());modes.addView(a,weight());root.addView(modes,lp(-2));
    TextView info=center(adminMode?"LOGIN ADMIN UTAMA":"LOGIN PERSONIL TOKO",17,DARK,true);info.setPadding(0,dp(7),0,dp(8));root.addView(info,lp(-2));
    identityInput=new EditText(this);identityInput.setSingleLine(true);identityInput.setTextSize(15);identityInput.setMaxWidth(dp(420));identityInput.setPadding(dp(15),dp(12),dp(15),dp(12));identityInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));identityInput.setHint(adminMode?"Email Admin Utama":"NIK (8 angka)");identityInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS:InputType.TYPE_CLASS_NUMBER);root.addView(identityInput,field());
    passwordInput=new EditText(this);passwordInput.setSingleLine(true);passwordInput.setTextSize(15);passwordInput.setMaxWidth(dp(420));passwordInput.setPadding(dp(15),dp(12),dp(15),dp(12));passwordInput.setBackground(shape(Color.WHITE,0xffdddddd,dp(12)));passwordInput.setHint(adminMode?"Password":"PIN (6 digit)");passwordInput.setInputType(adminMode?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(passwordInput,field());
    loginButton=new Button(this);loginButton.setText("Login");loginButton.setTextColor(Color.WHITE);loginButton.setAllCaps(false);loginButton.setTextSize(16);loginButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));root.addView(loginButton,field());
    TextView note=center(adminMode?"Admin Utama\nLogin menggunakan email dan password.":"Personil Toko: COS, ACOS, dan Crew\nLogin menggunakan NIK dan PIN.",12,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(12)));note.setPadding(dp(12),dp(14),dp(12),dp(14));root.addView(note,field());
    if(!adminMode){ TextView signup=center("Belum punya akun?  Daftar Akun Baru",14,BLUE,true); signup.setPadding(0,dp(12),0,dp(12)); signup.setClickable(true); signup.setOnClickListener(v->showRegister()); root.addView(signup,lp(-2)); }
    TextView credit=center("Design by Adzwan Putera Suswanto",11,MUTED,false); credit.setPadding(0,dp(10),0,dp(6)); root.addView(credit,lp(-2));
    p.setOnClickListener(v->{adminMode=false;showLogin();});a.setOnClickListener(v->{adminMode=true;showLogin();});loginButton.setOnClickListener(v->doLogin());setContentView(sc);
  }
  private void showRegister(){
    ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout page=col();page.setGravity(Gravity.CENTER_HORIZONTAL);page.setPadding(dp(22),dp(22),dp(22),dp(22));page.setBackgroundColor(BG);sc.addView(page);
    TextView title=center("DAFTAR AKUN PERSONIL",22,DARK,true);title.setPadding(0,dp(16),0,dp(8));page.addView(title,lp(-2));
    TextView desc=center("Isi data personil dan toko. Akun menunggu verifikasi Admin Utama.",13,MUTED,false);page.addView(desc,lp(-2));
    EditText name=registerField(page,"Nama Lengkap",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    EditText nik=registerField(page,"NIK (8 angka)",InputType.TYPE_CLASS_NUMBER);
    Spinner role=new Spinner(this);String[] roles={"Pilih Jabatan","Crew","ACOS","COS"};role.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,roles));page.addView(role,field());
    EditText code=registerField(page,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText shop=registerField(page,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    EditText pin=registerField(page,"Buat PIN (6 digit)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    EditText confirm=registerField(page,"Ulangi PIN",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
    Button submit=primary("Daftar Akun");page.addView(submit,field());
    TextView info=txt("Pendaftaran tidak memakai kode aktivasi. Akun baru belum dapat login sampai Admin Utama memverifikasi data dan mengaktifkannya.",12,BLUE,false);info.setBackground(shape(0xffe8f0fc,0,dp(12)));info.setPadding(dp(12),dp(12),dp(12),dp(12));page.addView(info,field());
    TextView back=center("Kembali ke Login",14,BLUE,true);back.setPadding(0,dp(12),0,dp(12));page.addView(back,lp(-2));back.setOnClickListener(v->showLogin());
    submit.setOnClickListener(v->{String nm=name.getText().toString().trim(),n=nik.getText().toString().trim(),r=role.getSelectedItemPosition()==1?"crew":role.getSelectedItemPosition()==2?"acos":role.getSelectedItemPosition()==3?"cos":"",c=code.getText().toString().trim().toUpperCase(Locale.US),sn=shop.getText().toString().trim(),pw=pin.getText().toString(),cp=confirm.getText().toString();if(nm.isEmpty()||!n.matches("\\d{8}")||r.isEmpty()||c.isEmpty()||sn.isEmpty()||!pw.matches("\\d{6}")||!pw.equals(cp)){toast("Periksa semua data, jabatan, NIK, dan PIN.");return;}if(auth==null||db==null){toast("Firebase belum siap.");return;}submit.setEnabled(false);submit.setText("Mendaftarkan...");String email=n+AUTH_DOMAIN;auth.createUserWithEmailAndPassword(email,pw).addOnCompleteListener(this,task->{if(!task.isSuccessful()){submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran gagal: "+(task.getException()==null?"periksa koneksi":task.getException().getLocalizedMessage()));return;}Map<String,Object> req=new HashMap<>();req.put("nik",n);req.put("name",nm);req.put("requestedRole",r);req.put("storeCode",c);req.put("storeName",sn);req.put("email",email);req.put("status","pending");req.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());req.put("authUid",auth.getCurrentUser().getUid());db.collection("RegistrationRequests").document(n).set(req).addOnSuccessListener(vv->{auth.signOut();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Pendaftaran terkirim. Tunggu verifikasi Admin Utama.");showLogin();}).addOnFailureListener(e->{if(auth.getCurrentUser()!=null)auth.getCurrentUser().delete();submit.setEnabled(true);submit.setText("Daftar Akun");toast("Permohonan gagal disimpan. Rules Firestore perlu diperbarui: "+e.getLocalizedMessage());});});});
    setContentView(sc);
  }
  private EditText registerField(LinearLayout parent,String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setInputType(type);e.setPadding(dp(17),dp(14),dp(17),dp(14));e.setBackground(shape(Color.WHITE,0xffe4e8ef,dp(16)));parent.addView(e,field());return e;}
  private Button modeButton(String s,boolean selected){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);b.setTextColor(selected?Color.WHITE:DARK);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(selected?RED:Color.WHITE));return b;}
  private LinearLayout.LayoutParams field(){LinearLayout.LayoutParams p=lp(-2);p.bottomMargin=dp(10);return p;}
  private void doLogin(){if(auth==null||db==null){toast("Firebase belum siap.");return;}String id=identityInput.getText().toString().trim(),pw=passwordInput.getText().toString().trim();if(adminMode){if(id.isEmpty()||pw.isEmpty()){toast("Masukkan email dan password.");return;}signIn(id,pw,true,null);}else{if(!id.matches("\\d{8}")||!pw.matches("\\d{6}")){toast("NIK harus 8 angka dan PIN harus 6 digit.");return;}signIn(id+AUTH_DOMAIN,pw,false,id);}}
  private void signIn(String email,String password,boolean admin,String nik){
    loginButton.setEnabled(false);loginButton.setText("Memeriksa...");
    auth.signInWithEmailAndPassword(email,password).addOnCompleteListener(this,task->{
      if(!task.isSuccessful()){restoreLogin();toast("Login gagal. Periksa NIK/email dan PIN/password.");return;}
      if(admin){db.collection("Users").document("AdminUtama").get().addOnSuccessListener(d->finishLogin(d,true,nik,email)).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil Admin: "+e.getLocalizedMessage());});return;}
      // Personil: baca identitas kanonis langsung dari Personnel/{NIK}; tidak memakai collectionGroup/index.
      db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{
        if(!person.exists()){restoreLogin();auth.signOut();toast("Profil Personnel tidak ditemukan. Minta Admin Utama memeriksa data personil.");return;}
        if(!Boolean.TRUE.equals(person.getBoolean("isActive"))){restoreLogin();auth.signOut();toast("Akun personil belum aktif. Hubungi Admin Utama.");return;}
        String role=firstNonEmpty(person.getString("currentRole"),person.getString("role"));
        String code=firstNonEmpty(person.getString("currentStoreCode"),person.getString("storeCode"));
        String shop=firstNonEmpty(person.getString("currentStoreName"),person.getString("storeName"));
        if(role.isEmpty()||code.isEmpty()||shop.isEmpty()){restoreLogin();auth.signOut();toast("Data jabatan atau toko aktif di Personnel belum lengkap. Hubungi Admin Utama.");return;}
        db.collection("Stores").document(code).collection("Users").document(nik).get().addOnSuccessListener(profile->{
          if(!profile.exists()||!Boolean.TRUE.equals(profile.getBoolean("isActive"))||!nik.equals(profile.getString("nik"))){restoreLogin();auth.signOut();toast("Profil toko aktif tidak ditemukan atau belum aktif. Periksa Stores/"+code+"/Users/"+nik+".");return;}
          String storeRole=firstNonEmpty(profile.getString("role"),role);
          if(!role.equals(storeRole)){restoreLogin();auth.signOut();toast("Jabatan di Personnel dan profil toko berbeda. Minta Admin Utama menyamakan data.");return;}
          db.collection("Stores").document(code).get().addOnSuccessListener(storeDoc->{
            if(!storeDoc.exists()){restoreLogin();auth.signOut();toast("Data master toko belum dibuat. Admin Utama perlu mengatur jenis toko terlebih dahulu.");return;}
            String type=firstNonEmpty(storeDoc.getString("storeType"),storeDoc.getString("type"));
            if(!"24_JAM".equals(type)&&!"NORMAL".equals(type)){restoreLogin();auth.signOut();toast("Jenis toko belum diatur. Minta Admin Utama memilih 24 Jam atau Normal.");return;}
            currentName=firstNonEmpty(person.getString("name"),profile.getString("name"));currentRole=role;currentNik=nik;storeCode=code;storeName=shop;storeType=type;restoreLogin();showDashboard("Beranda");
          }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca master toko: "+e.getLocalizedMessage());});
        }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca profil toko: "+e.getLocalizedMessage());});
      }).addOnFailureListener(e->{restoreLogin();auth.signOut();toast("Gagal membaca Personnel: "+e.getLocalizedMessage());});
    });
  }
  private String firstNonEmpty(String a,String b){if(a!=null&&!a.trim().isEmpty()&&!"...".equals(a.trim())&&!".".equals(a.trim()))return a;return b==null?"":b;}
  private void finishLogin(DocumentSnapshot d,boolean admin,String nik,String email){restoreLogin();String role=d.getString("role"),registered=d.getString("email");boolean valid=Boolean.TRUE.equals(d.getBoolean("isActive"))&&(admin?"admin_utama".equals(role):(role!=null&&("crew".equals(role)||"acos".equals(role)||"cos".equals(role))&&nik.equals(d.getString("nik"))));if(admin&&registered!=null&&!registered.equalsIgnoreCase(email))valid=false;if(!valid){auth.signOut();toast("Akun belum aktif atau hak akses tidak sesuai. Jika baru mendaftar, tunggu verifikasi Admin Utama.");return;}currentName=d.getString("name")==null?"Personil":d.getString("name");currentRole=role;currentNik=admin?"":nik;storeCode=d.getString("storeCode")==null?"":d.getString("storeCode");storeName=d.getString("storeName")==null?"":d.getString("storeName");if(!admin&&(storeCode.isEmpty()||storeName.isEmpty())){auth.signOut();toast("Profil belum memiliki data toko aktif. Hubungi Admin Utama.");return;}showDashboard("Beranda");}
  private void restoreLogin(){if(loginButton!=null){loginButton.setEnabled(true);loginButton.setText("Login");}}
  private void showDashboard(String page){
    LinearLayout shell=col(); shell.setBackgroundColor(BG);
    LinearLayout header=row(); header.setBackgroundColor(RED); header.setPadding(dp(16),dp(12),dp(16),dp(12));
    TextView menu=txt("☰",24,Color.WHITE,true); menu.setGravity(Gravity.CENTER); menu.setPadding(dp(8),dp(4),dp(8),dp(4)); menu.setContentDescription("Buka menu"); menu.setClickable(true); menu.setFocusable(true); header.addView(menu);
    menu.setOnClickListener(v->{ PopupMenu popup=new PopupMenu(MainActivity.this,menu); String[] entries=menuEntries(); for(String entry:entries) popup.getMenu().add(entry); popup.setOnMenuItemClickListener(item->{String choice=item.getTitle().toString(); if("Keluar".equals(choice)){if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();}else if("Input PL Crew".equals(choice)){showDashboard("Input PL Crew");}else{showDashboard(choice);} return true;}); popup.show();});
    TextView brand=txt("IKT Alfamart",18,Color.WHITE,true); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1);bp.leftMargin=dp(14);header.addView(brand,bp);
    TextView bell=txt("♧",22,Color.WHITE,true);header.addView(bell);shell.addView(header,lp(-2));
    ScrollView sc=new ScrollView(this);sc.setFillViewport(false);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(14));sc.addView(body);shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout welcome=row();TextView avatar=center("●",25,RED,true);avatar.setBackground(shape(Color.WHITE,0xffdddddd,dp(28)));avatar.setWidth(dp(50));avatar.setHeight(dp(50));welcome.addView(avatar);
    LinearLayout who=col();who.setPadding(dp(10),0,0,0);who.addView(txt("Halo, "+currentName,15,DARK,true));who.addView(txt(roleLabel()+" • Toko "+storeCode,12,MUTED,false));welcome.addView(who,new LinearLayout.LayoutParams(0,-2,1));
    TextView month=txt("Nov 2026  ▣",11,DARK,true);month.setBackground(shape(Color.WHITE,0xffdddddd,dp(8)));month.setPadding(dp(9),dp(8),dp(9),dp(8));welcome.addView(month);body.addView(welcome,lp(-2));

    if(page.equals("Pengaturan Jenis Toko")){
      if(!"admin_utama".equals(currentRole)){body.addView(txt("Akses hanya untuk Admin Utama.",14,RED,true));}
      else showStoreTypeSettings(body);
    }else if(page.equals("Beranda")){
      if("crew".equals(currentRole)){
        cardTitle(body,"Pencapaian Saya (s.d. 20 Nov)");
        LinearLayout trophy=col();trophy.setBackground(shape(0xfffff6df,0xffeadcae,dp(11)));trophy.setPadding(dp(13),dp(12),dp(13),dp(12));
        trophy.addView(txt("🏆  Ranking Gabungan",14,DARK,true));trophy.addView(txt("Menunggu data pencapaian",18,GREEN,true));body.addView(trophy,lp(-2));
        cardTitle(body,"Pencapaian per Indikator");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
        LinearLayout acts=row();Button input=primary("Input PL Hari Ini");Button rank=smallButton("Lihat Ranking");acts.addView(input,weight());acts.addView(rank,weight());body.addView(acts,field());input.setOnClickListener(v->showDashboard("Input PL"));rank.setOnClickListener(v->showDashboard("Ranking Crew"));
      }else{
        cardTitle(body,"Kinerja Toko (s.d. 20 Nov)");
        LinearLayout metrics=col(); TextView[][] metricFields=new TextView[4][4]; String[] metricLabels={"NET SALES","MARGIN","NSB","STATUS IKT"}; int[] cardColors={0xffFBE3E8,0xffDFEAFA,0xffE2F2E2,0xffFCEBD9};
        for(int rowIndex=0;rowIndex<2;rowIndex++){ LinearLayout metricRow=row(); for(int colIndex=0;colIndex<2;colIndex++){int ix=rowIndex*2+colIndex; LinearLayout c=col(); c.setBackground(shape(cardColors[ix],0xffe7ebf2,dp(20)));c.setElevation(dp(3)); c.setPadding(dp(13),dp(14),dp(13),dp(14)); c.addView(txt(metricLabels[ix],16,BLUE,true)); metricFields[ix][0]=txt("Memuat...",29,Color.BLACK,true); metricFields[ix][0].setPadding(0,dp(9),0,dp(1)); c.addView(metricFields[ix][0]); metricFields[ix][1]=txt(ix==3?"Status toko":"Pencapaian",14,DARK,false); c.addView(metricFields[ix][1]); View gap=new View(this);c.addView(gap,lp(12)); metricFields[ix][2]=txt("Target : --",13,DARK,false); c.addView(metricFields[ix][2]); metricFields[ix][3]=txt("Aktual : --",13,DARK,false); c.addView(metricFields[ix][3]); TextView note=txt("Keterangan : Menunggu data",13,GREEN,true); note.setPadding(0,dp(13),0,0);c.addView(note); metricFields[ix]=new TextView[]{metricFields[ix][0],metricFields[ix][1],metricFields[ix][2],metricFields[ix][3],note}; LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(236),1); q.setMargins(dp(4),dp(4),dp(4),dp(4)); metricRow.addView(c,q);} metrics.addView(metricRow,lp(-2)); } body.addView(metrics,lp(-2)); loadDashboardIKT(metricFields);
        LinearLayout actions=row();String[][] acts={{"▣","Input Target IKT"},{"▤","Target Penawaran Langsung"},{"✎","Penawaran Langsung Crew"},{"♛","Ranking Crew"}};
        for(String[] act:acts){String label=act[1];LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setBackground(shape(Color.WHITE,0xffe8eaf0,dp(15)));tile.setElevation(dp(2));tile.setPadding(dp(3),dp(10),dp(3),dp(10));tile.addView(center(act[0],21,RED,true));tile.addView(center(label,10,DARK,true));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(78),1);q.setMargins(dp(3),dp(8),dp(3),dp(8));actions.addView(tile,q);tile.setOnClickListener(v->showDashboard(label.equals("Penawaran Langsung Crew")?"Input PL Crew":label));}body.addView(actions,lp(-2));
        LinearLayout extra=row();String[][] extraActs={{"♜","Reward"},{"▤","Laporan"}};for(String[] act:extraActs){Button b=smallButton(act[1]);extra.addView(b,weight());b.setOnClickListener(v->showDashboard(act[1]));}body.addView(extra,field());
        cardTitle(body,"Progress Indikator PL Toko");for(String s:new String[]{"PSM","PWP","Serba Gratis","SUEGER"})progressRow(body,s,"Belum ada data");
      }
    }else if(page.equals("Input Target Penawaran Langsung")) {
      cardTitle(body,"Input Target Penawaran Langsung");
      body.addView(txt("Atur target bulanan toko. Setiap indikator memiliki periode pencapaian tersendiri.",12,MUTED,false),field());
      body.addView(txt("Bulan Target",13,DARK,true)); DatePicker targetMonth=new DatePicker(this); targetMonth.setCalendarViewShown(false); targetMonth.setSpinnersShown(true); body.addView(targetMonth,lp(-2));
      Map<String,EditText> plTargets=new HashMap<>();
      addTargetPeriod(body,plTargets,"PSM","Week 1 • Tanggal 1–7","PSM_W1"); addTargetPeriod(body,plTargets,"PSM","Week 2 • Tanggal 8–15","PSM_W2"); addTargetPeriod(body,plTargets,"PSM","Week 3 • Tanggal 16–23","PSM_W3"); addTargetPeriod(body,plTargets,"PSM","Week 4 • Tanggal 24–akhir bulan","PSM_W4");
      addTargetPeriod(body,plTargets,"PWP","Periode 1 • Tanggal 1–15","PWP_P1"); addTargetPeriod(body,plTargets,"PWP","Periode 2 • Tanggal 16–akhir bulan","PWP_P2");
      addTargetPeriod(body,plTargets,"Serba Gratis","Periode 1 • Tanggal 1–15","SG_P1"); addTargetPeriod(body,plTargets,"Serba Gratis","Periode 2 • Tanggal 16–akhir bulan","SG_P2");
      addTargetPeriod(body,plTargets,"SUEGER","Periode 1 • Tanggal 1–15","SUEGER_P1"); addTargetPeriod(body,plTargets,"SUEGER","Periode 2 • Tanggal 16–akhir bulan","SUEGER_P2");
      loadMonthlyPLTargets(targetMonth,plTargets); Button savePLTarget=primary("Simpan Target Penawaran Langsung"); body.addView(savePLTarget,field()); savePLTarget.setOnClickListener(v->saveMonthlyPLTargets(targetMonth,plTargets,savePLTarget));
      TextView plNote=txt("Target tersimpan terpisah dari Target IKT untuk bulan dan toko yang dipilih.",11,BLUE,false); plNote.setBackground(shape(0xffe8f0fc,0,dp(8))); plNote.setPadding(dp(10),dp(10),dp(10),dp(10)); body.addView(plNote,lp(-2));
    }else if(page.equals("Input Target IKT")||page.equals("Input PL")||page.equals("Input PL Crew")||page.equals("Input Toko")){
      boolean target=page.equals("Input Target IKT");boolean pl=page.equals("Input PL")||page.equals("Input PL Crew");
      cardTitle(body,target?"Input Target IKT Bulanan":pl?("crew".equals(currentRole)?"Penawaran Langsung Hari Ini":"Penawaran Langsung Crew") :"Input Data Toko");
      if(target)body.addView(txt("Atur target IKT bulanan toko: Net Sales, Margin %, NSB, APC, dan STD.",12,MUTED,false),field());
      if(pl && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))body.addView(txt("Masukkan NIK Crew yang akan diinput atau diperbarui. Data tersimpan atas nama Crew yang dipilih.",12,MUTED,false),field());
      body.addView(txt(target?"Pilih bulan target":"Tanggal",13,DARK,true));DatePicker date=new DatePicker(this);date.setCalendarViewShown(false);date.setSpinnersShown(true);body.addView(date,lp(-2));
      EditText targetNik=null;
      if(pl&&("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){body.addView(txt("NIK Crew yang diinput (8 angka)",13,DARK,true));targetNik=registerField(body,"Masukkan NIK Crew",InputType.TYPE_CLASS_NUMBER);targetNik.setText(currentNik);}
      String[] labels=target?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:page.equals("Input Toko")?new String[]{"Net Sales","Margin %","NSB","APC","STD"}:new String[]{"PSM","PWP","Serba Gratis","SUEGER"};
      Map<String,EditText> inputs=new HashMap<>();
      for(String key:labels){LinearLayout r=row();r.setPadding(dp(10),dp(7),dp(10),dp(7));r.setBackground(shape(Color.WHITE,0xffe5e5e5,dp(8)));r.addView(txt(key,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));if(isRupiahMetric(key))r.addView(txt("Rp",12,MUTED,true));else if(isDecimalMetric(key))r.addView(txt("%",12,MUTED,true));EditText val=new EditText(this);configureMetricInput(val,key);val.setText("0");val.setEms(5);applyZeroFocusStyle(val);r.addView(val);inputs.put(key,val);LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(7);body.addView(r,q);}
      final EditText selectedCrewNik=targetNik;
      if(target)loadMonthlyTarget(date,inputs);else loadDailyInput(page,date,inputs,selectedCrewNik);
      if(!target)date.init(date.getYear(),date.getMonth(),date.getDayOfMonth(),(view,y,m,d)->loadDailyInput(page,date,inputs,selectedCrewNik));
      Button save=primary(target?"Simpan Target": "Simpan");body.addView(save,field());save.setOnClickListener(v->{if(target)saveMonthlyTarget(date,inputs,save);else saveDailyInput(page,date,inputs,save,selectedCrewNik);});
      TextView note=txt(target?"Target berlaku untuk toko dan bulan yang dipilih.":"Data harian dapat diinput dan dikoreksi kapan saja. Semua indikator wajib diisi; NSB boleh 0. Setiap koreksi dicatat.",11,BLUE,false);note.setBackground(shape(0xffe8f0fc,0,dp(8)));note.setPadding(dp(10),dp(10),dp(10),dp(10));body.addView(note,lp(-2));
    }else if(page.equals("Ranking Crew")){
      cardTitle(body,"Ranking Crew");LinearLayout tabs=row();tabs.addView(smallButton("Harian"),weight());tabs.addView(primary("Bulanan"),weight());body.addView(tabs,field());
      for(int i=1;i<=5;i++)progressRow(body,i+". Personil Crew","Menunggu data pencapaian");
    }else if(page.equals("Reward")){
      cardTitle(body,"Reward IKT");LinearLayout trophy=col();trophy.setBackground(shape(0xfff0f8e9,0xffd4e8c8,dp(10)));trophy.setPadding(dp(14),dp(14),dp(14),dp(14));trophy.addView(center("🏆",28,GREEN,true));trophy.addView(center("Status IKT Toko",14,DARK,true));trophy.addView(center("Menunggu data kinerja",18,GREEN,true));body.addView(trophy,lp(-2));
      cardTitle(body,"Kategori Reward");progressRow(body,"Kategori A","Menunggu pencapaian Net Sales");progressRow(body,"Penerima","Data reward belum tersedia");
    }else if(page.equals("Profil")){
      cardTitle(body,"Profil Personil");profileAvatar=new ImageView(this);profileAvatar.setImageResource(android.R.drawable.ic_menu_camera);profileAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);profileAvatar.setBackground(shape(Color.WHITE,0xffe2e6ed,dp(60)));profileAvatar.setClipToOutline(true);LinearLayout.LayoutParams avatarLp=new LinearLayout.LayoutParams(dp(112),dp(112));avatarLp.gravity=Gravity.CENTER_HORIZONTAL;body.addView(profileAvatar,avatarLp);profileAvatar.setOnClickListener(v->chooseProfilePhoto());loadProfilePhoto();TextView name=center(currentName,18,DARK,true);body.addView(name,lp(-2));for(String[] x:new String[][]{{"NIK",currentNik.isEmpty()?"Admin Utama":currentNik},{"Username",currentNik},{"Jabatan",roleLabel()},{"Kode Toko",storeCode},{"Nama Toko",storeName}})detail(body,x[0],x[1]);
      if(!currentNik.isEmpty()){Button career=smallButton("Jenjang Karir / Ajukan Kenaikan");body.addView(career,field());career.setOnClickListener(v->showCareerRequest());}
      Button out=smallButton("Keluar");body.addView(out,field());out.setOnClickListener(v->{if(auth!=null)auth.signOut();currentName="";currentRole="";currentNik="";adminMode=false;showLogin();});
    }else if(page.equals("Verifikasi Pendaftaran")){
      cardTitle(body,"Verifikasi Pendaftaran Personil");loadPendingRegistrations(body);
    }else if(page.equals("Permohonan Karir")){
      cardTitle(body,"Persetujuan Jenjang Karir");loadPendingCareer(body);
    }else if(page.equals("Mutasi Personil")){
      cardTitle(body,"Mutasi Personil Antar Toko");EditText mn=registerField(body,"NIK Personil (8 angka)",InputType.TYPE_CLASS_NUMBER);EditText mc=registerField(body,"Kode Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);EditText ms=registerField(body,"Nama Toko Baru",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);Button move=primary("Proses Mutasi");body.addView(move,field());move.setOnClickListener(v->processMutation(mn.getText().toString().trim(),mc.getText().toString().trim().toUpperCase(Locale.US),ms.getText().toString().trim()));body.addView(txt("Mutasi memperbarui toko aktif dan mencatat riwayat toko sebelumnya. Hanya Admin Utama.",12,BLUE,false),field());
    }else if(page.equals("Laporan")){
      cardTitle(body,"Laporan Penawaran Langsung Crew");
      body.addView(txt("Pilih bulan untuk melihat data PSM, PWP, Serba Gratis, dan SUEGER yang sudah disimpan.",12,MUTED,false),field());
      DatePicker reportMonth=new DatePicker(this);reportMonth.setCalendarViewShown(false);reportMonth.setSpinnersShown(true);body.addView(reportMonth,lp(-2));
      LinearLayout reportResults=col();body.addView(reportResults,lp(-2));
      Button refresh=primary("Tampilkan Laporan Penawaran Langsung");body.addView(refresh,field());
      refresh.setOnClickListener(v->loadPLReport(reportResults,reportMonth));
      loadPLReport(reportResults,reportMonth);
    }else{
      cardTitle(body,page);body.addView(txt("Halaman ini disiapkan mengikuti desain referensi. Data dan fungsi operasional akan dihubungkan bertahap.",14,MUTED,false));
    }
    LinearLayout nav=row(); nav.setBackground(shape(Color.WHITE,0xffedf0f5,dp(18))); nav.setElevation(dp(10)); nav.setPadding(dp(2),dp(4),dp(2),dp(8)); String[][] tabs={{"⌂","Beranda"},{"✎","Input PL"},{"♛","Ranking Crew"},{"▤","Laporan"},{"♙","Profil"}}; for(String[] tab:tabs){String t=tab[1]; LinearLayout item=col(); item.setGravity(Gravity.CENTER); item.setPadding(dp(2),dp(5),dp(2),dp(5)); item.setClickable(true); item.setFocusable(true); item.setBackgroundResource(android.R.drawable.list_selector_background); TextView ico=center(tab[0],18,t.equals(page)?RED:MUTED,true); TextView label=center(t,9,t.equals(page)?RED:MUTED,true); item.addView(ico,lp(-2)); item.addView(label,lp(-2)); nav.addView(item,new LinearLayout.LayoutParams(0,dp(54),1)); item.setOnClickListener(v->showDashboard(("Input PL".equals(t) && ("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole)))?"Input PL Crew":t)); } shell.addView(nav,lp(-2)); setContentView(shell);
  }

  private void loadPLReport(LinearLayout results,DatePicker monthPicker){
    results.removeAllViews();
    if(db==null){results.addView(txt("Firebase belum siap.",13,RED,true),field());return;}
    results.addView(txt("Memuat data Penawaran Langsung...",13,MUTED,false),field());
    final int year=monthPicker.getYear(), month=monthPicker.getMonth()+1;
    final String monthLabel=String.format(Locale.US,"%04d-%02d",year,month);
    final String firstDay=String.format(Locale.US,"%04d%02d01",year,month);
    final String lastDay=String.format(Locale.US,"%04d%02d31",year,month);
    Query query=db.collection("DailyPLReports");
    if("crew".equals(currentRole)){
      query=query.whereEqualTo("targetNik",currentNik);
    }else if("cos".equals(currentRole)||"acos".equals(currentRole)){
      query=query.whereEqualTo("storeCode",storeCode);
    }else if(!"admin_utama".equals(currentRole)){
      results.removeAllViews();results.addView(txt("Akses laporan tidak tersedia untuk jabatan ini.",13,RED,true),field());return;
    }
    query=query.whereGreaterThanOrEqualTo("dateKey",firstDay).whereLessThanOrEqualTo("dateKey",lastDay);
    query.get().addOnSuccessListener(snapshot->{
      results.removeAllViews();double[] totals=new double[4];int recordCount=0;
      Map<String,double[]> byCrew=new HashMap<>();Map<String,String> crewNames=new HashMap<>();
      for(DocumentSnapshot doc:snapshot.getDocuments()){
        String nik=doc.getString("targetNik");
        if(nik==null||nik.isEmpty())nik=doc.getId().split("_")[0];
        double[] vals={num(doc.get("PSM")),num(doc.get("PWP")),num(doc.get("Serba Gratis")),num(doc.get("SUEGER"))};
        for(int i=0;i<4;i++)totals[i]+=vals[i];recordCount++;
        double[] crew=byCrew.get(nik);if(crew==null){crew=new double[5];byCrew.put(nik,crew);}for(int i=0;i<4;i++)crew[i]+=vals[i];crew[4]++;
        String name=doc.getString("targetName");if(name==null||name.isEmpty())name=nik;crewNames.put(nik,name);
      }
      cardTitle(results,"Rekap Bulan "+monthLabel);
      if(recordCount==0){results.addView(txt("Belum ada data Penawaran Langsung untuk periode ini.",13,MUTED,false),field());return;}
      detail(results,"Jumlah input Crew-hari",String.valueOf(recordCount));String[] labels={"PSM","PWP","Serba Gratis","SUEGER"};
      for(int i=0;i<4;i++)detail(results,"Total "+labels[i],formatGroupedInteger(totals[i]));
      cardTitle(results,"Rincian per Crew");ArrayList<String> keys=new ArrayList<>(byCrew.keySet());Collections.sort(keys);
      for(String key:keys){double[] v=byCrew.get(key);LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e9ef,dp(12)));card.setPadding(dp(12),dp(10),dp(12),dp(10));card.addView(txt(crewNames.get(key)+" • "+key,14,DARK,true));card.addView(txt("Jumlah input: "+(int)v[4],11,MUTED,false));for(int i=0;i<4;i++)card.addView(txt(labels[i]+": "+formatGroupedInteger(v[i]),12,DARK,false));LinearLayout.LayoutParams cp=lp(-2);cp.bottomMargin=dp(8);results.addView(card,cp);}
    }).addOnFailureListener(e->{results.removeAllViews();results.addView(txt("Gagal membaca DailyPLReports: "+e.getLocalizedMessage(),13,RED,false),field());});
  }

  private void loadPendingRegistrations(LinearLayout body){if(!"admin_utama".equals(currentRole)){toast("Khusus Admin Utama.");return;}db.collection("RegistrationRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pendaftaran menunggu verifikasi.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("name"),role=d.getString("requestedRole"),code=d.getString("storeCode"),shop=d.getString("storeName"),email=d.getString("email");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(role+" | "+code+" - "+shop,12,MUTED,false));LinearLayout buttons=row();Button approve=primary("Setujui");Button reject=smallButton("Tolak");buttons.addView(approve,weight());buttons.addView(reject,weight());card.addView(buttons,field());body.addView(card,field());approve.setOnClickListener(v->approveRegistration(d));reject.setOnClickListener(v->rejectRequest("RegistrationRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pendaftaran: "+e.getLocalizedMessage()));}
  private void approveRegistration(DocumentSnapshot req){if(!"admin_utama".equals(currentRole))return;String nik=req.getString("nik"),code=req.getString("storeCode"),shop=req.getString("storeName"),role=req.getString("requestedRole");if(nik==null||code==null||shop==null||role==null)return;Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",req.getString("name"));profile.put("role",role);profile.put("storeCode",code);profile.put("storeName",shop);profile.put("email",req.getString("email"));profile.put("isActive",true);profile.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());Map<String,Object> person=new HashMap<>(profile);person.put("currentRole",role);person.put("currentStoreCode",code);person.put("currentStoreName",shop);db.runBatch(batch->{batch.set(db.collection("Stores").document(code).collection("Users").document(nik),profile);batch.set(db.collection("Personnel").document(nik),person,SetOptions.merge());batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy",currentNik.isEmpty()?"AdminUtama":currentNik);}).addOnSuccessListener(v->showDashboard("Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menyetujui. Periksa Rules: "+e.getLocalizedMessage()));}
  private void loadPendingCareer(LinearLayout body){if(!"admin_utama".equals(currentRole))return;db.collection("CareerRequests").whereEqualTo("status","pending").get().addOnSuccessListener(q->{if(q.isEmpty()){body.addView(txt("Tidak ada pengajuan karir menunggu persetujuan.",14,MUTED,false),field());return;}for(DocumentSnapshot d:q.getDocuments()){String nik=d.getString("nik"),name=d.getString("personName"),from=d.getString("currentRole"),to=d.getString("requestedRole"),why=d.getString("reason");LinearLayout card=col();card.setBackground(shape(Color.WHITE,0xffe5e8ef,dp(12)));card.setPadding(dp(12),dp(12),dp(12),dp(12));card.addView(txt(name+" • "+nik,15,DARK,true));card.addView(txt(String.valueOf(from)+" → "+String.valueOf(to)+"\n"+String.valueOf(why),12,MUTED,false));LinearLayout buttons=row();Button yes=primary("Setujui");Button no=smallButton("Tolak");buttons.addView(yes,weight());buttons.addView(no,weight());card.addView(buttons,field());body.addView(card,field());yes.setOnClickListener(v->approveCareer(d));no.setOnClickListener(v->rejectRequest("CareerRequests",d.getId()));}}).addOnFailureListener(e->toast("Gagal memuat pengajuan karir: "+e.getLocalizedMessage()));}
  private void approveCareer(DocumentSnapshot req){if(!"admin_utama".equals(currentRole))return;String nik=req.getString("nik"),from=req.getString("currentRole"),to=req.getString("requestedRole"),code=req.getString("storeCode");boolean sequence=("crew".equals(from)&&"acos".equals(to))||("acos".equals(from)&&"cos".equals(to));if(!sequence){toast("Urutan jabatan tidak valid.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()||!from.equals(person.getString("currentRole"))){toast("Jabatan personil sudah berubah. Pengajuan perlu diperiksa ulang.");return;}Map<String,Object> update=new HashMap<>();update.put("currentRole",to);update.put("role",to);update.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());String effective=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());Map<String,Object> history=new HashMap<>();history.put("previousRole",from);history.put("newRole",to);history.put("effectiveDate",effective);history.put("approvedBy","AdminUtama");history.put("notes",req.getString("reason"));db.runBatch(batch->{batch.update(db.collection("Personnel").document(nik),update);batch.update(db.collection("Stores").document(code).collection("Users").document(nik),"role",to);batch.set(db.collection("Personnel").document(nik).collection("CareerHistory").document(),history);batch.update(req.getReference(),"status","approved");batch.update(req.getReference(),"reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());batch.update(req.getReference(),"reviewedBy","AdminUtama");}).addOnSuccessListener(v->showDashboard("Permohonan Karir")).addOnFailureListener(e->toast("Gagal menyetujui karir: "+e.getLocalizedMessage()));});}
  private void rejectRequest(String collection,String id){Map<String,Object> u=new HashMap<>();u.put("status","rejected");u.put("reviewedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());u.put("reviewedBy","AdminUtama");db.collection(collection).document(id).update(u).addOnSuccessListener(v->showDashboard(collection.equals("CareerRequests")?"Permohonan Karir":"Verifikasi Pendaftaran")).addOnFailureListener(e->toast("Gagal menolak permohonan: "+e.getLocalizedMessage()));}
  private void processMutation(String nik,String newCode,String newName){if(!"admin_utama".equals(currentRole)||!nik.matches("\\d{8}")||newCode.isEmpty()||newName.isEmpty()){toast("Periksa NIK, kode toko, dan nama toko.");return;}db.collection("Personnel").document(nik).get().addOnSuccessListener(person->{if(!person.exists()){toast("Data personil tidak ditemukan di Personnel.");return;}String oldCode=person.getString("currentStoreCode"),oldName=person.getString("currentStoreName"),role=person.getString("currentRole"),name=person.getString("name");Map<String,Object> profile=new HashMap<>();profile.put("nik",nik);profile.put("name",name);profile.put("role",role);profile.put("storeCode",newCode);profile.put("storeName",newName);profile.put("email",person.getString("email"));profile.put("isActive",true);Map<String,Object> pupdate=new HashMap<>();pupdate.put("currentStoreCode",newCode);pupdate.put("currentStoreName",newName);pupdate.put("storeCode",newCode);pupdate.put("storeName",newName);Map<String,Object> hist=new HashMap<>();hist.put("previousStoreCode",oldCode);hist.put("previousStoreName",oldName);hist.put("newStoreCode",newCode);hist.put("newStoreName",newName);hist.put("effectiveDate",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()));hist.put("updatedBy","AdminUtama");db.runBatch(batch->{batch.set(db.collection("Stores").document(newCode).collection("Users").document(nik),profile);if(oldCode!=null&&!oldCode.isEmpty()&&!oldCode.equals(newCode))batch.update(db.collection("Stores").document(oldCode).collection("Users").document(nik),"isActive",false);batch.update(db.collection("Personnel").document(nik),pupdate);batch.set(db.collection("Personnel").document(nik).collection("MutationHistory").document(),hist);}).addOnSuccessListener(v->toast("Mutasi berhasil dicatat. Pastikan profil toko lama dinonaktifkan oleh Admin.")).addOnFailureListener(e->toast("Mutasi gagal: "+e.getLocalizedMessage()));});}
  private void showCareerRequest(){if(currentNik.isEmpty()||db==null)return;String next="";if("crew".equals(currentRole))next="acos";else if("acos".equals(currentRole))next="cos";if(next.isEmpty()){toast("COS adalah jenjang tertinggi.");return;}LinearLayout page=col();page.setPadding(dp(18),dp(18),dp(18),dp(18));page.setBackgroundColor(BG);page.addView(txt("PENGAJUAN JENJANG KARIR",20,DARK,true),field());page.addView(txt("Jabatan saat ini: "+roleLabel()+"\nJabatan yang dapat diajukan: "+next.toUpperCase(Locale.US),14,MUTED,false),field());EditText reason=registerField(page,"Alasan pengajuan",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);final String requestedRole=next;Button send=primary("Kirim Pengajuan");page.addView(send,field());Button back=smallButton("Kembali");page.addView(back,field());back.setOnClickListener(v->showDashboard("Profil"));send.setOnClickListener(v->{String why=reason.getText().toString().trim();if(why.isEmpty()){toast("Isi alasan pengajuan terlebih dahulu.");return;}String id=currentNik+"_"+System.currentTimeMillis();Map<String,Object> data=new HashMap<>();data.put("nik",currentNik);data.put("personName",currentName);data.put("currentRole",currentRole);data.put("requestedRole",requestedRole);data.put("storeCode",storeCode);data.put("reason",why);data.put("status","pending");data.put("submittedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());db.collection("CareerRequests").document(id).set(data).addOnSuccessListener(vv->toast("Pengajuan dikirim ke Admin Utama.")).addOnFailureListener(e->toast("Pengajuan gagal: "+e.getLocalizedMessage()));});setContentView(page);}
  // Dashboard IKT membaca dokumen harian per tanggal agar tidak memerlukan query list.
  private void loadDashboardIKT(TextView[][] fields){
    if(db==null||storeCode==null||storeCode.isEmpty()){setDashboardValues(fields,"--","--","--","DATA BELUM TERSEDIA","--","--","--","--","--","--");return;}
    Calendar now=Calendar.getInstance(); int year=now.get(Calendar.YEAR), month=now.get(Calendar.MONTH);
    String monthId=String.format(Locale.US,"%04d%02d",year,month+1); String targetId=storeCode+"_"+monthId;
    db.collection("MonthlyIKTTargets").document(targetId).get().addOnSuccessListener(targetDoc->{
      if(!targetDoc.exists()){setDashboardValues(fields,"--","--","--","TARGET BELUM DIISI","--","--","--","--","--","--");return;}
      double targetSales=num(targetDoc.get("Net Sales")), targetMargin=num(targetDoc.get("Margin %")), targetApc=num(targetDoc.get("APC")), targetStd=num(targetDoc.get("STD"));
      Calendar first=(Calendar)now.clone(); first.set(Calendar.DAY_OF_MONTH,1); int days=now.get(Calendar.DAY_OF_MONTH);
      final double[] sums=new double[5]; final int[] count={0}, pending={days};
      for(int day=1;day<=days;day++){Calendar d=(Calendar)first.clone();d.set(Calendar.DAY_OF_MONTH,day);String key=String.format(Locale.US,"%04d%02d%02d",year,month+1,day);String docId=storeCode+"_"+key;
        db.collection("DailyStoreReports").document(docId).get().addOnSuccessListener(doc->{if(doc.exists()){sums[0]+=num(doc.get("Net Sales"));sums[1]+=num(doc.get("Margin %"));sums[2]+=num(doc.get("NSB"));sums[3]+=num(doc.get("APC"));sums[4]+=num(doc.get("STD"));count[0]++;}pending[0]--;if(pending[0]==0)renderDashboardIKT(fields,sums,count[0],targetSales,targetMargin,targetApc,targetStd);
        }).addOnFailureListener(e->{pending[0]--;if(pending[0]==0)renderDashboardIKT(fields,sums,count[0],targetSales,targetMargin,targetApc,targetStd);});
      }
    }).addOnFailureListener(e->setDashboardValues(fields,"--","--","--","GAGAL MEMBACA TARGET","--","--","--","--","--","--"));
  }
  private double num(Object value){if(value instanceof Number)return ((Number)value).doubleValue();if(value==null)return 0;try{return Double.parseDouble(String.valueOf(value).replace(",","."));}catch(Exception e){return 0;}}
  private String pct(double value,int decimals){return String.format(Locale.US,"%."+decimals+"f%%",value).replace('.',',');}
  private void setDashboardValues(TextView[][] f,String sales,String margin,String nsb,String status,String salesTarget,String salesActual,String marginTarget,String marginActual,String nsbTarget,String nsbActual){
    String[] headline={sales,margin,nsb,status};for(int i=0;i<4;i++)f[i][0].setText(headline[i]);
    f[0][1].setText("Pencapaian");f[0][2].setText("Target : "+salesTarget);f[0][3].setText("Aktual : "+salesActual);
    f[1][1].setText("Pencapaian");f[1][2].setText("Target : "+marginTarget);f[1][3].setText("Aktual : "+marginActual);
    f[2][1].setText("Pencapaian");f[2][2].setText("Batas : "+nsbTarget);f[2][3].setText("Aktual : "+nsbActual);
    f[3][1].setText("Status toko");f[3][2].setText("Target : MENANG");f[3][3].setText("Aktual : "+status);
    double nsbValue=0; try{nsbValue=Double.parseDouble(nsb.replace("%","").replace(',','.'));}catch(Exception ignored){}
    String nsbStatus=nsb.equals("--")?"Menunggu data":(nsbValue<=0.15?"NSB TERKENDALI":(nsbValue<=0.30?"WASPADA KONTROL NSB":"NSB OVERLOAD"));
    String[] notes={"Keterangan : "+(sales.equals("--")?"Menunggu data":"Pencapaian Net Sales"),"Keterangan : "+(margin.equals("--")?"Menunggu data":"Pencapaian Margin"),"Keterangan : "+nsbStatus,"Keterangan : "+(status.equals("MENANG")?"✓ Tercapai":"Dalam Progres")};
    for(int i=0;i<4;i++)f[i][4].setText(notes[i]);
    if(!nsb.equals("--")){f[2][4].setTextColor(nsbValue<=0.15?0xff18864b:(nsbValue<=0.30?0xffb77900:0xffc62828));}
  }
  private void renderDashboardIKT(TextView[][] fields,double[] sums,int count,double targetSales,double targetMargin,double targetApc,double targetStd){
    if(count==0){setDashboardValues(fields,"--","--","--","BELUM ADA DATA","--","Rp 0","--","--","--","--");return;}
    double avgMargin=sums[1]/count,avgApc=sums[3]/count,avgStd=sums[4]/count;
    double nsbAllowance=sums[0]*0.0015; double nsbRemaining=nsbAllowance-sums[2];
    // Dashboard classification uses absolute NSB actual; sign is preserved in the displayed Rupiah value.
    double nsbPercent=sums[0]<=0?0:(Math.abs(sums[2])/sums[0])*100.0;
    double salesAchievement=targetSales<=0?0:(sums[0]/targetSales)*100.0; double marginAchievement=targetMargin<=0?0:(avgMargin/targetMargin)*100.0;
    boolean salesOk=targetSales>0&&sums[0]>=targetSales, marginOk=targetMargin>0&&avgMargin>=targetMargin, nsbOk=nsbPercent<=0.15, apcOk=targetApc>0&&avgApc>=targetApc, stdOk=targetStd>0&&avgStd>=targetStd;
    String status=(salesOk&&marginOk&&nsbOk&&apcOk&&stdOk)?"MENANG":"DALAM PROGRES";
    setDashboardValues(fields,pct(salesAchievement,2),pct(marginAchievement,2),pct(nsbPercent,3),status,formatRupiah(targetSales),formatRupiah(sums[0]),pct(targetMargin,2),pct(avgMargin,2),formatRupiah(nsbAllowance),formatRupiah(sums[2]));
  }

  private String selectedDate(DatePicker date){Calendar c=Calendar.getInstance();c.set(date.getYear(),date.getMonth(),date.getDayOfMonth(),0,0,0);c.set(Calendar.MILLISECOND,0);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
  private String selectedDateKey(DatePicker date){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date(date.getYear()-1900,date.getMonth(),date.getDayOfMonth()));}
  private boolean canEditToday(DatePicker date){Calendar now=Calendar.getInstance();return date.getYear()==now.get(Calendar.YEAR)&&date.getMonth()==now.get(Calendar.MONTH)&&date.getDayOfMonth()==now.get(Calendar.DAY_OF_MONTH)&&now.get(Calendar.HOUR_OF_DAY)<24;}
  private void loadDailyInput(String page,DatePicker date,Map<String,EditText> inputs,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null)return;
    boolean store=page.equals("Input Toko");for(EditText input:inputs.values())input.setText("0");String day=selectedDateKey(date);String targetNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();if(!store&&!targetNik.matches("\\d{8}"))return;String id=store?storeCode+"_"+day:targetNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    db.collection(collection).document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca data: "+e.getLocalizedMessage()));
  }
  private void saveDailyInput(String page,DatePicker date,Map<String,EditText> inputs,Button save,EditText selectedCrewNik){
    if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    boolean store=page.equals("Input Toko");
    boolean elevated="cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole);
    if(store&&!elevated){toast("Hanya COS/ACOS yang dapat menginput data toko.");return;}
    if(!store&&!("crew".equals(currentRole)||elevated)){toast("Jabatan ini tidak memiliki akses input PL.");return;}
    String selectedNik=selectedCrewNik==null?currentNik:selectedCrewNik.getText().toString().trim();
    if(!store&&!selectedNik.matches("\\d{8}")){toast("NIK Crew harus 8 angka.");return;}
    if(!store&&!elevated&&!selectedNik.equals(currentNik)){toast("Crew hanya dapat menginput data miliknya sendiri.");return;}
    String dateText=selectedDate(date),day=selectedDateKey(date);String id=store?storeCode+"_"+day:selectedNik+"_"+day;String collection=store?"DailyStoreReports":"DailyPLReports";
    Map<String,Object> data=new HashMap<>();data.put("date",dateText);data.put("dateKey",day);data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("ownerNik",currentNik);data.put("ownerName",currentName);data.put("ownerRole",currentRole);
    if(!store){data.put("targetNik",selectedNik);data.put("targetName",selectedNik.equals(currentNik)?currentName:"Crew "+selectedNik);}
    try{
      for(String key:inputs.keySet()){
        String raw=inputs.get(key).getText().toString().trim().replace("%","");
        if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');
        if(raw.isEmpty()){toast("Indikator "+key+" wajib diisi.");return;}
        double value=Double.parseDouble(raw);
        if((!key.equalsIgnoreCase("NSB")&&value<0)||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Nilai "+key+" tidak valid.");return;}
        if(!key.equalsIgnoreCase("NSB")&&value<=0){toast(key+" harus lebih dari 0.");return;}
        data.put(key,isDecimalMetric(key)?value:(long)value);
      }
    }catch(NumberFormatException ex){toast("Pastikan semua indikator diisi dengan angka yang valid.");return;}
    StringBuilder summary=new StringBuilder("Tanggal: ").append(dateText).append("\nToko: ").append(storeCode).append(" - ").append(storeName).append("\n\n");
    for(String key:inputs.keySet())summary.append(key).append(": ").append(inputs.get(key).getText().toString()).append("\n");
    new AlertDialog.Builder(this).setTitle("Konfirmasi Data Harian").setMessage(summary.toString()).setNegativeButton("Periksa Kembali",(d,w)->{}).setPositiveButton("Konfirmasi & Simpan",(d,w)->{
      save.setEnabled(false);save.setText("Menyimpan...");
      db.collection(collection).document(id).get().addOnSuccessListener(oldDoc->{
        boolean existed=oldDoc.exists();Map<String,Object> oldValues=existed?new HashMap<>(oldDoc.getData()):new HashMap<>();
        data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
        data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedByRole",currentRole);
        if(!existed){data.put("firstSavedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());Calendar now=Calendar.getInstance();data.put("isLate",now.get(Calendar.HOUR_OF_DAY)>=23);}
        else {Object first=oldDoc.get("firstSavedAt");if(first!=null)data.put("firstSavedAt",first);Object late=oldDoc.get("isLate");data.put("isLate",late instanceof Boolean?(Boolean)late:false);}
        com.google.firebase.firestore.WriteBatch batch=db.batch();com.google.firebase.firestore.DocumentReference reportRef=db.collection(collection).document(id);batch.set(reportRef,data,SetOptions.merge());
        if(existed){Map<String,Object> audit=new HashMap<>();audit.put("date",dateText);audit.put("storeCode",storeCode);audit.put("editedByNik",currentNik);audit.put("editedByName",currentName);audit.put("editedByRole",currentRole);audit.put("editedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());audit.put("oldValues",oldValues);audit.put("newValues",new HashMap<>(data));batch.set(reportRef.collection("EditHistory").document(),audit);}
        batch.commit().addOnSuccessListener(unused->{
          save.setEnabled(true);save.setText("Simpan");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));
          toast(existed?"Data berhasil diperbarui. Riwayat koreksi dicatat.":"Data harian berhasil disimpan.");
          if(store) showDashboard("Beranda");
        }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal menyimpan. Periksa Firestore Rules: "+e.getLocalizedMessage());});
      }).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan");toast("Gagal memeriksa data sebelumnya: "+e.getLocalizedMessage());});
    }).show();
  }


  private void showStoreTypeSettings(LinearLayout body){
    cardTitle(body,"PENGATURAN JENIS TOKO");
    body.addView(txt("Atur jenis toko satu kali. Aplikasi akan membacanya otomatis saat personil login.",12,MUTED,false),field());
    EditText code=registerField(body,"Kode Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
    EditText name=registerField(body,"Nama Toko",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
    Spinner type=new Spinner(this);String[] types={"Pilih Jenis Toko","24 Jam","Normal"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));body.addView(type,field());
    Button load=smallButton("Cek Data Toko");body.addView(load,field());
    load.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US);if(c.isEmpty()){toast("Masukkan kode toko.");return;}db.collection("Stores").document(c).get().addOnSuccessListener(d->{if(d.exists()){name.setText(d.getString("storeName")==null?"":d.getString("storeName"));String t=firstNonEmpty(d.getString("storeType"),d.getString("type"));type.setSelection("24_JAM".equals(t)?1:"NORMAL".equals(t)?2:0);toast("Data toko ditemukan.");}else toast("Dokumen master toko belum ada. Simpan untuk membuatnya.");}).addOnFailureListener(e->toast("Gagal membaca toko: "+e.getLocalizedMessage()));});
    Button save=primary("Simpan Jenis Toko");body.addView(save,field());
    save.setOnClickListener(v->{String c=code.getText().toString().trim().toUpperCase(Locale.US),n=name.getText().toString().trim();int selected=type.getSelectedItemPosition();if(c.isEmpty()||n.isEmpty()||selected==0){toast("Lengkapi kode, nama, dan jenis toko.");return;}String t=selected==1?"24_JAM":"NORMAL";Map<String,Object> data=new HashMap<>();data.put("storeCode",c);data.put("storeName",n);data.put("storeType",t);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());data.put("updatedBy","AdminUtama");save.setEnabled(false);db.collection("Stores").document(c).set(data,SetOptions.merge()).addOnSuccessListener(x->{save.setEnabled(true);toast("Jenis toko "+t.replace('_',' ')+" berhasil disimpan untuk "+c+".");}).addOnFailureListener(e->{save.setEnabled(true);toast("Gagal menyimpan. Pastikan Firestore Rules mengizinkan Admin Utama mengubah master Stores: "+e.getLocalizedMessage());});});
  }

  private String[] menuEntries(){
    if("admin_utama".equals(currentRole))return new String[]{"Beranda","Pengaturan Jenis Toko","Verifikasi Pendaftaran","Permohonan Karir","Mutasi Personil"};
    if("cos".equals(currentRole)||"acos".equals(currentRole))return new String[]{"Beranda","Input Target IKT","Input Target Penawaran Langsung","Input Toko","Input PL Crew","Ranking Crew","Reward","Laporan","Profil","Keluar"};
    return new String[]{"Beranda","Input PL","Ranking Crew","Laporan","Profil","Keluar"};
  }
  private String monthKey(DatePicker date){return String.format(Locale.US,"%04d%02d",date.getYear(),date.getMonth()+1);}
  // Tampilan angka tidak mengubah nilai numerik yang disimpan di Firestore.
  private String cleanNumber(Object value, boolean decimalAllowed){
    if(value==null)return "0";
    try{
      double n=Double.parseDouble(String.valueOf(value).replace(",","."));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0";
      if(!decimalAllowed || n==Math.rint(n))return String.format(Locale.US,"%.0f",n);
      return String.format(Locale.US,"%s",new java.math.BigDecimal(String.valueOf(n)).stripTrailingZeros().toPlainString());
    }catch(Exception e){return String.valueOf(value);}
  }
  // Margin disimpan sebagai angka (mis. 12.52), tetapi selalu ditampilkan 2 desimal dengan koma dan %.
  private String formatMargin(Object value){
    try{
      double n=Double.parseDouble(String.valueOf(value).trim().replace("%","").replace(',','.'));
      if(Double.isNaN(n)||Double.isInfinite(n))return "0,00%";
      return String.format(new Locale("id","ID"),"%.2f%%",n);
    }catch(Exception e){return "0,00%";}
  }
  private String formatGroupedInteger(Object value){
    try{java.math.BigDecimal n=new java.math.BigDecimal(String.valueOf(value).replace(",","."));return String.format(new Locale("id","ID"),"%,.0f",n.doubleValue());}catch(Exception e){return "0";}
  }
  private String profileDocumentId(){return currentRole!=null&&currentRole.equals("admin_utama")?"AdminUtama":currentNik;}
  private void chooseProfilePhoto(){Intent intent=new Intent(Intent.ACTION_GET_CONTENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(intent,"Pilih foto profil"),PICK_PROFILE_PHOTO);}
  private void loadProfilePhoto(){if(db==null)return;String docId=profileDocumentId();if(docId==null||docId.isEmpty())return;db.collection("Users").document(docId).get().addOnSuccessListener(doc->{String url=doc.getString("profilePhotoUrl");if(url!=null&&!url.isEmpty()&&storage!=null){storage.getReferenceFromUrl(url).getBytes(4*1024*1024).addOnSuccessListener(bytes->{if(profileAvatar!=null)profileAvatar.setImageBitmap(BitmapFactory.decodeByteArray(bytes,0,bytes.length));}).addOnFailureListener(e->toast("Foto profil gagal dimuat."));}});}
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_PROFILE_PHOTO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri source=data.getData();Uri destination=Uri.fromFile(new File(getCacheDir(),"profile_crop_"+System.currentTimeMillis()+".jpg"));UCrop.of(source,destination).withAspectRatio(1,1).withMaxResultSize(900,900).start(this);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==RESULT_OK&&data!=null){Uri cropped=UCrop.getOutput(data);if(cropped!=null)uploadProfilePhoto(cropped);return;}if(requestCode==UCrop.REQUEST_CROP&&resultCode==UCrop.RESULT_ERROR&&data!=null){Throwable error=UCrop.getError(data);toast("Gagal memotong foto: "+(error==null?"coba foto lain":error.getLocalizedMessage()));}}
  private void uploadProfilePhoto(Uri uri){if(profileAvatar!=null)profileAvatar.setImageURI(uri);if(storage==null||auth==null||auth.getCurrentUser()==null||db==null){toast("Firebase Storage belum siap.");return;}String docId=profileDocumentId();String uid=auth.getCurrentUser().getUid();StorageReference ref=storage.getReference().child("profile_photos").child(uid+".jpg");toast("Mengunggah foto profil...");ref.putFile(uri).continueWithTask(task->{if(!task.isSuccessful())throw task.getException();return ref.getDownloadUrl();}).addOnSuccessListener(download->{Map<String,Object> update=new HashMap<>();update.put("profilePhotoUrl",download.toString());db.collection("Users").document(docId).update(update).addOnSuccessListener(v->toast("Foto profil berhasil disimpan.")).addOnFailureListener(e->toast("Foto terunggah, tetapi profil Firestore menolak penyimpanan URL. Periksa Rules."));}).addOnFailureListener(e->toast("Gagal mengunggah foto: "+e.getLocalizedMessage()));}
  private void configureMetricInput(EditText input,String key){
    if(isDecimalMetric(key)){
      input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
      input.setKeyListener(DigitsKeyListener.getInstance("0123456789,.%"));
      input.setHint("0,0 %");
    }else{
      input.setInputType(InputType.TYPE_CLASS_NUMBER);
      input.setKeyListener(DigitsKeyListener.getInstance(key.equalsIgnoreCase("NSB")?"-0123456789.":(isRupiahMetric(key)?"0123456789.":"0123456789")));
    }
  }
  private void applyZeroFocusStyle(EditText input){
    input.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
    input.setOnFocusChangeListener((v,focused)->{
      String raw=input.getText().toString().trim().replace(",",".");
      boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
      input.setTypeface(Typeface.create("sans-serif",focused&&zero?Typeface.BOLD:Typeface.NORMAL));
    });
    input.addTextChangedListener(new TextWatcher(){
      boolean fixing=false;
      public void beforeTextChanged(CharSequence s,int start,int count,int after){}
      public void onTextChanged(CharSequence s,int start,int before,int count){
        if(input.hasFocus()){
          String raw=s.toString().trim().replace(",",".").replace("%","");
          boolean zero=raw.isEmpty()||raw.matches("[+-]?0+(\\.0*)?");
          input.setTypeface(Typeface.create("sans-serif",zero?Typeface.BOLD:Typeface.NORMAL));
        }
      }
      public void afterTextChanged(Editable e){
        if(fixing||!input.hasFocus()||e.length()<=1)return;
        if(e.charAt(0)=='0' && Character.isDigit(e.charAt(1))){fixing=true;e.delete(0,1);fixing=false;}
      }
    });
  }
  private boolean isDecimalMetric(String key){return key!=null&&key.toLowerCase(Locale.ROOT).contains("margin");}
  private boolean isRupiahMetric(String key){return key!=null&&(key.equalsIgnoreCase("Net Sales")||key.equalsIgnoreCase("NSB")||key.equalsIgnoreCase("APC")||key.equalsIgnoreCase("netSales")||key.equalsIgnoreCase("nsb")||key.equalsIgnoreCase("apc"));}
  private String formatRupiah(Object value){return "Rp "+String.format(Locale.US,"%,.0f",Double.parseDouble(cleanNumber(value,false))).replace(',','.');}
  private void loadMonthlyTarget(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return;String id=storeCode+"_"+monthKey(date);db.collection("MonthlyIKTTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object value=doc.get(key);if(value!=null)inputs.get(key).setText(isDecimalMetric(key)?formatMargin(value):(isRupiahMetric(key)?formatGroupedInteger(value):cleanNumber(value,false)));}}).addOnFailureListener(e->toast("Gagal membaca target: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyTarget(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target IKT.");return;}if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>();data.put("month",monthKey(date));data.put("storeCode",storeCode);data.put("storeName",storeName);data.put("updatedByNik",currentNik);data.put("updatedByName",currentName);data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","");if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if(value<0||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyIKTTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target");for(String key:inputs.keySet())inputs.get(key).setText(isDecimalMetric(key)?formatMargin(data.get(key)):(isRupiahMetric(key)?formatGroupedInteger(data.get(key)):cleanNumber(data.get(key),false)));toast("Target IKT bulanan berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target");toast("Gagal menyimpan target. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }
  private void addTargetPeriod(LinearLayout body,Map<String,EditText> inputs,String category,String period,String key){
    LinearLayout card=col(); card.setBackground(shape(Color.WHITE,0xffe5e9ef,dp(13))); card.setPadding(dp(12),dp(10),dp(12),dp(10));
    card.addView(txt(category+"  •  "+period,13,DARK,true)); EditText value=new EditText(this); value.setSingleLine(true); value.setText("0"); value.setHint("Masukkan target"); value.setInputType(InputType.TYPE_CLASS_NUMBER); applyZeroFocusStyle(value); card.addView(value,lp(-2));
    LinearLayout.LayoutParams q=lp(-2); q.bottomMargin=dp(7); body.addView(card,q); inputs.put(key,value);
  }
  private void loadMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs){
    if(db==null)return; String id=storeCode+"_"+monthKey(date); db.collection("MonthlyPLTargets").document(id).get().addOnSuccessListener(doc->{if(doc.exists())for(String key:inputs.keySet()){Object v=doc.get(key);if(v!=null)inputs.get(key).setText(cleanNumber(v,false));}}).addOnFailureListener(e->toast("Gagal membaca target PL: "+e.getLocalizedMessage()));
  }
  private void saveMonthlyPLTargets(DatePicker date,Map<String,EditText> inputs,Button save){
    if(!("cos".equals(currentRole)||"acos".equals(currentRole)||"admin_utama".equals(currentRole))){toast("Hanya COS/ACOS yang dapat mengatur target toko.");return;} if(db==null||auth==null||auth.getCurrentUser()==null){toast("Sesi login tidak ditemukan.");return;}
    Map<String,Object> data=new HashMap<>(); data.put("month",monthKey(date)); data.put("storeCode",storeCode); data.put("storeName",storeName); data.put("updatedByNik",currentNik); data.put("updatedByName",currentName); data.put("updatedByRole",currentRole); data.put("updatedAt",com.google.firebase.firestore.FieldValue.serverTimestamp());
    try{for(String key:inputs.keySet()){String raw=inputs.get(key).getText().toString().trim().replace("%","");if(isRupiahMetric(key))raw=raw.replace(".","").replace(",","");else raw=raw.replace(',','.');if(raw.isEmpty())raw="0";double value=Double.parseDouble(raw);if((!key.equalsIgnoreCase("NSB")&&value<0)||Double.isNaN(value)||Double.isInfinite(value)||(!isDecimalMetric(key)&&value!=Math.rint(value))){toast("Target "+key+" harus berupa angka bulat yang valid.");return;}data.put(key,isDecimalMetric(key)?value:(long)value);}}catch(NumberFormatException e){toast("Target harus berupa angka.");return;}
    save.setEnabled(false);save.setText("Menyimpan...");db.collection("MonthlyPLTargets").document(storeCode+"_"+monthKey(date)).set(data,SetOptions.merge()).addOnSuccessListener(v->{save.setEnabled(true);save.setText("Simpan Target Penawaran Langsung");toast("Target Penawaran Langsung berhasil disimpan.");}).addOnFailureListener(e->{save.setEnabled(true);save.setText("Simpan Target Penawaran Langsung");toast("Gagal menyimpan target PL. Periksa Firestore Rules: "+e.getLocalizedMessage());});
  }

  private String roleLabel(){if("cos".equals(currentRole))return "COS";if("acos".equals(currentRole))return "ACOS";if("crew".equals(currentRole))return "Crew";return "Admin Utama";}
  private void cardTitle(LinearLayout p,String s){TextView t=txt(s,16,DARK,true);t.setPadding(0,dp(16),0,dp(9));p.addView(t,lp(-2));}
  private View metricBox(String title,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe4e4e4,dp(10)));c.setPadding(dp(6),dp(12),dp(6),dp(12));c.addView(center(title,10,MUTED,false));c.addView(center(value,16,GREEN,true));return c;}
  private View metric(LinearLayout p,String title,String sub,String val,boolean unused){LinearLayout c=col();c.setBackground(shape(0xfffff5dc,0xffeadcae,dp(12)));c.setPadding(dp(14),dp(14),dp(14),dp(14));c.addView(txt(title,14,DARK,true));c.addView(txt(sub+"  "+val,14,GREEN,true));p.addView(c,lp(-2));return c;}
  private void progressRow(LinearLayout p,String name,String value){LinearLayout c=col();c.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(15)));c.setElevation(dp(1));c.setPadding(dp(14),dp(12),dp(14),dp(12));LinearLayout top=row();top.addView(txt(name,14,DARK,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(txt("—",13,MUTED,true));c.addView(top);TextView sub=txt(value,11,MUTED,false);sub.setPadding(0,dp(4),0,dp(8));c.addView(sub);ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffedf0f4));c.addView(bar,lp(7));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(8);p.addView(c,q);}
  private void detail(LinearLayout p,String k,String v){LinearLayout r=row();r.setPadding(dp(10),dp(13),dp(10),dp(13));r.setBackground(shape(Color.WHITE,0xffe7ebf2,dp(14)));r.addView(txt(k,13,DARK,false),new LinearLayout.LayoutParams(0,-2,1));r.addView(txt(v,13,DARK,true));LinearLayout.LayoutParams q=lp(-2);q.bottomMargin=dp(5);p.addView(r,q);}
  private Button smallButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setAllCaps(false);b.setPadding(dp(2),dp(2),dp(2),dp(2));b.setTextColor(RED);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));return b;}
  private Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));b.setMinHeight(dp(48));return b;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  @Override public void onBackPressed(){if(auth!=null&&auth.getCurrentUser()!=null){showDashboard("Beranda");}else showLogin();}
}
