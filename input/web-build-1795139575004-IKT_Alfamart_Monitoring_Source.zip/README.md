# IKT Alfamart Monitoring — starter source

Package: `com.adzwan.iktalfamartmonitoring`
Firebase project: `monitoring-ikt`

This is a buildable starter shell containing the Android project structure, Firebase Android configuration, and an initial NIK/PIN login screen.

IMPORTANT: This is not the completed monitoring application. NIK/PIN authentication is intentionally not faked and is not yet active. A secure backend (for example, a Cloud Function that validates a PIN hash and issues a Firebase custom token), Firestore security rules, role-based screens, daily input, targets, reports, reminders, and offline synchronization still need implementation and testing before real operational use.

Do not put plain PINs or passwords in Firestore. Keep `google-services.json` private to this project and never publish it in a public repository.
