package com.adzwan.iktalfamartmonitoring;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends Activity {
    private int red = Color.rgb(215, 25, 32);
    private int dark = Color.rgb(40, 40, 40);
    private int gold = Color.rgb(255, 204, 0);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        try { FirebaseApp.initializeApp(this); } catch (Exception ignored) {}
        showLogin();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 36, 28, 28); root.setBackgroundColor(Color.rgb(248,248,248));
        return root;
    }

    private void showLogin() {
        LinearLayout root = page();
        TextView brand = text("ALFAMART", 28, red, true);
        brand.setPadding(0, 28, 0, 4); root.addView(brand, match());
        root.addView(text("IKT MONITORING", 20, dark, true), match());
        root.addView(text("Monitoring Kinerja Toko", 14, Color.DKGRAY, false), match());
        EditText nik = new EditText(this); nik.setSingleLine(true); nik.setHint("NIK (8 digit)"); nik.setInputType(2);
        root.addView(nik, field());
        EditText pin = new EditText(this); pin.setSingleLine(true); pin.setHint("PIN (6 digit)"); pin.setInputType(2 | 0x80);
        root.addView(pin, field());
        Button login = new Button(this); login.setText("MASUK"); login.setTextColor(Color.WHITE); login.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
        root.addView(login, field());
        login.setOnClickListener(v -> {
            String n = nik.getText().toString().trim(), p = pin.getText().toString().trim();
            if (!n.matches("\\d{8}") || !p.matches("\\d{6}")) {
                Toast.makeText(this, "NIK harus 8 digit dan PIN harus 6 digit", Toast.LENGTH_LONG).show(); return;
            }
            Toast.makeText(this, "Layanan login NIK/PIN belum diaktifkan. Perlu backend autentikasi aman.", Toast.LENGTH_LONG).show();
        });
        TextView note = text("Versi awal aplikasi — koneksi Firebase disiapkan. Login NIK/PIN dan fitur operasional akan diaktifkan setelah backend dan aturan keamanan selesai.", 12, Color.GRAY, false);
        note.setPadding(8, 24, 8, 0); root.addView(note, match());
        setContentView(root);
    }

    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams field() { LinearLayout.LayoutParams p = match(); p.setMargins(0, 14, 0, 0); return p; }
}
